package com.artifex.sonui.artifactsdk.utilitiesEditorSdk;

import java.util.ArrayList;
import java.util.Arrays;

public class EditorBottomBarConstants {
    public static final ArrayList<String> bottomDocxToolsListForXLSAPP = new ArrayList<>(Arrays.asList(new String[]{"Text Type", "Text Size", "Bold Text", "Docx To Pdf"}));
    public static final ArrayList<String> bottomXlsToolsListForXLSAPP = new ArrayList<>(Arrays.asList(new String[]{"Text Type", "Text Size", "Bold Text", "Excel to PDF"}));
    public static final ArrayList<String> editorPdfToolsList = new ArrayList<>(Arrays.asList(new String[]{"Compress PDF", "E Signature PDF", "Split PDF"}));
}
