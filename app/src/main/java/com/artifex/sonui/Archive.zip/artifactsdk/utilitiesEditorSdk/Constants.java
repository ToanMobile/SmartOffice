package com.artifex.sonui.artifactsdk.utilitiesEditorSdk;

import java.util.ArrayList;
import java.util.Arrays;

public final class Constants {
    public static final ArrayList<String> editorDocxToolsList = new ArrayList<>(Arrays.asList(new String[]{"Docx To Pdf", "Edit Docx"}));
    public static final ArrayList<String> editorDocxToolsListDocX = new ArrayList<>(Arrays.asList(new String[]{"Docx To Pdf"}));
    public static final ArrayList<String> editorPPTToolsList = new ArrayList<>(Arrays.asList(new String[]{"PPT to PDF"}));
    public static final ArrayList<String> editorXlsToolsList = new ArrayList<>(Arrays.asList(new String[]{"Excel to PDF", "Edit Xls"}));
    public static final ArrayList<String> editorXlsToolsListForXLSAPP = new ArrayList<>(Arrays.asList(new String[]{"Excel to PDF"}));
}
