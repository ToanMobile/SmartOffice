package com.artifex.sonui.commonutils;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatEditText;
import billing.pro.SubscriptionPlan$$ExternalSyntheticLambda3;
import com.analytics_lite.analytics.analytic.AnalyticsHelp;
import com.rpdev.document.manager.reader.allfiles.R;
import java.util.HashMap;
import kotlin.jvm.internal.DefaultConstructorMarker;

public final class RenameFileDialog extends Dialog {
    public static final /* synthetic */ int $r8$clinit = 0;
    public String fileName;
    public final RenameFileDialogListener listener;
    public final String openedFrom;

    public interface RenameFileDialogListener {
    }

    public RenameFileDialog(Context context, RenameFileDialogListener renameFileDialogListener, String str) {
        super(context);
        this.listener = renameFileDialogListener;
        this.openedFrom = str;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.v2_add_label_dialog);
        HashMap hashMap = new HashMap();
        hashMap.put("openedFrom", this.openedFrom);
        if (AnalyticsHelp.instance == null) {
            AnalyticsHelp.instance = new AnalyticsHelp((DefaultConstructorMarker) null);
        }
        AnalyticsHelp analyticsHelp = AnalyticsHelp.instance;
        if (analyticsHelp != null) {
            analyticsHelp.logEvent("event_app_rename_dialog_shown", hashMap);
        }
        Window window = getWindow();
        if (window != null) {
            window.setLayout((int) (((double) Resources.getSystem().getDisplayMetrics().widthPixels) * 0.8d), -2);
        }
        TextView textView = (TextView) findViewById(R.id.txtDone);
        ((TextView) findViewById(R.id.txtTitle)).setText("Rename File");
        ((TextView) findViewById(R.id.txtMsg)).setText("Enter file name");
        textView.setText("Rename");
        ((TextView) findViewById(R.id.txtCancel)).setOnClickListener(new SubscriptionPlan$$ExternalSyntheticLambda3(this));
        textView.setOnClickListener(new RenameFileDialog$$ExternalSyntheticLambda0(this, (AppCompatEditText) findViewById(R.id.eTextTagName)));
    }
}
