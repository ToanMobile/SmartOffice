package com.artifex.sonui.artifactsdk.modelEditor;

public class PathData {
    public boolean isFolder = false;
    public String path;
    public String title;
}
