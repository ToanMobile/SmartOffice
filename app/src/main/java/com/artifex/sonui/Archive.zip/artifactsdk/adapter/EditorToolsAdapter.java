package com.artifex.sonui.artifactsdk.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import com.commons_lite.ads_module.billing.pro.legacy.ProAdapter$$ExternalSyntheticOutline0;
import com.rpdev.document.manager.reader.allfiles.R;
import java.util.ArrayList;

public class EditorToolsAdapter extends RecyclerView.Adapter<ToolViewHolder> {
    public Boolean iSBottom;
    public EditorToolOnClickListener listener;
    public ArrayList<String> toolList;
    public Integer width;

    public interface EditorToolOnClickListener {
        void editorToolOnClick(String str);
    }

    public class ToolViewHolder extends RecyclerView.ViewHolder {
        public ImageView toolIcon;
        public ConstraintLayout toolItemLayout;
        public AppCompatTextView toolTitle;

        public ToolViewHolder(EditorToolsAdapter editorToolsAdapter, View view) {
            super(view);
            this.toolIcon = (ImageView) view.findViewById(R.id.editorToolIcon);
            this.toolTitle = (AppCompatTextView) view.findViewById(R.id.editorToolTitle);
            this.toolItemLayout = (ConstraintLayout) view.findViewById(R.id.toolItemLayout);
        }
    }

    public EditorToolsAdapter(int i, Boolean bool, ArrayList<String> arrayList, EditorToolOnClickListener editorToolOnClickListener) {
        this.width = Integer.valueOf(i);
        this.iSBottom = bool;
        this.toolList = arrayList;
        this.listener = editorToolOnClickListener;
    }

    public int getItemCount() {
        return this.toolList.size();
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x009b, code lost:
        if (r0.equals("E Signature PDF") == false) goto L_0x00d5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onBindViewHolder(androidx.recyclerview.widget.RecyclerView.ViewHolder r5, int r6) {
        /*
            r4 = this;
            com.artifex.sonui.artifactsdk.adapter.EditorToolsAdapter$ToolViewHolder r5 = (com.artifex.sonui.artifactsdk.adapter.EditorToolsAdapter.ToolViewHolder) r5
            java.lang.Boolean r0 = r4.iSBottom
            boolean r0 = r0.booleanValue()
            r1 = 5
            if (r0 == 0) goto L_0x0026
            androidx.constraintlayout.widget.ConstraintLayout r0 = r5.toolItemLayout
            android.view.ViewGroup$LayoutParams r0 = r0.getLayoutParams()
            java.lang.Integer r2 = r4.width
            int r2 = r2.intValue()
            java.util.ArrayList<java.lang.String> r3 = r4.toolList
            int r3 = r3.size()
            int r2 = r2 / r3
            int r2 = r2 - r1
            r0.width = r2
            androidx.constraintlayout.widget.ConstraintLayout r2 = r5.toolItemLayout
            r2.setLayoutParams(r0)
        L_0x0026:
            androidx.appcompat.widget.AppCompatTextView r0 = r5.toolTitle
            java.util.ArrayList<java.lang.String> r2 = r4.toolList
            java.lang.Object r2 = r2.get(r6)
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
            r0.setText(r2)
            java.util.ArrayList<java.lang.String> r0 = r4.toolList
            java.lang.Object r0 = r0.get(r6)
            java.lang.String r0 = (java.lang.String) r0
            java.util.Objects.requireNonNull(r0)
            int r2 = r0.hashCode()
            switch(r2) {
                case -2053846300: goto L_0x00ca;
                case -1888231764: goto L_0x00bf;
                case -1293553779: goto L_0x00b4;
                case -665540406: goto L_0x00a9;
                case 78343830: goto L_0x009e;
                case 85869743: goto L_0x0095;
                case 291526486: goto L_0x008a;
                case 907236116: goto L_0x007f;
                case 907280973: goto L_0x0071;
                case 1106729448: goto L_0x0063;
                case 1603960628: goto L_0x0055;
                case 1665114345: goto L_0x0047;
                default: goto L_0x0045;
            }
        L_0x0045:
            goto L_0x00d5
        L_0x0047:
            java.lang.String r1 = "Edit Xls"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0051
            goto L_0x00d5
        L_0x0051:
            r1 = 11
            goto L_0x00d6
        L_0x0055:
            java.lang.String r1 = "Compress PDF"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x005f
            goto L_0x00d5
        L_0x005f:
            r1 = 10
            goto L_0x00d6
        L_0x0063:
            java.lang.String r1 = "Bold Text"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x006d
            goto L_0x00d5
        L_0x006d:
            r1 = 9
            goto L_0x00d6
        L_0x0071:
            java.lang.String r1 = "Text Type"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x007b
            goto L_0x00d5
        L_0x007b:
            r1 = 8
            goto L_0x00d6
        L_0x007f:
            java.lang.String r1 = "Text Size"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0088
            goto L_0x00d5
        L_0x0088:
            r1 = 7
            goto L_0x00d6
        L_0x008a:
            java.lang.String r1 = "Excel to PDF"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x0093
            goto L_0x00d5
        L_0x0093:
            r1 = 6
            goto L_0x00d6
        L_0x0095:
            java.lang.String r2 = "E Signature PDF"
            boolean r0 = r0.equals(r2)
            if (r0 != 0) goto L_0x00d6
            goto L_0x00d5
        L_0x009e:
            java.lang.String r1 = "Edit Docx"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x00a7
            goto L_0x00d5
        L_0x00a7:
            r1 = 4
            goto L_0x00d6
        L_0x00a9:
            java.lang.String r1 = "Merge PDF"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x00b2
            goto L_0x00d5
        L_0x00b2:
            r1 = 3
            goto L_0x00d6
        L_0x00b4:
            java.lang.String r1 = "Docx To Pdf"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x00bd
            goto L_0x00d5
        L_0x00bd:
            r1 = 2
            goto L_0x00d6
        L_0x00bf:
            java.lang.String r1 = "Split PDF"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x00c8
            goto L_0x00d5
        L_0x00c8:
            r1 = 1
            goto L_0x00d6
        L_0x00ca:
            java.lang.String r1 = "PDF to Image"
            boolean r0 = r0.equals(r1)
            if (r0 != 0) goto L_0x00d3
            goto L_0x00d5
        L_0x00d3:
            r1 = 0
            goto L_0x00d6
        L_0x00d5:
            r1 = -1
        L_0x00d6:
            switch(r1) {
                case 0: goto L_0x012b;
                case 1: goto L_0x0122;
                case 2: goto L_0x0119;
                case 3: goto L_0x0110;
                case 4: goto L_0x0107;
                case 5: goto L_0x00fe;
                case 6: goto L_0x0119;
                case 7: goto L_0x00f5;
                case 8: goto L_0x00ec;
                case 9: goto L_0x00e3;
                case 10: goto L_0x00da;
                case 11: goto L_0x0107;
                default: goto L_0x00d9;
            }
        L_0x00d9:
            goto L_0x0133
        L_0x00da:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231360(0x7f080280, float:1.8078799E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x00e3:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231002(0x7f08011a, float:1.8078073E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x00ec:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131232338(0x7f080652, float:1.8080782E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x00f5:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131232337(0x7f080651, float:1.808078E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x00fe:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231490(0x7f080302, float:1.8079062E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x0107:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231491(0x7f080303, float:1.8079065E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x0110:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231499(0x7f08030b, float:1.807908E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x0119:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231525(0x7f080325, float:1.8079133E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x0122:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231520(0x7f080320, float:1.8079123E38)
            r0.setImageResource(r1)
            goto L_0x0133
        L_0x012b:
            android.widget.ImageView r0 = r5.toolIcon
            r1 = 2131231502(0x7f08030e, float:1.8079087E38)
            r0.setImageResource(r1)
        L_0x0133:
            androidx.constraintlayout.widget.ConstraintLayout r5 = r5.toolItemLayout
            com.artifex.sonui.artifactsdk.adapter.EditorToolsAdapter$$ExternalSyntheticLambda0 r0 = new com.artifex.sonui.artifactsdk.adapter.EditorToolsAdapter$$ExternalSyntheticLambda0
            r0.<init>((com.artifex.sonui.artifactsdk.adapter.EditorToolsAdapter) r4, (int) r6)
            r5.setOnClickListener(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.artifex.sonui.artifactsdk.adapter.EditorToolsAdapter.onBindViewHolder(androidx.recyclerview.widget.RecyclerView$ViewHolder, int):void");
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        if (this.iSBottom.booleanValue()) {
            return new ToolViewHolder(this, ProAdapter$$ExternalSyntheticOutline0.m(viewGroup, R.layout.bottom_tool_item_layout, viewGroup, false));
        }
        return new ToolViewHolder(this, ProAdapter$$ExternalSyntheticOutline0.m(viewGroup, R.layout.editor_tool_item_layout, viewGroup, false));
    }
}
