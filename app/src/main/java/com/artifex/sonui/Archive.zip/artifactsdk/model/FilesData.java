package com.artifex.sonui.artifactsdk.model;

import java.io.Serializable;

public class FilesData implements Serializable {
    public long fileDate;
    public boolean isFavorite = false;
    public String path;
    public boolean showAds = false;
    public double size;
    public String title = "";
}
