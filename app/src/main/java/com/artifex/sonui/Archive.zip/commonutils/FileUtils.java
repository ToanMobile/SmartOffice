package com.artifex.sonui.commonutils;

import android.app.Activity;
import android.preference.PreferenceManager;

public class FileUtils {
    public final Activity mContext;

    public enum FileType {
        e_PDF,
        e_TXT
    }

    public FileUtils(Activity activity) {
        this.mContext = activity;
        PreferenceManager.getDefaultSharedPreferences(activity);
    }

    public static String getFileName(String str) {
        int lastIndexOf;
        if (str != null && (lastIndexOf = str.lastIndexOf("/")) < str.length()) {
            return str.substring(lastIndexOf + 1);
        }
        return null;
    }
}
