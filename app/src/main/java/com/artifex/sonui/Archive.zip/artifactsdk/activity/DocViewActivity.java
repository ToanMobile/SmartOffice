package com.artifex.sonui.artifactsdk.activity;

import a.a.a.a.a.c$$ExternalSyntheticOutline0;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts$StartActivityForResult;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.ViewUtilsBase;
import billing.adapters.SkuDetailsAdapter$$ExternalSyntheticOutline0;
import billing.freeTrial.FreeTrialActivityHelper;
import billing.helper.BillingHelp;
import billing.pro.SubscriptionPlan$$ExternalSyntheticLambda0;
import com.analytics_lite.analytics.analytic.AnalyticsHelp;
import com.applovin.sdk.AppLovinEventTypes;
import com.arasthel.asyncjob.AsyncJob;
import com.artifex.solib.ArDkLib;
import com.artifex.solib.ConfigOptions;
import com.artifex.solib.FileUtils;
import com.artifex.solib.SODocSaveListener;
import com.artifex.solib.SOPreferences;
import com.artifex.sonui.editor.SODocumentView;
import com.artifex.sonui.editor.Utilities;
import com.commons_lite.ads_module.CommonsMultiDexApplication;
import com.commons_lite.ads_module.ads.control.AdHelpMain;
import com.commons_lite.ads_module.ads.control.vendor.appLovin.NativeTemplateBuilder;
import com.commons_lite.utilities.permissions.PermissionUtils;
import com.commons_lite.utilities.rating.RateAppBottomSheet;
import com.commons_lite.utilities.util.UtilsApp;
import com.artifex.sonui.artifactsdk.adapter.EditorToolsAdapter;
import com.artifex.sonui.artifactsdk.utilitiesEditorSdk.ClipboardHandler;
import com.artifex.sonui.artifactsdk.utilitiesEditorSdk.Constants;
import com.artifex.sonui.artifactsdk.utilitiesEditorSdk.DataLeakHandlers;
import com.artifex.sonui.artifactsdk.utilitiesEditorSdk.EditorBottomBarConstants;
import com.artifex.sonui.artifactsdk.utilitiesEditorSdk.Overlay;
import com.artifex.sonui.artifactsdk.utilitiesEditorSdk.PersistentStorage;
import com.artifex.sonui.artifactsdk.utilitiesEditorSdk.SecureFS;
import com.artifex.sonui.commonutils.ManageFiles;
import com.artifex.sonui.commonutils.ManageLabelDialog;
import com.artifex.sonui.commonutils.PDFPasswordDialog;
import com.github.clans.fab.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.rpdev.a1officecloudmodule.login.LoginHelper;
import com.rpdev.a1officecloudmodule.share.ShareFileHelper;
import com.rpdev.a1officecloudmodule.utilities.IntentRedirectionConstants;
import com.rpdev.docreadermainV2.activity.pdfTools.ToolsViewActivity;
import com.rpdev.docreadermainV2.pdfTools.filePreview.FilePreviewHandlingActivity;
import com.rpdev.document.manager.reader.allfiles.R;
import com.zoho.desk.asap.R$layout;
import es.dmoral.toasty.Toasty;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Callable;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.apache.commons.io.FilenameUtils;

public class DocViewActivity extends Hilt_DocViewActivity implements EditorToolsAdapter.EditorToolOnClickListener, ManageLabelDialog.OnManageLabelCallback, PermissionUtils.onGetCallableListener {
    public static boolean isSetup = false;
    public ActivityResultLauncher<Intent> allowAccessButtonCallback = registerForActivityResult(new ActivityResultContracts$StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        public void onActivityResult(Object obj) {
            ActivityResult activityResult = (ActivityResult) obj;
            if (PermissionUtils.checkPermission(DocViewActivity.this.mContext) || ContextCompat.checkSelfPermission(DocViewActivity.this.mContext, "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                AnalyticsHelp.getInstance().logEvent("event_app_editor_view_permission_success", (Map<String, String>) null);
                DocViewActivity.this.allDocControllerInit();
            }
        }
    });
    public AppCompatTextView bottomTextSize;
    public RecyclerView bottomToolsRecycler;
    public Button btnAllowAccess;
    public final int[] colors = {-65536, -16711936, -16776961};
    public final int[] colorsToShow = {R.color.colorLineRed, R.color.colorLineGreen, R.color.colorLineBlue};
    public ConfigOptions configOptions;
    public AppCompatEditText eTextSearch;
    public AlertDialog editFileDialog1;
    public EditorToolsAdapter.EditorToolOnClickListener editorToolOnClickListener;
    public EditorToolsAdapter editorToolsAdapter;
    public RecyclerView editorToolsRecycler;
    public FloatingActionButton fabEdit;
    public String fileExt = "";
    public String fileName = "";
    public String filePath = "";
    public String fileType;
    public AppCompatImageView fontMinus;
    public AppCompatImageView fontPlus;
    public boolean fromApp;
    public ImageView imgDraw;
    public ImageView imgLineColor;
    public AppCompatImageView imvArrange1;
    public AppCompatImageView imvArrange2;
    public AppCompatImageView imvArrange3;
    public AppCompatImageView imvArrange4;
    public AppCompatImageView imvBold;
    public AppCompatImageView imvClear;
    public ImageView imvCloseEPD;
    public AppCompatImageView imvDrawRedo;
    public AppCompatImageView imvDrawSelectAlignment;
    public AppCompatImageView imvDrawSelectBgColor;
    public AppCompatImageView imvDrawUndo;
    public AppCompatImageView imvFontMinus;
    public AppCompatImageView imvFontPlus;
    public AppCompatImageView imvFormatRedo;
    public AppCompatImageView imvFormatUndo;
    public ImageView imvFullScreen;
    public AppCompatImageView imvInsertRedo;
    public AppCompatImageView imvInsertUndo;
    public AppCompatImageView imvItalic;
    public AppCompatImageView imvRedo;
    public AppCompatImageView imvSearchForward;
    public AppCompatImageView imvSearchPrev;
    public AppCompatImageView imvSelectBgColor;
    public AppCompatImageView imvSelectFont;
    public AppCompatImageView imvSelectFontColor;
    public AppCompatImageView imvShape1;
    public AppCompatImageView imvShape2;
    public AppCompatImageView imvShape3;
    public AppCompatImageView imvShape4;
    public AppCompatImageView imvUnderline;
    public AppCompatImageView imvUndo;
    public boolean isDocLoadCompleted = false;
    public LinearLayoutCompat llAddText;
    public LinearLayoutCompat llAnnotation;
    public LinearLayoutCompat llAuthor;
    public LinearLayout llButtonView;
    public LinearLayoutCompat llDeleteSelection;
    public LinearLayoutCompat llDeleteText;
    public LinearLayoutCompat llDeselect;
    public LinearLayout llDocView;
    public LinearLayoutCompat llDraw;
    public LinearLayoutCompat llDrawOption;
    public LinearLayoutCompat llDrawSubMenu;
    public LinearLayoutCompat llESign;
    public LinearLayoutCompat llEdit;
    public LinearLayoutCompat llFile;
    public LinearLayoutCompat llFind;
    public LinearLayoutCompat llFirstPage;
    public LinearLayoutCompat llFormat;
    public LinearLayoutCompat llFreeze;
    public LinearLayoutCompat llFreezeFirstColumn;
    public LinearLayoutCompat llFreezeFirstRow;
    public LinearLayoutCompat llGetPremium;
    public LinearLayoutCompat llGetText;
    public LinearLayoutCompat llImage;
    public LinearLayoutCompat llInsert;
    public LinearLayoutCompat llLastPage;
    public LinearLayoutCompat llLineColor;
    public LinearLayoutCompat llLineThickness;
    public LinearLayoutCompat llOpen;
    public LinearLayoutCompat llOrganize;
    public LinearLayoutCompat llOverLay;
    public LinearLayoutCompat llPPTtoImage;
    public LinearLayoutCompat llPPTtoPDF;
    public LinearLayoutCompat llPages;
    public LinearLayoutCompat llPhoto;
    public LinearLayoutCompat llPrint;
    public LinearLayoutCompat llReset;
    public LinearLayoutCompat llSave;
    public LinearLayoutCompat llSaveAs;
    public LinearLayoutCompat llSaveAsPDF;
    public LinearLayoutCompat llScale;
    public LinearLayoutCompat llScaleDown;
    public LinearLayoutCompat llScaleUp;
    public LinearLayoutCompat llScrollDown;
    public LinearLayoutCompat llScrollUp;
    public LinearLayoutCompat llSelection;
    public LinearLayoutCompat llShape;
    public LinearLayoutCompat llShare;
    public LinearLayoutCompat llShowPages;
    public LinearLayoutCompat llSubMenuMain;
    public LinearLayoutCompat llTools;
    public LinearLayoutCompat llWatchVideo;
    public Activity mContext;
    public SODocumentView mDocumentView;
    public float mOriginalScale = -1.0f;
    public Overlay mOverlayDocument;
    public Uri mUri = null;
    public PDFPasswordDialog.OnPPDCallback onPPDCallback;
    public String openedFrom = "";
    public String outputPath = "";
    public String placementId;
    public ProgressDialog progressDialog;
    public String selectFontName = "";
    public String selectMenuTitle = "";
    public boolean startSaveActivityCalled = false;
    public TabLayout tlMenus;
    public Toolbar toolbar;
    public TextView tvDraw;
    public TextView tvEditPPT;
    public TextView txtActivityTitle;
    public TextView txtEditTitle;
    public AppCompatTextView txtFontName;
    public AppCompatTextView txtOR;
    public AppCompatTextView txtShowPages;
    public AppCompatTextView txtTextSize;
    public AppCompatTextView unfreeze;
    public int whatSelected = 0;

    public DocViewActivity() {
        registerForActivityResult(new ActivityResultContracts$StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            public void onActivityResult(Object obj) {
                ActivityResult activityResult = (ActivityResult) obj;
                if (activityResult.mResultCode == -1) {
                    Uri data = activityResult.mData.getData();
                    DocViewActivity docViewActivity = DocViewActivity.this;
                    docViewActivity.mUri = data;
                    Cursor cursor = null;
                    try {
                        Cursor query = docViewActivity.getContentResolver().query(data, new String[]{"_data"}, (String) null, (String[]) null, (String) null);
                        int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
                        query.moveToFirst();
                        String string = query.getString(columnIndexOrThrow);
                        query.close();
                        docViewActivity.filePath = string;
                        DocViewActivity.this.allDocControllerInit();
                    } catch (Throwable th) {
                        if (cursor != null) {
                            cursor.close();
                        }
                        throw th;
                    }
                }
            }
        });
        this.editorToolOnClickListener = new EditorToolsAdapter.EditorToolOnClickListener() {
            /* JADX WARNING: Can't fix incorrect switch cases order */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void editorToolOnClick(java.lang.String r13) {
                /*
                    r12 = this;
                    com.analytics_lite.analytics.analytic.AnalyticsHelp r0 = com.analytics_lite.analytics.analytic.AnalyticsHelp.getInstance()
                    java.lang.String r1 = "event_app_editor_bottom_tools_"
                    java.lang.String r2 = "_pressed"
                    r3 = 0
                    billing.helper.BillingHelp$$ExternalSyntheticOutline0.m(r1, r13, r2, r0, r3)
                    java.util.Objects.requireNonNull(r13)
                    int r0 = r13.hashCode()
                    r1 = 1
                    r2 = 0
                    r3 = 8
                    java.lang.String r4 = "Compress PDF"
                    java.lang.String r5 = "Split PDF"
                    java.lang.String r6 = "PDF to Image"
                    switch(r0) {
                        case -2053846300: goto L_0x0079;
                        case -1888231764: goto L_0x0070;
                        case -1293553779: goto L_0x0065;
                        case 85869743: goto L_0x005a;
                        case 291526486: goto L_0x004f;
                        case 907236116: goto L_0x0044;
                        case 907280973: goto L_0x0039;
                        case 1106729448: goto L_0x002e;
                        case 1603960628: goto L_0x0022;
                        default: goto L_0x0020;
                    }
                L_0x0020:
                    goto L_0x0082
                L_0x0022:
                    boolean r13 = r13.equals(r4)
                    if (r13 != 0) goto L_0x002a
                    goto L_0x0082
                L_0x002a:
                    r13 = 8
                    goto L_0x0083
                L_0x002e:
                    java.lang.String r0 = "Bold Text"
                    boolean r13 = r13.equals(r0)
                    if (r13 != 0) goto L_0x0037
                    goto L_0x0082
                L_0x0037:
                    r13 = 7
                    goto L_0x0083
                L_0x0039:
                    java.lang.String r0 = "Text Type"
                    boolean r13 = r13.equals(r0)
                    if (r13 != 0) goto L_0x0042
                    goto L_0x0082
                L_0x0042:
                    r13 = 6
                    goto L_0x0083
                L_0x0044:
                    java.lang.String r0 = "Text Size"
                    boolean r13 = r13.equals(r0)
                    if (r13 != 0) goto L_0x004d
                    goto L_0x0082
                L_0x004d:
                    r13 = 5
                    goto L_0x0083
                L_0x004f:
                    java.lang.String r0 = "Excel to PDF"
                    boolean r13 = r13.equals(r0)
                    if (r13 != 0) goto L_0x0058
                    goto L_0x0082
                L_0x0058:
                    r13 = 4
                    goto L_0x0083
                L_0x005a:
                    java.lang.String r0 = "E Signature PDF"
                    boolean r13 = r13.equals(r0)
                    if (r13 != 0) goto L_0x0063
                    goto L_0x0082
                L_0x0063:
                    r13 = 3
                    goto L_0x0083
                L_0x0065:
                    java.lang.String r0 = "Docx To Pdf"
                    boolean r13 = r13.equals(r0)
                    if (r13 != 0) goto L_0x006e
                    goto L_0x0082
                L_0x006e:
                    r13 = 2
                    goto L_0x0083
                L_0x0070:
                    boolean r13 = r13.equals(r5)
                    if (r13 != 0) goto L_0x0077
                    goto L_0x0082
                L_0x0077:
                    r13 = 1
                    goto L_0x0083
                L_0x0079:
                    boolean r13 = r13.equals(r6)
                    if (r13 != 0) goto L_0x0080
                    goto L_0x0082
                L_0x0080:
                    r13 = 0
                    goto L_0x0083
                L_0x0082:
                    r13 = -1
                L_0x0083:
                    java.lang.String r0 = "com.rpdev.docreadermainV2.activity.pdfTools.ToolsViewActivity"
                    switch(r13) {
                        case 0: goto L_0x0115;
                        case 1: goto L_0x010d;
                        case 2: goto L_0x00de;
                        case 3: goto L_0x00d6;
                        case 4: goto L_0x00ce;
                        case 5: goto L_0x00b5;
                        case 6: goto L_0x00ad;
                        case 7: goto L_0x0093;
                        case 8: goto L_0x008a;
                        default: goto L_0x0088;
                    }
                L_0x0088:
                    goto L_0x011c
                L_0x008a:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    boolean r1 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.isSetup
                    r13.redirectToTool(r0, r4)
                    goto L_0x011c
                L_0x0093:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    boolean r0 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.isSetup
                    java.lang.String r0 = "bold"
                    r13.callEvents(r0)
                    com.artifex.sonui.editor.SODocumentView r0 = r13.mDocumentView
                    if (r0 == 0) goto L_0x00a8
                    boolean r2 = r0.getSelectionIsBold()
                    r1 = r1 ^ r2
                    r0.setSelectionIsBold(r1)
                L_0x00a8:
                    r13.updateUI()
                    goto L_0x011c
                L_0x00ad:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    boolean r0 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.isSetup
                    r13.imvSelectFont()
                    goto L_0x011c
                L_0x00b5:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    r0 = 2131430354(0x7f0b0bd2, float:1.8482407E38)
                    android.view.View r13 = r13.findViewById(r0)
                    android.widget.LinearLayout r13 = (android.widget.LinearLayout) r13
                    int r0 = r13.getVisibility()
                    if (r0 != 0) goto L_0x00ca
                    r13.setVisibility(r3)
                    goto L_0x011c
                L_0x00ca:
                    r13.setVisibility(r2)
                    goto L_0x011c
                L_0x00ce:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    r13.whatSelected = r1
                    r13.saveAsPdf()
                    goto L_0x011c
                L_0x00d6:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    boolean r0 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.isSetup
                    r13.eSignPDF()
                    goto L_0x011c
                L_0x00de:
                    billing.helper.BillingHelp r13 = billing.helper.BillingHelp.INSTANCE
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r0 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    android.app.Activity r0 = r0.mContext
                    boolean r0 = r13.isPremiumEnabled(r0)
                    if (r0 == 0) goto L_0x00f8
                    boolean r13 = r13.isPremium()
                    if (r13 == 0) goto L_0x00f8
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    r13.whatSelected = r1
                    r13.saveAsPdf()
                    goto L_0x011c
                L_0x00f8:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r2 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    android.app.Activity r3 = r2.mContext
                    r6 = 0
                    r7 = 0
                    java.lang.String r9 = r2.fileExt
                    r11 = 0
                    java.lang.String r4 = "docx_to_pdf_android"
                    java.lang.String r5 = "redirect_to_docx_to_pdf"
                    java.lang.String r8 = "docx_to_pdf"
                    java.lang.String r10 = " To convert Docx To PDF "
                    r2.showEditFileDialog(r3, r4, r5, r6, r7, r8, r9, r10, r11)
                    goto L_0x011c
                L_0x010d:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    boolean r1 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.isSetup
                    r13.redirectToTool(r0, r5)
                    goto L_0x011c
                L_0x0115:
                    com.artifex.sonui.artifactsdk.activity.DocViewActivity r13 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.this
                    boolean r1 = com.artifex.sonui.artifactsdk.activity.DocViewActivity.isSetup
                    r13.redirectToTool(r0, r6)
                L_0x011c:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass31.editorToolOnClick(java.lang.String):void");
            }
        };
        this.onPPDCallback = new PDFPasswordDialog.OnPPDCallback() {
            public void onSuccess(boolean z, String str) {
                if (z) {
                    DocViewActivity.this.mDocumentView.providePassword(str);
                } else {
                    DocViewActivity.this.onBackPressed();
                }
            }
        };
    }

    public static void access$000(DocViewActivity docViewActivity) {
        docViewActivity.callEvents("font_plus");
        SODocumentView sODocumentView = docViewActivity.mDocumentView;
        if (sODocumentView != null) {
            double selectionFontSize = sODocumentView.getSelectionFontSize();
            if (selectionFontSize > 0.0d) {
                docViewActivity.mDocumentView.setSelectionFontSize(selectionFontSize + 1.0d);
            }
        }
        docViewActivity.updateUI();
    }

    public static void access$100(DocViewActivity docViewActivity) {
        docViewActivity.callEvents("font_minus");
        SODocumentView sODocumentView = docViewActivity.mDocumentView;
        if (sODocumentView != null) {
            double selectionFontSize = sODocumentView.getSelectionFontSize();
            if (selectionFontSize > 0.0d) {
                docViewActivity.mDocumentView.setSelectionFontSize(selectionFontSize - 1.0d);
            }
        }
        docViewActivity.updateUI();
    }

    public static void access$2000(DocViewActivity docViewActivity) {
        if (docViewActivity.mDocumentView != null) {
            try {
                if (docViewActivity.fileType.endsWith(".pdf")) {
                    Activity activity = docViewActivity.mContext;
                    Uri uriForFile = FileProvider.getUriForFile(activity, docViewActivity.getApplicationContext().getPackageName() + ".provider", new File(docViewActivity.filePath));
                    Intent intent = new Intent(docViewActivity.mContext, ToolsViewActivity.class);
                    intent.setData(uriForFile);
                    if (uriForFile != null) {
                        intent.putExtra("cache_file_uri", uriForFile.toString());
                    }
                    intent.putExtra("TOOL_TAG", "pdf_to_images");
                    intent.putExtra("isFromPreview", true);
                    intent.putExtra("from_app", true);
                    docViewActivity.showInterAds("actionBaseClick", true, intent, IntentRedirectionConstants.PRINT_REDIRECTION_REQUEST_CODE.intValue());
                } else {
                    docViewActivity.mDocumentView.print();
                }
            } catch (Exception unused) {
            }
        }
        docViewActivity.updateUI();
    }

    public static void access$2100(DocViewActivity docViewActivity) {
        docViewActivity.callEvents(AppLovinEventTypes.USER_SHARED_LINK);
        SODocumentView sODocumentView = docViewActivity.mDocumentView;
        if (sODocumentView == null) {
            return;
        }
        if (sODocumentView.isDocumentModified()) {
            BillingHelp billingHelp = BillingHelp.INSTANCE;
            if (!billingHelp.isPremiumEnabled(docViewActivity.mContext) || !billingHelp.isPremium()) {
                docViewActivity.showEditFileDialog(docViewActivity.mContext, docViewActivity.placementId, (String) null, (String) null, (Intent) null, AppLovinEventTypes.USER_SHARED_LINK, docViewActivity.fileExt, "To share your document", false);
                return;
            }
            docViewActivity.mDocumentView.saveTo(docViewActivity.filePath, new SODocSaveListener() {
                public void onComplete(int i, int i2) {
                    Activity activity = DocViewActivity.this.mContext;
                    ShareFileHelper.getInstance().shareFile(DocViewActivity.this.mContext, new File(DocViewActivity.this.filePath).getName(), new File(DocViewActivity.this.filePath).getAbsolutePath(), FileProvider.getUriForFile(activity, DocViewActivity.this.getApplicationContext().getPackageName() + ".provider", new File(DocViewActivity.this.filePath)));
                }
            });
            return;
        }
        Activity activity = docViewActivity.mContext;
        ShareFileHelper.getInstance().shareFile(docViewActivity.mContext, new File(docViewActivity.filePath).getName(), docViewActivity.filePath, FileProvider.getUriForFile(activity, docViewActivity.getApplicationContext().getPackageName() + ".provider", new File(docViewActivity.filePath)));
    }

    public static void access$2300(DocViewActivity docViewActivity) {
        docViewActivity.callEvents("undo");
        SODocumentView sODocumentView = docViewActivity.mDocumentView;
        if (sODocumentView != null) {
            sODocumentView.undo();
        }
        docViewActivity.updateUI();
    }

    public static void access$2400(DocViewActivity docViewActivity) {
        docViewActivity.callEvents("redo");
        SODocumentView sODocumentView = docViewActivity.mDocumentView;
        if (sODocumentView != null) {
            sODocumentView.redo();
        }
        docViewActivity.updateUI();
    }

    public static void access$5200(DocViewActivity docViewActivity) {
        if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_file, docViewActivity.selectMenuTitle)) {
            docViewActivity.menuFile();
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_edit, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llEdit.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_tools, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llTools.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_insert, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llInsert.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_format, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llFormat.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_draw, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llDraw.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_slides, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_pages, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llPages.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_annotate, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llAnnotation.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_selection, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llSelection.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_scale, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llScale.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_organize, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llOrganize.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_find, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llFind.setVisibility(0);
        } else if (DocViewActivity$82$$ExternalSyntheticOutline0.m(docViewActivity, R.string.menu_freeze, docViewActivity.selectMenuTitle)) {
            docViewActivity.hideSubMenus();
            docViewActivity.llFreeze.setVisibility(0);
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Can't wrap try/catch for region: R(38:202|203|204|(5:206|207|208|209|210)|214|(1:216)|217|(2:224|(2:226|(1:228)(1:229))(1:230))(1:223)|231|(1:233)|234|(1:236)(1:237)|238|(1:240)|241|(1:245)|246|(1:250)|251|(1:253)|254|(1:260)|261|(1:263)|264|(1:266)|267|(1:269)(1:270)|271|(1:273)|274|(2:276|(2:278|(1:300))(1:301))|302|(1:304)|305|(1:307)|308|309) */
    /* JADX WARNING: Code restructure failed: missing block: B:102:0x02dd, code lost:
        r1 = 65535;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:103:0x02de, code lost:
        switch(r1) {
            case 0: goto L_0x02f8;
            case 1: goto L_0x02ef;
            case 2: goto L_0x02ef;
            case 3: goto L_0x02e6;
            case 4: goto L_0x02e6;
            case 5: goto L_0x02e6;
            case 6: goto L_0x02e6;
            case 7: goto L_0x02e6;
            case 8: goto L_0x02f8;
            case 9: goto L_0x02ef;
            case 10: goto L_0x02ef;
            case 11: goto L_0x02ef;
            case 12: goto L_0x02e6;
            case 13: goto L_0x02e6;
            case 14: goto L_0x02e6;
            case 15: goto L_0x02e6;
            case 16: goto L_0x02e6;
            case 17: goto L_0x02e6;
            case 18: goto L_0x02e6;
            case 19: goto L_0x02f8;
            case 20: goto L_0x02f8;
            case 21: goto L_0x02f8;
            case 22: goto L_0x02f8;
            case 23: goto L_0x02f8;
            case 24: goto L_0x02f8;
            default: goto L_0x02e1;
        };
     */
    /* JADX WARNING: Code restructure failed: missing block: B:104:0x02e1, code lost:
        r18 = r13;
        r13 = r33;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:105:0x02e6, code lost:
        r18 = r13;
        r13 = r33;
        r13.placementId = "editor_pro_dialog_ppt_android";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:106:0x02ef, code lost:
        r18 = r13;
        r13 = r33;
        r13.placementId = "editor_pro_dialog_docx_android";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:107:0x02f8, code lost:
        r18 = r13;
        r13 = r33;
        r13.placementId = "editor_pro_dialog_xls_android";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:108:0x0300, code lost:
        r13.fabEdit = (com.github.clans.fab.FloatingActionButton) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.fabEdit);
        r13.tlMenus = (com.google.android.material.tabs.TabLayout) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.tlMenus);
        r13.llSubMenuMain = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llSubMenuMain);
        r29 = r6;
        r13.llDocView.setVisibility(0);
        r13.llButtonView.setVisibility(8);
        r13.txtActivityTitle.setText("");
        r1 = r13.txtActivityTitle;
        r6 = a.a.a.a.a.c$$ExternalSyntheticOutline0.m("");
        r30 = ".ppsm";
        r6.append(r13.fileName);
        r1.setText(r6.toString());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:109:0x034d, code lost:
        if (r13.fileType != null) goto L_0x0355;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:10:0x008c, code lost:
        r24 = ".xlsb";
        r6 = r23;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:110:0x034f, code lost:
        r13.fileType = checkFileType();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:111:0x0355, code lost:
        r31 = ".pdf";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x0363, code lost:
        if (r13.fileType.endsWith(".pdf") == false) goto L_0x0369;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:113:0x0365, code lost:
        r1 = com.rpdev.document.manager.reader.allfiles.R.color.pdfColor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:115:0x036f, code lost:
        if (r13.fileType.endsWith(r7) != false) goto L_0x04fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0377, code lost:
        if (r13.fileType.endsWith(r5) != false) goto L_0x04fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:119:0x037f, code lost:
        if (r13.fileType.endsWith(r4) != false) goto L_0x04fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0090, code lost:
        r23 = ".xlsm";
        r5 = r19;
        r19 = ".ppam";
        r13 = r18;
        r32 = r22;
        r22 = ".xlsx";
        r8 = r20;
        r20 = r32;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x0387, code lost:
        if (r13.fileType.endsWith(".dot") != false) goto L_0x04fc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:123:0x038f, code lost:
        if (r13.fileType.endsWith(r3) == false) goto L_0x0393;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:125:0x0399, code lost:
        if (r13.fileType.endsWith(".txt") == false) goto L_0x03ac;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:126:0x039b, code lost:
        r1 = com.rpdev.document.manager.reader.allfiles.R.color.text_color;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x039e, code lost:
        r7 = r22;
        r4 = r25;
        r5 = r26;
        r23 = r29;
        r2 = r30;
        r22 = r20;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x03b2, code lost:
        if (r13.fileType.endsWith(".pptx") != false) goto L_0x04ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:131:0x03ba, code lost:
        if (r13.fileType.endsWith(".pptm") != false) goto L_0x04ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:133:0x03c2, code lost:
        if (r13.fileType.endsWith(r0) != false) goto L_0x04ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:135:0x03ca, code lost:
        if (r13.fileType.endsWith(".potx") != false) goto L_0x04ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:137:0x03d2, code lost:
        if (r13.fileType.endsWith(".potm") != false) goto L_0x04ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:139:0x03da, code lost:
        if (r13.fileType.endsWith(r8) != false) goto L_0x04ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:141:0x03e2, code lost:
        if (r13.fileType.endsWith(".ppsx") != false) goto L_0x04ed;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:142:0x03e4, code lost:
        r2 = r30;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:143:0x03ec, code lost:
        if (r13.fileType.endsWith(r2) != false) goto L_0x04e2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:144:0x03ee, code lost:
        r3 = r29;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:145:0x03f6, code lost:
        if (r13.fileType.endsWith(r3) != false) goto L_0x04d9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:146:0x03f8, code lost:
        r4 = r19;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:147:0x0400, code lost:
        if (r13.fileType.endsWith(r4) != false) goto L_0x04d4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:148:0x0402, code lost:
        r5 = r20;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:149:0x040a, code lost:
        if (r13.fileType.endsWith(r5) != false) goto L_0x04c7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:150:0x040c, code lost:
        r7 = r21;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:151:0x0414, code lost:
        if (r13.fileType.endsWith(r7) == false) goto L_0x041e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:152:0x0416, code lost:
        r23 = r3;
        r19 = r4;
        r21 = r7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:153:0x041e, code lost:
        r21 = r7;
        r7 = r22;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:154:0x0428, code lost:
        if (r13.fileType.endsWith(r7) != false) goto L_0x04bc;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:155:0x042a, code lost:
        r22 = r5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:156:0x0434, code lost:
        if (r13.fileType.endsWith(r23) != false) goto L_0x04b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:158:0x043e, code lost:
        if (r13.fileType.endsWith(r24) != false) goto L_0x04b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:160:0x0448, code lost:
        if (r13.fileType.endsWith(r28) != false) goto L_0x04b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:162:0x0452, code lost:
        if (r13.fileType.endsWith(r27) != false) goto L_0x04b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:163:0x0454, code lost:
        r5 = r26;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:164:0x045c, code lost:
        if (r13.fileType.endsWith(r5) != false) goto L_0x04ac;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:165:0x045e, code lost:
        r19 = r4;
        r4 = r25;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:166:0x0468, code lost:
        if (r13.fileType.endsWith(r4) == false) goto L_0x046d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:167:0x046a, code lost:
        r23 = r3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:168:0x046d, code lost:
        r23 = r3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:169:0x0477, code lost:
        if (r13.fileType.endsWith(r18) == false) goto L_0x047a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:171:0x0480, code lost:
        if (r13.fileType.endsWith(".html") == false) goto L_0x0483;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:173:0x048b, code lost:
        if (r13.fileType.endsWith(".png") != false) goto L_0x04a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:175:0x0495, code lost:
        if (r13.fileType.endsWith(".jpg") != false) goto L_0x04a7;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:177:0x049f, code lost:
        if (r13.fileType.endsWith(".jpeg") == false) goto L_0x04a2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:178:0x04a2, code lost:
        r1 = com.rpdev.document.manager.reader.allfiles.R.color.colorPrimary;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:179:0x04a7, code lost:
        r1 = com.rpdev.document.manager.reader.allfiles.R.color.imageColor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:180:0x04ac, code lost:
        r23 = r3;
        r19 = r4;
        r4 = r25;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:181:0x04b3, code lost:
        r23 = r3;
        r19 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:182:0x04b7, code lost:
        r4 = r25;
        r5 = r26;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:183:0x04bc, code lost:
        r23 = r3;
        r19 = r4;
        r22 = r5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:184:0x04c3, code lost:
        r1 = com.rpdev.document.manager.reader.allfiles.R.color.excelColor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:185:0x04c7, code lost:
        r23 = r3;
        r19 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:186:0x04cb, code lost:
        r7 = r22;
        r4 = r25;
        r22 = r5;
        r5 = r26;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:187:0x04d4, code lost:
        r23 = r3;
        r19 = r4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:188:0x04d9, code lost:
        r23 = r3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:189:0x04db, code lost:
        r7 = r22;
        r4 = r25;
        r5 = r26;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:190:0x04e2, code lost:
        r7 = r22;
        r4 = r25;
        r5 = r26;
        r23 = r29;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:191:0x04ea, code lost:
        r22 = r20;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:192:0x04ed, code lost:
        r7 = r22;
        r4 = r25;
        r5 = r26;
        r23 = r29;
        r2 = r30;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:193:0x04f8, code lost:
        r1 = com.rpdev.document.manager.reader.allfiles.R.color.pptColor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:194:0x04fc, code lost:
        r7 = r22;
        r4 = r25;
        r5 = r26;
        r23 = r29;
        r2 = r30;
        r22 = r20;
        r1 = com.rpdev.document.manager.reader.allfiles.R.color.docColor;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:196:?, code lost:
        r3 = getWindow();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:197:0x050f, code lost:
        r30 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:199:?, code lost:
        r3.clearFlags(67108864);
        r3.addFlags(Integer.MIN_VALUE);
        r3.setStatusBarColor(androidx.core.content.ContextCompat.getColor(r13, r1));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:200:0x0523, code lost:
        r30 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:203:?, code lost:
        r13.toolbar.setBackgroundColor(getResources().getColor(r1));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:204:0x0532, code lost:
        r1 = (android.widget.RelativeLayout) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.rlDocContainer);
        r2 = new com.artifex.sonui.editor.SODocumentView(r13);
        r13.mDocumentView = r2;
        r18 = ".ppsx";
        ((android.widget.RelativeLayout) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.soDocViewLayout)).addView(r2, new android.view.ViewGroup.LayoutParams(-1, -1));
        r13.mOverlayDocument = (com.artifex.sonui.artifactsdk.utilitiesEditorSdk.Overlay) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.overlayDoc);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:207:?, code lost:
        r2 = androidx.transition.ViewUtilsBase.getInstance();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:208:0x057b, code lost:
        r20 = r8;
        r8 = r17;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:210:?, code lost:
        r2.executeLogEventPath("event_app_editor_document_loading_start_" + r13.fileExt, r8, (java.lang.String) null, r13.filePath);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:212:0x0585, code lost:
        r20 = r8;
        r8 = r17;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:214:0x0589, code lost:
        r13.mOverlayDocument.setDocView(r13.mDocumentView);
        r2 = r13.mDocumentView;
        r13.configOptions = com.artifex.solib.ArDkLib.getAppConfigOptions();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:215:0x059a, code lost:
        if (r13.fileType == null) goto L_0x059c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:216:0x059c, code lost:
        r13.fileType = checkFileType();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:218:0x05aa, code lost:
        if (r13.fileType.endsWith(r31) != false) goto L_0x05cb;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:223:0x05bd, code lost:
        r13.configOptions.setEditingEnabled(true);
        r13.fabEdit.setVisibility(8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:224:0x05cb, code lost:
        r13.configOptions.setEditingEnabled(false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:225:0x05d3, code lost:
        if (r13.fileName != null) goto L_0x05d5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:227:0x05db, code lost:
        if (r13.fileType.endsWith(".txt") != false) goto L_0x05dd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:228:0x05dd, code lost:
        r13.fabEdit.setVisibility(8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:229:0x05e5, code lost:
        r13.fabEdit.setVisibility(0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:230:0x05eb, code lost:
        com.analytics_lite.analytics.analytic.AnalyticsHelp.getInstance().logEvent("event_app_file_name_null", (java.util.Map<java.lang.String, java.lang.String>) null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:231:0x05f4, code lost:
        r2.setDocConfigOptions(r13.configOptions);
        r13.mDocumentView.setDocDataLeakHandler(com.artifex.sonui.editor.Utilities.getDataLeakHandlers());
        r13.mDocumentView.setPageChangeListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass5(r13));
        r13.mDocumentView.setDocumentListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass6(r13));
        r13.mDocumentView.setDocStateListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass7(r13));
        r1 = android.net.Uri.fromFile(new java.io.File(r13.filePath));
        r13.mUri = r1;
        r13.mDocumentView.start(r1, 0, false);
        r13.llFile = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llFile);
        r13.llOpen = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llOpen);
        r13.llSave = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llSave);
        r13.llSaveAs = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llSaveAs);
        r13.llSaveAsPDF = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llSaveAsPDF);
        r13.llPrint = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llPrint);
        r13.llShare = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llShare);
        r13.llOpen.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass8(r13));
        r13.llSave.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass9(r13));
        r13.llSaveAs.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass10(r13));
        r13.llSaveAsPDF.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass11(r13));
        r13.llPrint.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass12(r13));
        r13.llShare.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass13(r13));
        r13.llEdit = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llEdit);
        r13.imvUndo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvUndo);
        r13.imvRedo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvRedo);
        r13.txtFontName = (androidx.appcompat.widget.AppCompatTextView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.txtFontName);
        r13.imvSelectFont = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvSelectFont);
        r13.imvFontPlus = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvFontPlus);
        r13.txtTextSize = (androidx.appcompat.widget.AppCompatTextView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.txtTextSize);
        r13.bottomTextSize = (androidx.appcompat.widget.AppCompatTextView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.bottomViewTextSize);
        r13.imvFontMinus = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvFontMinus);
        r13.imvBold = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvBold);
        r13.imvItalic = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvItalic);
        r13.imvUnderline = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvUnderline);
        r1 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvBgColor);
        r13.imvSelectBgColor = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvSelectBgColor);
        r1 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvFontColor);
        r13.imvSelectFontColor = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvSelectFontColor);
        r13.imvUndo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass17(r13));
        r13.imvRedo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass18(r13));
        r13.txtFontName.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass19(r13));
        r13.imvSelectFont.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass20(r13));
        r13.imvFontPlus.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass21(r13));
        r13.imvFontMinus.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass22(r13));
        r13.imvBold.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass23(r13));
        r13.imvItalic.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass24(r13));
        r13.imvUnderline.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass25(r13));
        r13.imvSelectBgColor.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass26(r13));
        r13.imvSelectFontColor.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass27(r13));
        r13.llTools = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llTools);
        r13.llPPTtoPDF = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llPPTtoPDF);
        r13.llESign = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llESign);
        r13.llPPTtoImage = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llPPTtoImage);
        r13.editorToolsRecycler = (androidx.recyclerview.widget.RecyclerView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.editorToolsRecyclerView);
        r13.bottomToolsRecycler = (androidx.recyclerview.widget.RecyclerView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.bottomToolsRecyclerView);
        r13.llPPTtoPDF.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass28(r13));
        r13.llESign.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass29(r13));
        r13.llPPTtoImage.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass30(r13));
        r13.fileType = checkFileType();
        com.arasthel.asyncjob.AsyncJob.doInBackground(new com.applovin.exoplayer2.h.u$a$$ExternalSyntheticLambda0(r13));
        r13.llInsert = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llInsert);
        r13.imvInsertUndo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvInsertUndo);
        r13.imvInsertRedo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvInsertRedo);
        r13.llImage = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llImage);
        r13.llPhoto = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llPhoto);
        r13.llShape = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llShape);
        r13.imvInsertUndo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass32(r13));
        r13.imvInsertRedo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass33(r13));
        r13.llImage.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass34(r13));
        r13.llPhoto.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass35(r13));
        r13.llShape.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass36(r13));
        r13.llFormat = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llFormat);
        r13.imvFormatUndo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvFormatUndo);
        r13.imvFormatRedo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvFormatRedo);
        r13.imvShape1 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvShape1);
        r13.imvShape2 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvShape2);
        r13.imvShape3 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvShape3);
        r13.imvShape4 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvShape4);
        r13.imvArrange1 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvArrange1);
        r13.imvArrange2 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvArrange2);
        r13.imvArrange3 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvArrange3);
        r13.imvArrange4 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvArrange4);
        r13.imvFormatUndo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass37(r13));
        r13.imvFormatRedo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass38(r13));
        r13.imvShape1.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass39(r13));
        r13.imvShape2.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass40(r13));
        r13.imvShape3.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass41(r13));
        r13.imvShape4.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass42(r13));
        r13.imvArrange1.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass43(r13));
        r13.imvArrange2.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass44(r13));
        r13.imvArrange3.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass45(r13));
        r13.imvArrange4.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass46(r13));
        r13.llDraw = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llDraw);
        r13.imvDrawUndo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvDrawUndo);
        r13.imvDrawRedo = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvDrawRedo);
        r13.llDrawOption = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llDrawOption);
        r1 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvDrawBgColor);
        r13.imvDrawSelectBgColor = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvDrawSelectBgColor);
        r1 = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvDrawAlignment);
        r13.imvDrawSelectAlignment = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvDrawSelectAlignment);
        r13.imvDrawUndo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass47(r13));
        r13.imvDrawRedo.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass48(r13));
        r13.llDrawOption.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass49(r13));
        r13.imvDrawSelectBgColor.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass50(r13));
        r13.imvDrawSelectAlignment.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass51(r13));
        r13.llDrawSubMenu = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llDrawSubMenu);
        r13.tvDraw = (android.widget.TextView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.tvDraw);
        r13.imgDraw = (android.widget.ImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imgDraw);
        r13.llDeleteSelection = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llDeleteSelection);
        r13.llLineColor = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llLineColor);
        r13.imgLineColor = (android.widget.ImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imgLineColor);
        r13.llLineThickness = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llLineThickness);
        r13.llAuthor = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llAuthor);
        r13.llDrawSubMenu.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass55(r13));
        r13.llDeleteSelection.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass56(r13));
        r13.llLineColor.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass57(r13));
        r13.llLineThickness.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass58(r13));
        r13.llAuthor.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass59(r13));
        r13.llGetText = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llGetText);
        r13.llAddText = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llAddText);
        r13.llDeleteText = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llDeleteText);
        r13.llDeselect = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llDeselect);
        r13.llOverLay = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llOverLay);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:232:0x0ae2, code lost:
        if (r13.configOptions.isEditingEnabled() == false) goto L_0x0ae4;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:233:0x0ae4, code lost:
        r13.llAddText.setVisibility(8);
        r13.llDeleteText.setVisibility(8);
        r13.llDeselect.setVisibility(8);
        r13.llOverLay.setVisibility(8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:234:0x0afa, code lost:
        r13.llGetText.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass60(r13));
        r13.llAddText.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass61(r13));
        r13.llDeleteText.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass62(r13));
        r13.llDeselect.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass63(r13));
        r13.llOverLay.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass64(r13));
        r13.llScaleUp = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llScaleUp);
        r13.llScaleDown = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llScaleDown);
        r13.llScrollUp = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llScrollUp);
        r13.llScrollDown = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llScrollDown);
        r1 = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llReset);
        r13.llReset = r1;
        r1.setVisibility(8);
        r13.llScaleUp.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass65(r13));
        r13.llScaleDown.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass66(r13));
        r13.llScrollUp.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass67(r13));
        r13.llScrollDown.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass68(r13));
        r13.llReset.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass69(r13));
        r13.llPages = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llPages);
        r13.llShowPages = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llShowPages);
        r13.txtShowPages = (androidx.appcompat.widget.AppCompatTextView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.txtShowPages);
        r13.llFirstPage = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llFirstPage);
        r13.llLastPage = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llLastPage);
        r13.llScale = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llScale);
        r13.llAnnotation = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llAnnotation);
        r13.llSelection = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llSelection);
        r13.llShowPages.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass52(r13));
        r13.llFirstPage.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass53(r13));
        r13.llLastPage.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass54(r13));
        r13.llOrganize = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llOrganize);
        ((androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llAddLabelToFile)).setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass70(r13));
        r13.llFind = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llFind);
        r13.eTextSearch = (androidx.appcompat.widget.AppCompatEditText) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.eTextSearch);
        r13.imvClear = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvClear);
        r13.imvSearchPrev = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvSearchPrev);
        r13.imvSearchForward = (androidx.appcompat.widget.AppCompatImageView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.imvSearchForward);
        r13.imvClear.setEnabled(false);
        r13.imvSearchPrev.setEnabled(false);
        r13.imvSearchForward.setEnabled(false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:235:0x0c79, code lost:
        if (r13.mDocumentView.hasSearch() != false) goto L_0x0c7b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:236:0x0c7b, code lost:
        r13.eTextSearch.addTextChangedListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass71(r13));
        r13.imvClear.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass72(r13));
        r13.imvSearchPrev.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass73(r13));
        r13.imvSearchForward.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass74(r13));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:237:0x0ca4, code lost:
        r13.llFind.setEnabled(false);
        r13.eTextSearch.setEnabled(false);
        r13.imvClear.setEnabled(false);
        r13.imvSearchPrev.setEnabled(false);
        r13.imvSearchForward.setEnabled(false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:238:0x0cbe, code lost:
        r13.llFreeze = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llFreeze);
        r13.llFreezeFirstColumn = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llFreezeFirstColumn);
        r13.llFreezeFirstRow = (androidx.appcompat.widget.LinearLayoutCompat) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.llFreezeFirstRow);
        r13.unfreeze = (androidx.appcompat.widget.AppCompatTextView) r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.unfreeze);
        r13.llFreezeFirstColumn.setOnClickListener(new com.rpdev.docreadermainV2.adapter.FileAdapter$$ExternalSyntheticLambda0(r13));
        r13.llFreezeFirstRow.setOnClickListener(new billing.pro.SubscriptionPlan$$ExternalSyntheticLambda2(r13));
        r13.unfreeze.setOnClickListener(new billing.pro.SubscriptionPlan$$ExternalSyntheticLambda1(r13));
        r13.tlMenus.removeAllTabs();
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_file, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:239:0x0d28, code lost:
        if (r13.configOptions.isEditingEnabled() != false) goto L_0x0d2a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:240:0x0d2a, code lost:
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_edit, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:241:0x0d3f, code lost:
        r1 = a.a.a.a.a.c$$ExternalSyntheticOutline0.m(r16);
        r1.append(org.apache.commons.io.FilenameUtils.getExtension(new java.io.File(r13.filePath).getName()));
        r13.fileExt = r1.toString();
        r1 = checkFileType();
        r13.fileType = r1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:245:0x0d77, code lost:
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_tools, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_selection, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:250:0x0db9, code lost:
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_pages, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:252:0x0dd4, code lost:
        if (r13.configOptions.isEditingEnabled() != false) goto L_0x0dd6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:253:0x0dd6, code lost:
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_annotate, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:254:0x0deb, code lost:
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_scale, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_organize, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_find, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:260:0x0e4e, code lost:
        r1 = r13.tlMenus;
        r2 = r1.newTab();
        com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, com.rpdev.document.manager.reader.allfiles.R.string.menu_freeze, r2);
        r1.addTab(r2, r1.tabs.isEmpty());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:261:0x0e63, code lost:
        r1 = r13.tlMenus;
        r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass82(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:262:0x0e70, code lost:
        if (r1.selectedListeners.contains(r2) == false) goto L_0x0e72;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:263:0x0e72, code lost:
        r1.selectedListeners.add(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:264:0x0e77, code lost:
        r13.selectMenuTitle = r13.mContext.getResources().getString(com.rpdev.document.manager.reader.allfiles.R.string.menu_file);
        menuFile();
        r1 = r13.mDocumentView;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:265:0x0e88, code lost:
        if (r1 != null) goto L_0x0e8a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:266:0x0e8a, code lost:
        r1.setOnUpdateUI(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass75(r13));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:267:0x0e92, code lost:
        r13.mDocumentView.hasPages();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:268:0x0e9d, code lost:
        if (r13.mDocumentView.hasUndo() == false) goto L_0x0e9f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:269:0x0e9f, code lost:
        r2 = 8;
        r13.imvUndo.setVisibility(8);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:270:0x0ea7, code lost:
        r2 = 8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:272:0x0eaf, code lost:
        if (r13.mDocumentView.hasRedo() == false) goto L_0x0eb1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:273:0x0eb1, code lost:
        r13.imvRedo.setVisibility(r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:275:0x0ec7, code lost:
        if (r13.getString(com.rpdev.document.manager.reader.allfiles.R.string.app_name).toLowerCase().contains("ppt") != false) goto L_0x0ec9;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:277:0x0ecb, code lost:
        if (r13.fileName != null) goto L_0x0ecd;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:300:0x0f31, code lost:
        r13.fileType.endsWith(r21);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:301:0x0f39, code lost:
        androidx.transition.ViewUtilsBase.getInstance().executeLogEvent("event_app_editor_filename_null", r8, (java.lang.String) null, "null");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:302:0x0f45, code lost:
        r0 = r13.imvFullScreen;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:303:0x0f47, code lost:
        if (r0 != null) goto L_0x0f49;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:304:0x0f49, code lost:
        r0.setVisibility(0);
        r13.imvFullScreen.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass76(r13));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:305:0x0f57, code lost:
        r0 = r13.fabEdit;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:306:0x0f59, code lost:
        if (r0 != null) goto L_0x0f5b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:307:0x0f5b, code lost:
        r0.setOnClickListener(new com.artifex.sonui.artifactsdk.activity.DocViewActivity.AnonymousClass77(r13));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:308:0x0f63, code lost:
        setFabButtonColor();
        r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.bottomAdView).setVisibility(0);
        com.commons_lite.ads_module.ads.control.AdHelpMain.INSTANCE.renderPreloadedBanner(0, r33, r13.findViewById(com.rpdev.document.manager.reader.allfiles.R.id.bottomAdView), false, false);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:309:0x0f80, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x012b, code lost:
        r3 = r26;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x013a, code lost:
        r26 = ".xltx";
        r7 = r27;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x014f, code lost:
        r27 = ".xltm";
        r4 = r28;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:5:0x007e, code lost:
        r3 = r26;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x0168, code lost:
        r28 = ".xlam";
        r0 = r24;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0080, code lost:
        r26 = ".xltx";
        r7 = r27;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:71:0x01b8, code lost:
        r24 = ".xlsb";
        r6 = r23;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:75:0x01d8, code lost:
        r23 = ".xlsm";
        r5 = r22;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0084, code lost:
        r27 = ".xltm";
        r4 = r28;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:80:0x01ff, code lost:
        r22 = ".xlsx";
        r8 = r20;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x0224, code lost:
        r20 = r5;
        r5 = r19;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:0x022b, code lost:
        r20 = r5;
        r5 = r21;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0088, code lost:
        r28 = ".xlam";
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x027b, code lost:
        r1 = 65535;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:93:0x027e, code lost:
        r21 = r5;
        r5 = r19;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:96:0x02a7, code lost:
        r19 = ".ppam";
        r13 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:98:0x02ad, code lost:
        r19 = ".ppam";
        r13 = r18;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x008a, code lost:
        r0 = r24;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:202:0x0525 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void allDocControllerInit() {
        /*
            r33 = this;
            r6 = r33
            java.lang.String r0 = "DocViewActivityArtifact"
            java.lang.String r1 = r6.fileExt
            java.lang.String r2 = "."
            if (r1 != 0) goto L_0x0026
            java.lang.StringBuilder r1 = a.a.a.a.a.c$$ExternalSyntheticOutline0.m(r2)
            java.io.File r3 = new java.io.File
            java.lang.String r4 = r6.filePath
            r3.<init>(r4)
            java.lang.String r3 = r3.getName()
            java.lang.String r3 = org.apache.commons.io.FilenameUtils.getExtension(r3)
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r6.fileExt = r1
        L_0x0026:
            java.lang.String r1 = r6.fileExt
            java.util.Objects.requireNonNull(r1)
            int r3 = r1.hashCode()
            java.lang.String r4 = ".doc"
            java.lang.String r5 = ".csv"
            java.lang.String r7 = ".xltx"
            java.lang.String r8 = ".xlsx"
            java.lang.String r9 = ".pptx"
            java.lang.String r10 = ".pptm"
            java.lang.String r11 = ".ppsx"
            java.lang.String r12 = ".ppsm"
            java.lang.String r13 = ".ppam"
            java.lang.String r14 = ".potx"
            java.lang.String r15 = ".potm"
            r16 = r2
            java.lang.String r2 = ".xls"
            r17 = r0
            java.lang.String r0 = ".ppt"
            java.lang.String r6 = ".pps"
            r18 = r5
            java.lang.String r5 = ".ppa"
            r19 = r4
            java.lang.String r4 = ".pot"
            r20 = r4
            java.lang.String r4 = ".odp"
            r21 = r4
            java.lang.String r4 = ".xltm"
            r22 = r5
            java.lang.String r5 = ".xlsm"
            r23 = r6
            java.lang.String r6 = ".xlsb"
            r24 = r0
            java.lang.String r0 = ".xlam"
            r25 = r2
            java.lang.String r2 = ".dotx"
            r26 = r2
            java.lang.String r2 = ".docx"
            r27 = r2
            java.lang.String r2 = ".docm"
            r28 = r2
            java.lang.String r2 = ".dot"
            switch(r3) {
                case 1469208: goto L_0x02b2;
                case 1470026: goto L_0x0283;
                case 1470043: goto L_0x0257;
                case 1480269: goto L_0x0230;
                case 1481575: goto L_0x0204;
                case 1481587: goto L_0x01dd;
                case 1481605: goto L_0x01bd;
                case 1481606: goto L_0x01a1;
                case 1489169: goto L_0x016d;
                case 45570915: goto L_0x0154;
                case 45570926: goto L_0x013f;
                case 45571453: goto L_0x012e;
                case 45928934: goto L_0x0121;
                case 45928945: goto L_0x0116;
                case 45929306: goto L_0x010b;
                case 45929864: goto L_0x0100;
                case 45929875: goto L_0x00f6;
                case 45929895: goto L_0x00ec;
                case 45929906: goto L_0x00e2;
                case 46163790: goto L_0x00d8;
                case 46164337: goto L_0x00ce;
                case 46164348: goto L_0x00c3;
                case 46164359: goto L_0x00b8;
                case 46164379: goto L_0x00ad;
                case 46164390: goto L_0x00a2;
                default: goto L_0x007e;
            }
        L_0x007e:
            r3 = r26
        L_0x0080:
            r26 = r7
            r7 = r27
        L_0x0084:
            r27 = r4
            r4 = r28
        L_0x0088:
            r28 = r0
        L_0x008a:
            r0 = r24
        L_0x008c:
            r24 = r6
            r6 = r23
        L_0x0090:
            r23 = r5
            r5 = r19
            r19 = r13
            r13 = r18
            r32 = r22
            r22 = r8
            r8 = r20
            r20 = r32
            goto L_0x02dd
        L_0x00a2:
            boolean r1 = r1.equals(r7)
            if (r1 != 0) goto L_0x00a9
            goto L_0x007e
        L_0x00a9:
            r1 = 24
            goto L_0x012b
        L_0x00ad:
            boolean r1 = r1.equals(r4)
            if (r1 != 0) goto L_0x00b4
            goto L_0x007e
        L_0x00b4:
            r1 = 23
            goto L_0x012b
        L_0x00b8:
            boolean r1 = r1.equals(r8)
            if (r1 != 0) goto L_0x00bf
            goto L_0x007e
        L_0x00bf:
            r1 = 22
            goto L_0x012b
        L_0x00c3:
            boolean r1 = r1.equals(r5)
            if (r1 != 0) goto L_0x00ca
            goto L_0x007e
        L_0x00ca:
            r1 = 21
            goto L_0x012b
        L_0x00ce:
            boolean r1 = r1.equals(r6)
            if (r1 != 0) goto L_0x00d5
            goto L_0x007e
        L_0x00d5:
            r1 = 20
            goto L_0x012b
        L_0x00d8:
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x00df
            goto L_0x007e
        L_0x00df:
            r1 = 19
            goto L_0x012b
        L_0x00e2:
            boolean r1 = r1.equals(r9)
            if (r1 != 0) goto L_0x00e9
            goto L_0x007e
        L_0x00e9:
            r1 = 18
            goto L_0x012b
        L_0x00ec:
            boolean r1 = r1.equals(r10)
            if (r1 != 0) goto L_0x00f3
            goto L_0x007e
        L_0x00f3:
            r1 = 17
            goto L_0x012b
        L_0x00f6:
            boolean r1 = r1.equals(r11)
            if (r1 != 0) goto L_0x00fd
            goto L_0x007e
        L_0x00fd:
            r1 = 16
            goto L_0x012b
        L_0x0100:
            boolean r1 = r1.equals(r12)
            if (r1 != 0) goto L_0x0108
            goto L_0x007e
        L_0x0108:
            r1 = 15
            goto L_0x012b
        L_0x010b:
            boolean r1 = r1.equals(r13)
            if (r1 != 0) goto L_0x0113
            goto L_0x007e
        L_0x0113:
            r1 = 14
            goto L_0x012b
        L_0x0116:
            boolean r1 = r1.equals(r14)
            if (r1 != 0) goto L_0x011e
            goto L_0x007e
        L_0x011e:
            r1 = 13
            goto L_0x012b
        L_0x0121:
            boolean r1 = r1.equals(r15)
            if (r1 != 0) goto L_0x0129
            goto L_0x007e
        L_0x0129:
            r1 = 12
        L_0x012b:
            r3 = r26
            goto L_0x013a
        L_0x012e:
            r3 = r26
            boolean r1 = r1.equals(r3)
            if (r1 != 0) goto L_0x0138
            goto L_0x0080
        L_0x0138:
            r1 = 11
        L_0x013a:
            r26 = r7
            r7 = r27
            goto L_0x014f
        L_0x013f:
            r3 = r26
            r26 = r7
            r7 = r27
            boolean r1 = r1.equals(r7)
            if (r1 != 0) goto L_0x014d
            goto L_0x0084
        L_0x014d:
            r1 = 10
        L_0x014f:
            r27 = r4
            r4 = r28
            goto L_0x0168
        L_0x0154:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            boolean r1 = r1.equals(r4)
            if (r1 != 0) goto L_0x0166
            goto L_0x0088
        L_0x0166:
            r1 = 9
        L_0x0168:
            r28 = r0
            r0 = r24
            goto L_0x01b8
        L_0x016d:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r25
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x0185
            r25 = r0
            goto L_0x008a
        L_0x0185:
            r1 = 8
            r25 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            r23 = r5
            r5 = r19
            r19 = r13
            r13 = r18
            r32 = r22
            r22 = r8
            r8 = r20
            r20 = r32
            goto L_0x02de
        L_0x01a1:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            boolean r1 = r1.equals(r0)
            if (r1 != 0) goto L_0x01b7
            goto L_0x008c
        L_0x01b7:
            r1 = 7
        L_0x01b8:
            r24 = r6
            r6 = r23
            goto L_0x01d8
        L_0x01bd:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            boolean r1 = r1.equals(r6)
            if (r1 != 0) goto L_0x01d7
            goto L_0x0090
        L_0x01d7:
            r1 = 6
        L_0x01d8:
            r23 = r5
            r5 = r22
            goto L_0x01ff
        L_0x01dd:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            r23 = r5
            r5 = r22
            boolean r1 = r1.equals(r5)
            if (r1 != 0) goto L_0x01fe
            r22 = r8
            r8 = r20
            goto L_0x0224
        L_0x01fe:
            r1 = 5
        L_0x01ff:
            r22 = r8
            r8 = r20
            goto L_0x022b
        L_0x0204:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            r23 = r5
            r5 = r22
            r22 = r8
            r8 = r20
            boolean r1 = r1.equals(r8)
            if (r1 != 0) goto L_0x022a
        L_0x0224:
            r20 = r5
            r5 = r19
            goto L_0x02a7
        L_0x022a:
            r1 = 4
        L_0x022b:
            r20 = r5
            r5 = r21
            goto L_0x027e
        L_0x0230:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            r23 = r5
            r5 = r21
            r32 = r22
            r22 = r8
            r8 = r20
            r20 = r32
            boolean r1 = r1.equals(r5)
            if (r1 != 0) goto L_0x0255
            goto L_0x027b
        L_0x0255:
            r1 = 3
            goto L_0x027e
        L_0x0257:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            r23 = r5
            r5 = r21
            r32 = r22
            r22 = r8
            r8 = r20
            r20 = r32
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x027d
        L_0x027b:
            r1 = -1
            goto L_0x027e
        L_0x027d:
            r1 = 2
        L_0x027e:
            r21 = r5
            r5 = r19
            goto L_0x02ad
        L_0x0283:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            r23 = r5
            r5 = r19
            r32 = r22
            r22 = r8
            r8 = r20
            r20 = r32
            boolean r1 = r1.equals(r5)
            if (r1 != 0) goto L_0x02ac
        L_0x02a7:
            r19 = r13
            r13 = r18
            goto L_0x02dd
        L_0x02ac:
            r1 = 1
        L_0x02ad:
            r19 = r13
            r13 = r18
            goto L_0x02de
        L_0x02b2:
            r3 = r26
            r26 = r7
            r7 = r27
            r27 = r4
            r4 = r28
            r28 = r0
            r0 = r24
            r24 = r6
            r6 = r23
            r23 = r5
            r5 = r19
            r19 = r13
            r13 = r18
            r32 = r22
            r22 = r8
            r8 = r20
            r20 = r32
            boolean r1 = r1.equals(r13)
            if (r1 != 0) goto L_0x02db
            goto L_0x02dd
        L_0x02db:
            r1 = 0
            goto L_0x02de
        L_0x02dd:
            r1 = -1
        L_0x02de:
            switch(r1) {
                case 0: goto L_0x02f8;
                case 1: goto L_0x02ef;
                case 2: goto L_0x02ef;
                case 3: goto L_0x02e6;
                case 4: goto L_0x02e6;
                case 5: goto L_0x02e6;
                case 6: goto L_0x02e6;
                case 7: goto L_0x02e6;
                case 8: goto L_0x02f8;
                case 9: goto L_0x02ef;
                case 10: goto L_0x02ef;
                case 11: goto L_0x02ef;
                case 12: goto L_0x02e6;
                case 13: goto L_0x02e6;
                case 14: goto L_0x02e6;
                case 15: goto L_0x02e6;
                case 16: goto L_0x02e6;
                case 17: goto L_0x02e6;
                case 18: goto L_0x02e6;
                case 19: goto L_0x02f8;
                case 20: goto L_0x02f8;
                case 21: goto L_0x02f8;
                case 22: goto L_0x02f8;
                case 23: goto L_0x02f8;
                case 24: goto L_0x02f8;
                default: goto L_0x02e1;
            }
        L_0x02e1:
            r18 = r13
            r13 = r33
            goto L_0x0300
        L_0x02e6:
            java.lang.String r1 = "editor_pro_dialog_ppt_android"
            r18 = r13
            r13 = r33
            r13.placementId = r1
            goto L_0x0300
        L_0x02ef:
            r18 = r13
            r13 = r33
            java.lang.String r1 = "editor_pro_dialog_docx_android"
            r13.placementId = r1
            goto L_0x0300
        L_0x02f8:
            r18 = r13
            r13 = r33
            java.lang.String r1 = "editor_pro_dialog_xls_android"
            r13.placementId = r1
        L_0x0300:
            r1 = 2131428370(0x7f0b0412, float:1.8478383E38)
            android.view.View r1 = r13.findViewById(r1)
            com.github.clans.fab.FloatingActionButton r1 = (com.github.clans.fab.FloatingActionButton) r1
            r13.fabEdit = r1
            r1 = 2131430411(0x7f0b0c0b, float:1.8482522E38)
            android.view.View r1 = r13.findViewById(r1)
            com.google.android.material.tabs.TabLayout r1 = (com.google.android.material.tabs.TabLayout) r1
            r13.tlMenus = r1
            r1 = 2131428984(0x7f0b0678, float:1.8479628E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llSubMenuMain = r1
            android.widget.LinearLayout r1 = r13.llDocView
            r29 = r6
            r6 = 0
            r1.setVisibility(r6)
            android.widget.LinearLayout r1 = r13.llButtonView
            r6 = 8
            r1.setVisibility(r6)
            android.widget.TextView r1 = r13.txtActivityTitle
            java.lang.String r6 = ""
            r1.setText(r6)
            android.widget.TextView r1 = r13.txtActivityTitle
            java.lang.StringBuilder r6 = a.a.a.a.a.c$$ExternalSyntheticOutline0.m(r6)
            r30 = r12
            java.lang.String r12 = r13.fileName
            r6.append(r12)
            java.lang.String r6 = r6.toString()
            r1.setText(r6)
            java.lang.String r1 = r13.fileType
            if (r1 != 0) goto L_0x0355
            java.lang.String r1 = r33.checkFileType()
            r13.fileType = r1
        L_0x0355:
            java.lang.String r1 = r13.fileType
            java.lang.String r6 = ".pdf"
            boolean r1 = r1.endsWith(r6)
            java.lang.String r12 = ".txt"
            r31 = r6
            java.lang.String r6 = ".html"
            if (r1 == 0) goto L_0x0369
            r1 = 2131100577(0x7f0603a1, float:1.781354E38)
            goto L_0x039e
        L_0x0369:
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r7)
            if (r1 != 0) goto L_0x04fc
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r5)
            if (r1 != 0) goto L_0x04fc
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r4)
            if (r1 != 0) goto L_0x04fc
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r2)
            if (r1 != 0) goto L_0x04fc
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r3)
            if (r1 == 0) goto L_0x0393
            goto L_0x04fc
        L_0x0393:
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r12)
            if (r1 == 0) goto L_0x03ac
            r1 = 2131101157(0x7f0605e5, float:1.7814716E38)
        L_0x039e:
            r7 = r22
            r4 = r25
            r5 = r26
            r23 = r29
            r2 = r30
            r22 = r20
            goto L_0x050b
        L_0x03ac:
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r9)
            if (r1 != 0) goto L_0x04ed
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r10)
            if (r1 != 0) goto L_0x04ed
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r0)
            if (r1 != 0) goto L_0x04ed
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r14)
            if (r1 != 0) goto L_0x04ed
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r15)
            if (r1 != 0) goto L_0x04ed
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r8)
            if (r1 != 0) goto L_0x04ed
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r11)
            if (r1 != 0) goto L_0x04ed
            java.lang.String r1 = r13.fileType
            r2 = r30
            boolean r1 = r1.endsWith(r2)
            if (r1 != 0) goto L_0x04e2
            java.lang.String r1 = r13.fileType
            r3 = r29
            boolean r1 = r1.endsWith(r3)
            if (r1 != 0) goto L_0x04d9
            java.lang.String r1 = r13.fileType
            r4 = r19
            boolean r1 = r1.endsWith(r4)
            if (r1 != 0) goto L_0x04d4
            java.lang.String r1 = r13.fileType
            r5 = r20
            boolean r1 = r1.endsWith(r5)
            if (r1 != 0) goto L_0x04c7
            java.lang.String r1 = r13.fileType
            r7 = r21
            boolean r1 = r1.endsWith(r7)
            if (r1 == 0) goto L_0x041e
            r23 = r3
            r19 = r4
            r21 = r7
            goto L_0x04cb
        L_0x041e:
            java.lang.String r1 = r13.fileType
            r21 = r7
            r7 = r22
            boolean r1 = r1.endsWith(r7)
            if (r1 != 0) goto L_0x04bc
            java.lang.String r1 = r13.fileType
            r22 = r5
            r5 = r23
            boolean r1 = r1.endsWith(r5)
            if (r1 != 0) goto L_0x04b3
            java.lang.String r1 = r13.fileType
            r5 = r24
            boolean r1 = r1.endsWith(r5)
            if (r1 != 0) goto L_0x04b3
            java.lang.String r1 = r13.fileType
            r5 = r28
            boolean r1 = r1.endsWith(r5)
            if (r1 != 0) goto L_0x04b3
            java.lang.String r1 = r13.fileType
            r5 = r27
            boolean r1 = r1.endsWith(r5)
            if (r1 != 0) goto L_0x04b3
            java.lang.String r1 = r13.fileType
            r5 = r26
            boolean r1 = r1.endsWith(r5)
            if (r1 != 0) goto L_0x04ac
            java.lang.String r1 = r13.fileType
            r19 = r4
            r4 = r25
            boolean r1 = r1.endsWith(r4)
            if (r1 == 0) goto L_0x046d
            r23 = r3
            goto L_0x04c3
        L_0x046d:
            java.lang.String r1 = r13.fileType
            r23 = r3
            r3 = r18
            boolean r1 = r1.endsWith(r3)
            if (r1 == 0) goto L_0x047a
            goto L_0x04c3
        L_0x047a:
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r6)
            if (r1 == 0) goto L_0x0483
            goto L_0x04a7
        L_0x0483:
            java.lang.String r1 = r13.fileType
            java.lang.String r3 = ".png"
            boolean r1 = r1.endsWith(r3)
            if (r1 != 0) goto L_0x04a7
            java.lang.String r1 = r13.fileType
            java.lang.String r3 = ".jpg"
            boolean r1 = r1.endsWith(r3)
            if (r1 != 0) goto L_0x04a7
            java.lang.String r1 = r13.fileType
            java.lang.String r3 = ".jpeg"
            boolean r1 = r1.endsWith(r3)
            if (r1 == 0) goto L_0x04a2
            goto L_0x04a7
        L_0x04a2:
            r1 = 2131099774(0x7f06007e, float:1.781191E38)
            goto L_0x050b
        L_0x04a7:
            r1 = 2131100005(0x7f060165, float:1.781238E38)
            goto L_0x050b
        L_0x04ac:
            r23 = r3
            r19 = r4
            r4 = r25
            goto L_0x04c3
        L_0x04b3:
            r23 = r3
            r19 = r4
        L_0x04b7:
            r4 = r25
            r5 = r26
            goto L_0x04c3
        L_0x04bc:
            r23 = r3
            r19 = r4
            r22 = r5
            goto L_0x04b7
        L_0x04c3:
            r1 = 2131099946(0x7f06012a, float:1.781226E38)
            goto L_0x050b
        L_0x04c7:
            r23 = r3
            r19 = r4
        L_0x04cb:
            r7 = r22
            r4 = r25
            r22 = r5
            r5 = r26
            goto L_0x04f8
        L_0x04d4:
            r23 = r3
            r19 = r4
            goto L_0x04db
        L_0x04d9:
            r23 = r3
        L_0x04db:
            r7 = r22
            r4 = r25
            r5 = r26
            goto L_0x04ea
        L_0x04e2:
            r7 = r22
            r4 = r25
            r5 = r26
            r23 = r29
        L_0x04ea:
            r22 = r20
            goto L_0x04f8
        L_0x04ed:
            r7 = r22
            r4 = r25
            r5 = r26
            r23 = r29
            r2 = r30
            goto L_0x04ea
        L_0x04f8:
            r1 = 2131100589(0x7f0603ad, float:1.7813564E38)
            goto L_0x050b
        L_0x04fc:
            r7 = r22
            r4 = r25
            r5 = r26
            r23 = r29
            r2 = r30
            r22 = r20
            r1 = 2131099937(0x7f060121, float:1.7812241E38)
        L_0x050b:
            android.view.Window r3 = r33.getWindow()     // Catch:{ Exception -> 0x0523 }
            r30 = r2
            r2 = 67108864(0x4000000, float:1.5046328E-36)
            r3.clearFlags(r2)     // Catch:{ Exception -> 0x0525 }
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3.addFlags(r2)     // Catch:{ Exception -> 0x0525 }
            int r2 = androidx.core.content.ContextCompat.getColor(r13, r1)     // Catch:{ Exception -> 0x0525 }
            r3.setStatusBarColor(r2)     // Catch:{ Exception -> 0x0525 }
            goto L_0x0525
        L_0x0523:
            r30 = r2
        L_0x0525:
            androidx.appcompat.widget.Toolbar r2 = r13.toolbar     // Catch:{ Exception -> 0x0532 }
            android.content.res.Resources r3 = r33.getResources()     // Catch:{ Exception -> 0x0532 }
            int r1 = r3.getColor(r1)     // Catch:{ Exception -> 0x0532 }
            r2.setBackgroundColor(r1)     // Catch:{ Exception -> 0x0532 }
        L_0x0532:
            r1 = 2131429498(0x7f0b087a, float:1.848067E38)
            android.view.View r1 = r13.findViewById(r1)
            android.widget.RelativeLayout r1 = (android.widget.RelativeLayout) r1
            r1 = 2131430202(0x7f0b0b3a, float:1.8482098E38)
            android.view.View r1 = r13.findViewById(r1)
            android.widget.RelativeLayout r1 = (android.widget.RelativeLayout) r1
            com.artifex.sonui.editor.SODocumentView r2 = new com.artifex.sonui.editor.SODocumentView
            r2.<init>(r13)
            r13.mDocumentView = r2
            android.view.ViewGroup$LayoutParams r3 = new android.view.ViewGroup$LayoutParams
            r18 = r11
            r11 = -1
            r3.<init>(r11, r11)
            r1.addView(r2, r3)
            r1 = 2131429279(0x7f0b079f, float:1.8480226E38)
            android.view.View r1 = r13.findViewById(r1)
            com.artifex.sonui.artifactsdk.utilitiesEditorSdk.Overlay r1 = (com.artifex.sonui.artifactsdk.utilitiesEditorSdk.Overlay) r1
            r13.mOverlayDocument = r1
            r1 = 0
            androidx.transition.ViewUtilsBase r2 = androidx.transition.ViewUtilsBase.getInstance()     // Catch:{ Exception -> 0x0585 }
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0585 }
            r3.<init>()     // Catch:{ Exception -> 0x0585 }
            java.lang.String r11 = "event_app_editor_document_loading_start_"
            r3.append(r11)     // Catch:{ Exception -> 0x0585 }
            java.lang.String r11 = r13.fileExt     // Catch:{ Exception -> 0x0585 }
            r3.append(r11)     // Catch:{ Exception -> 0x0585 }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x0585 }
            java.lang.String r11 = r13.filePath     // Catch:{ Exception -> 0x0585 }
            r20 = r8
            r8 = r17
            r2.executeLogEventPath(r3, r8, r1, r11)     // Catch:{ Exception -> 0x0583 }
            goto L_0x0589
        L_0x0583:
            goto L_0x0589
        L_0x0585:
            r20 = r8
            r8 = r17
        L_0x0589:
            com.artifex.sonui.artifactsdk.utilitiesEditorSdk.Overlay r2 = r13.mOverlayDocument
            com.artifex.sonui.editor.SODocumentView r3 = r13.mDocumentView
            r2.setDocView(r3)
            com.artifex.sonui.editor.SODocumentView r2 = r13.mDocumentView
            com.artifex.solib.ConfigOptions r3 = com.artifex.solib.ArDkLib.getAppConfigOptions()
            r13.configOptions = r3
            java.lang.String r3 = r13.fileType
            if (r3 != 0) goto L_0x05a2
            java.lang.String r3 = r33.checkFileType()
            r13.fileType = r3
        L_0x05a2:
            java.lang.String r3 = r13.fileType
            r11 = r31
            boolean r3 = r3.endsWith(r11)
            if (r3 != 0) goto L_0x05cb
            java.lang.String r3 = r13.fileType
            boolean r3 = r3.endsWith(r12)
            if (r3 != 0) goto L_0x05cb
            java.lang.String r3 = r13.fileType
            boolean r3 = r3.endsWith(r6)
            if (r3 == 0) goto L_0x05bd
            goto L_0x05cb
        L_0x05bd:
            com.artifex.solib.ConfigOptions r1 = r13.configOptions
            r3 = 1
            r1.setEditingEnabled(r3)
            com.github.clans.fab.FloatingActionButton r1 = r13.fabEdit
            r3 = 8
            r1.setVisibility(r3)
            goto L_0x05f4
        L_0x05cb:
            com.artifex.solib.ConfigOptions r3 = r13.configOptions
            r6 = 0
            r3.setEditingEnabled(r6)
            java.lang.String r3 = r13.fileName
            if (r3 == 0) goto L_0x05eb
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r12)
            if (r1 == 0) goto L_0x05e5
            com.github.clans.fab.FloatingActionButton r1 = r13.fabEdit
            r3 = 8
            r1.setVisibility(r3)
            goto L_0x05f4
        L_0x05e5:
            com.github.clans.fab.FloatingActionButton r1 = r13.fabEdit
            r1.setVisibility(r6)
            goto L_0x05f4
        L_0x05eb:
            com.analytics_lite.analytics.analytic.AnalyticsHelp r3 = com.analytics_lite.analytics.analytic.AnalyticsHelp.getInstance()
            java.lang.String r6 = "event_app_file_name_null"
            r3.logEvent(r6, r1)
        L_0x05f4:
            com.artifex.solib.ConfigOptions r1 = r13.configOptions
            r2.setDocConfigOptions(r1)
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            com.artifex.sonui.editor.SODataLeakHandlers r2 = com.artifex.sonui.editor.Utilities.getDataLeakHandlers()
            r1.setDocDataLeakHandler(r2)
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$5 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$5
            r2.<init>()
            r1.setPageChangeListener(r2)
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$6 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$6
            r2.<init>()
            r1.setDocumentListener(r2)
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$7 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$7
            r2.<init>()
            r1.setDocStateListener(r2)
            java.io.File r1 = new java.io.File
            java.lang.String r2 = r13.filePath
            r1.<init>(r2)
            android.net.Uri r1 = android.net.Uri.fromFile(r1)
            r13.mUri = r1
            com.artifex.sonui.editor.SODocumentView r2 = r13.mDocumentView
            r3 = 0
            r2.start(r1, r3, r3)
            r1 = 2131428916(0x7f0b0634, float:1.847949E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llFile = r1
            r1 = 2131428946(0x7f0b0652, float:1.847955E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llOpen = r1
            r1 = 2131428966(0x7f0b0666, float:1.8479591E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llSave = r1
            r1 = 2131428967(0x7f0b0667, float:1.8479593E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llSaveAs = r1
            r1 = 2131428968(0x7f0b0668, float:1.8479595E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llSaveAsPDF = r1
            r1 = 2131428961(0x7f0b0661, float:1.8479581E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llPrint = r1
            r1 = 2131428979(0x7f0b0673, float:1.8479618E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llShare = r1
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llOpen
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$8 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$8
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llSave
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$9 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$9
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llSaveAs
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$10 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$10
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llSaveAsPDF
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$11 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$11
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llPrint
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$12 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$12
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llShare
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$13 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$13
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428914(0x7f0b0632, float:1.8479486E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llEdit = r1
            r1 = 2131428734(0x7f0b057e, float:1.847912E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvUndo = r1
            r1 = 2131428710(0x7f0b0566, float:1.8479072E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvRedo = r1
            r1 = 2131430577(0x7f0b0cb1, float:1.8482859E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatTextView r1 = (androidx.appcompat.widget.AppCompatTextView) r1
            r13.txtFontName = r1
            r1 = 2131428716(0x7f0b056c, float:1.8479084E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvSelectFont = r1
            r1 = 2131428693(0x7f0b0555, float:1.8479038E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvFontPlus = r1
            r1 = 2131430622(0x7f0b0cde, float:1.848295E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatTextView r1 = (androidx.appcompat.widget.AppCompatTextView) r1
            r13.txtTextSize = r1
            r1 = 2131427670(0x7f0b0156, float:1.8476963E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatTextView r1 = (androidx.appcompat.widget.AppCompatTextView) r1
            r13.bottomTextSize = r1
            r1 = 2131428691(0x7f0b0553, float:1.8479034E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvFontMinus = r1
            r1 = 2131428672(0x7f0b0540, float:1.8478995E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvBold = r1
            r1 = 2131428703(0x7f0b055f, float:1.8479058E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvItalic = r1
            r1 = 2131428733(0x7f0b057d, float:1.8479119E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvUnderline = r1
            r1 = 2131428671(0x7f0b053f, float:1.8478993E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r1 = 2131428715(0x7f0b056b, float:1.8479082E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvSelectBgColor = r1
            r1 = 2131428690(0x7f0b0552, float:1.8479032E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r1 = 2131428717(0x7f0b056d, float:1.8479086E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvSelectFontColor = r1
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvUndo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$17 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$17
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvRedo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$18 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$18
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatTextView r1 = r13.txtFontName
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$19 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$19
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSelectFont
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$20 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$20
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvFontPlus
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$21 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$21
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvFontMinus
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$22 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$22
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvBold
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$23 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$23
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvItalic
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$24 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$24
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvUnderline
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$25 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$25
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSelectBgColor
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$26 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$26
            r2.<init>(r13)
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSelectFontColor
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$27 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$27
            r2.<init>(r13)
            r1.setOnClickListener(r2)
            r1 = 2131428999(0x7f0b0687, float:1.8479658E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llTools = r1
            r1 = 2131428956(0x7f0b065c, float:1.8479571E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llPPTtoPDF = r1
            r1 = 2131428913(0x7f0b0631, float:1.8479484E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llESign = r1
            r1 = 2131428955(0x7f0b065b, float:1.847957E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llPPTtoImage = r1
            r1 = 2131428311(0x7f0b03d7, float:1.8478263E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.recyclerview.widget.RecyclerView r1 = (androidx.recyclerview.widget.RecyclerView) r1
            r13.editorToolsRecycler = r1
            r1 = 2131427667(0x7f0b0153, float:1.8476957E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.recyclerview.widget.RecyclerView r1 = (androidx.recyclerview.widget.RecyclerView) r1
            r13.bottomToolsRecycler = r1
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llPPTtoPDF
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$28 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$28
            r2.<init>(r13)
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llESign
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$29 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$29
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llPPTtoImage
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$30 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$30
            r2.<init>(r13)
            r1.setOnClickListener(r2)
            java.lang.String r1 = r33.checkFileType()
            r13.fileType = r1
            com.applovin.exoplayer2.h.u$a$$ExternalSyntheticLambda0 r1 = new com.applovin.exoplayer2.h.u$a$$ExternalSyntheticLambda0
            r1.<init>((com.artifex.sonui.artifactsdk.activity.DocViewActivity) r13)
            com.arasthel.asyncjob.AsyncJob.doInBackground(r1)
            r1 = 2131428936(0x7f0b0648, float:1.847953E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llInsert = r1
            r1 = 2131428702(0x7f0b055e, float:1.8479056E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvInsertUndo = r1
            r1 = 2131428701(0x7f0b055d, float:1.8479054E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvInsertRedo = r1
            r1 = 2131428935(0x7f0b0647, float:1.8479529E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llImage = r1
            r1 = 2131428959(0x7f0b065f, float:1.8479577E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llPhoto = r1
            r1 = 2131428978(0x7f0b0672, float:1.8479616E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llShape = r1
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvInsertUndo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$32 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$32
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvInsertRedo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$33 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$33
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llImage
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$34 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$34
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llPhoto
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$35 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$35
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llShape
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$36 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$36
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428924(0x7f0b063c, float:1.8479506E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llFormat = r1
            r1 = 2131428696(0x7f0b0558, float:1.8479044E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvFormatUndo = r1
            r1 = 2131428695(0x7f0b0557, float:1.8479042E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvFormatRedo = r1
            r1 = 2131428718(0x7f0b056e, float:1.8479088E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvShape1 = r1
            r1 = 2131428719(0x7f0b056f, float:1.847909E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvShape2 = r1
            r1 = 2131428720(0x7f0b0570, float:1.8479092E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvShape3 = r1
            r1 = 2131428721(0x7f0b0571, float:1.8479094E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvShape4 = r1
            r1 = 2131428667(0x7f0b053b, float:1.8478985E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvArrange1 = r1
            r1 = 2131428668(0x7f0b053c, float:1.8478987E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvArrange2 = r1
            r1 = 2131428669(0x7f0b053d, float:1.847899E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvArrange3 = r1
            r1 = 2131428670(0x7f0b053e, float:1.8478991E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvArrange4 = r1
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvFormatUndo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$37 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$37
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvFormatRedo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$38 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$38
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvShape1
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$39 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$39
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvShape2
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$40 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$40
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvShape3
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$41 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$41
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvShape4
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$42 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$42
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvArrange1
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$43 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$43
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvArrange2
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$44 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$44
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvArrange3
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$45 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$45
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvArrange4
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$46 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$46
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428909(0x7f0b062d, float:1.8479476E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llDraw = r1
            r1 = 2131428684(0x7f0b054c, float:1.847902E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvDrawUndo = r1
            r1 = 2131428681(0x7f0b0549, float:1.8479013E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvDrawRedo = r1
            r1 = 2131428910(0x7f0b062e, float:1.8479478E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llDrawOption = r1
            r1 = 2131428680(0x7f0b0548, float:1.8479011E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r1 = 2131428683(0x7f0b054b, float:1.8479017E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvDrawSelectBgColor = r1
            r1 = 2131428679(0x7f0b0547, float:1.847901E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r1 = 2131428682(0x7f0b054a, float:1.8479015E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvDrawSelectAlignment = r1
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvDrawUndo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$47 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$47
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvDrawRedo
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$48 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$48
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llDrawOption
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$49 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$49
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvDrawSelectBgColor
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$50 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$50
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvDrawSelectAlignment
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$51 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$51
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428911(0x7f0b062f, float:1.847948E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llDrawSubMenu = r1
            r1 = 2131430515(0x7f0b0c73, float:1.8482733E38)
            android.view.View r1 = r13.findViewById(r1)
            android.widget.TextView r1 = (android.widget.TextView) r1
            r13.tvDraw = r1
            r1 = 2131428658(0x7f0b0532, float:1.8478967E38)
            android.view.View r1 = r13.findViewById(r1)
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            r13.imgDraw = r1
            r1 = 2131428900(0x7f0b0624, float:1.8479458E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llDeleteSelection = r1
            r1 = 2131428940(0x7f0b064c, float:1.8479539E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llLineColor = r1
            r1 = 2131428661(0x7f0b0535, float:1.8478973E38)
            android.view.View r1 = r13.findViewById(r1)
            android.widget.ImageView r1 = (android.widget.ImageView) r1
            r13.imgLineColor = r1
            r1 = 2131428941(0x7f0b064d, float:1.847954E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llLineThickness = r1
            r1 = 2131428895(0x7f0b061f, float:1.8479447E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llAuthor = r1
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llDrawSubMenu
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$55 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$55
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llDeleteSelection
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$56 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$56
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llLineColor
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$57 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$57
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llLineThickness
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$58 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$58
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llAuthor
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$59 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$59
            r2.<init>(r13)
            r1.setOnClickListener(r2)
            r1 = 2131428930(0x7f0b0642, float:1.8479518E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llGetText = r1
            r1 = 2131428892(0x7f0b061c, float:1.8479441E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llAddText = r1
            r1 = 2131428901(0x7f0b0625, float:1.847946E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llDeleteText = r1
            r1 = 2131428902(0x7f0b0626, float:1.8479462E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llDeselect = r1
            r1 = 2131428948(0x7f0b0654, float:1.8479555E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llOverLay = r1
            com.artifex.solib.ConfigOptions r1 = r13.configOptions
            boolean r1 = r1.isEditingEnabled()
            if (r1 != 0) goto L_0x0afa
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llAddText
            r2 = 8
            r1.setVisibility(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llDeleteText
            r1.setVisibility(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llDeselect
            r1.setVisibility(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llOverLay
            r1.setVisibility(r2)
        L_0x0afa:
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llGetText
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$60 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$60
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llAddText
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$61 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$61
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llDeleteText
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$62 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$62
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llDeselect
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$63 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$63
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llOverLay
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$64 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$64
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428971(0x7f0b066b, float:1.8479602E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llScaleUp = r1
            r1 = 2131428970(0x7f0b066a, float:1.84796E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llScaleDown = r1
            r1 = 2131428973(0x7f0b066d, float:1.8479606E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llScrollUp = r1
            r1 = 2131428972(0x7f0b066c, float:1.8479604E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llScrollDown = r1
            r1 = 2131428965(0x7f0b0665, float:1.847959E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llReset = r1
            r2 = 8
            r1.setVisibility(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llScaleUp
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$65 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$65
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llScaleDown
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$66 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$66
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llScrollUp
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$67 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$67
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llScrollDown
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$68 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$68
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llReset
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$69 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$69
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428957(0x7f0b065d, float:1.8479573E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llPages = r1
            r1 = 2131428982(0x7f0b0676, float:1.8479624E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llShowPages = r1
            r1 = 2131430613(0x7f0b0cd5, float:1.8482932E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatTextView r1 = (androidx.appcompat.widget.AppCompatTextView) r1
            r13.txtShowPages = r1
            r1 = 2131428922(0x7f0b063a, float:1.8479502E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llFirstPage = r1
            r1 = 2131428939(0x7f0b064b, float:1.8479537E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llLastPage = r1
            r1 = 2131428969(0x7f0b0669, float:1.8479597E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llScale = r1
            r1 = 2131428894(0x7f0b061e, float:1.8479445E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llAnnotation = r1
            r1 = 2131428977(0x7f0b0671, float:1.8479614E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llSelection = r1
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llShowPages
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$52 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$52
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llFirstPage
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$53 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$53
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llLastPage
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$54 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$54
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428947(0x7f0b0653, float:1.8479553E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llOrganize = r1
            r1 = 2131428891(0x7f0b061b, float:1.847944E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$70 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$70
            r2.<init>()
            r1.setOnClickListener(r2)
            r1 = 2131428921(0x7f0b0639, float:1.84795E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llFind = r1
            r1 = 2131428289(0x7f0b03c1, float:1.8478218E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatEditText r1 = (androidx.appcompat.widget.AppCompatEditText) r1
            r13.eTextSearch = r1
            r1 = 2131428673(0x7f0b0541, float:1.8478997E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvClear = r1
            r1 = 2131428714(0x7f0b056a, float:1.847908E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvSearchPrev = r1
            r1 = 2131428713(0x7f0b0569, float:1.8479078E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatImageView r1 = (androidx.appcompat.widget.AppCompatImageView) r1
            r13.imvSearchForward = r1
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvClear
            r2 = 0
            r1.setEnabled(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSearchPrev
            r1.setEnabled(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSearchForward
            r1.setEnabled(r2)
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            boolean r1 = r1.hasSearch()
            if (r1 == 0) goto L_0x0ca4
            androidx.appcompat.widget.AppCompatEditText r1 = r13.eTextSearch
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$71 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$71
            r2.<init>()
            r1.addTextChangedListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvClear
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$72 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$72
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSearchPrev
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$73 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$73
            r2.<init>()
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSearchForward
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$74 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$74
            r2.<init>()
            r1.setOnClickListener(r2)
            goto L_0x0cbe
        L_0x0ca4:
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llFind
            r2 = 0
            r1.setEnabled(r2)
            androidx.appcompat.widget.AppCompatEditText r1 = r13.eTextSearch
            r1.setEnabled(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvClear
            r1.setEnabled(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSearchPrev
            r1.setEnabled(r2)
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvSearchForward
            r1.setEnabled(r2)
        L_0x0cbe:
            r1 = 2131428926(0x7f0b063e, float:1.847951E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llFreeze = r1
            r1 = 2131428927(0x7f0b063f, float:1.8479512E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llFreezeFirstColumn = r1
            r1 = 2131428928(0x7f0b0640, float:1.8479514E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.LinearLayoutCompat r1 = (androidx.appcompat.widget.LinearLayoutCompat) r1
            r13.llFreezeFirstRow = r1
            r1 = 2131430641(0x7f0b0cf1, float:1.8482989E38)
            android.view.View r1 = r13.findViewById(r1)
            androidx.appcompat.widget.AppCompatTextView r1 = (androidx.appcompat.widget.AppCompatTextView) r1
            r13.unfreeze = r1
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llFreezeFirstColumn
            com.rpdev.docreadermainV2.adapter.FileAdapter$$ExternalSyntheticLambda0 r2 = new com.rpdev.docreadermainV2.adapter.FileAdapter$$ExternalSyntheticLambda0
            r2.<init>((com.artifex.sonui.artifactsdk.activity.DocViewActivity) r13)
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.LinearLayoutCompat r1 = r13.llFreezeFirstRow
            billing.pro.SubscriptionPlan$$ExternalSyntheticLambda2 r2 = new billing.pro.SubscriptionPlan$$ExternalSyntheticLambda2
            r2.<init>((com.artifex.sonui.artifactsdk.activity.DocViewActivity) r13)
            r1.setOnClickListener(r2)
            androidx.appcompat.widget.AppCompatTextView r1 = r13.unfreeze
            billing.pro.SubscriptionPlan$$ExternalSyntheticLambda1 r2 = new billing.pro.SubscriptionPlan$$ExternalSyntheticLambda1
            r2.<init>((com.artifex.sonui.artifactsdk.activity.DocViewActivity) r13)
            r1.setOnClickListener(r2)
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            r1.removeAllTabs()
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r3 = 2132018466(0x7f140522, float:1.967524E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r3, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
            com.artifex.solib.ConfigOptions r1 = r13.configOptions
            boolean r1 = r1.isEditingEnabled()
            if (r1 == 0) goto L_0x0d3f
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018465(0x7f140521, float:1.9675237E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
        L_0x0d3f:
            java.lang.StringBuilder r1 = a.a.a.a.a.c$$ExternalSyntheticOutline0.m(r16)
            java.io.File r2 = new java.io.File
            java.lang.String r6 = r13.filePath
            r2.<init>(r6)
            java.lang.String r2 = r2.getName()
            java.lang.String r2 = org.apache.commons.io.FilenameUtils.getExtension(r2)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r13.fileExt = r1
            java.lang.String r1 = r33.checkFileType()
            r13.fileType = r1
            java.lang.String r1 = r1.toLowerCase()
            boolean r1 = r1.endsWith(r12)
            if (r1 != 0) goto L_0x0da1
            java.lang.String r1 = r13.fileType
            java.lang.String r1 = r1.toLowerCase()
            boolean r1 = r1.endsWith(r12)
            if (r1 != 0) goto L_0x0da1
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018476(0x7f14052c, float:1.967526E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018474(0x7f14052a, float:1.9675256E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
        L_0x0da1:
            java.lang.String r1 = r13.fileType
            java.lang.String r1 = r1.toLowerCase()
            boolean r1 = r1.endsWith(r4)
            if (r1 != 0) goto L_0x0dce
            java.lang.String r1 = r13.fileType
            java.lang.String r1 = r1.toLowerCase()
            boolean r1 = r1.endsWith(r12)
            if (r1 != 0) goto L_0x0dce
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018472(0x7f140528, float:1.9675252E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
        L_0x0dce:
            com.artifex.solib.ConfigOptions r1 = r13.configOptions
            boolean r1 = r1.isEditingEnabled()
            if (r1 == 0) goto L_0x0deb
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018463(0x7f14051f, float:1.9675233E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
        L_0x0deb:
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018473(0x7f140529, float:1.9675254E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018471(0x7f140527, float:1.967525E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r6 = 2132018467(0x7f140523, float:1.9675241E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r6, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r6 = r1.tabs
            boolean r6 = r6.isEmpty()
            r1.addTab(r2, r6)
            java.lang.String r1 = r13.fileType
            java.lang.String r1 = r1.toLowerCase()
            boolean r1 = r1.endsWith(r4)
            if (r1 != 0) goto L_0x0e4e
            java.lang.String r1 = r13.fileType
            java.lang.String r1 = r1.toLowerCase()
            boolean r1 = r1.endsWith(r7)
            if (r1 != 0) goto L_0x0e4e
            java.lang.String r1 = r13.fileType
            java.lang.String r1 = r1.toLowerCase()
            boolean r1 = r1.endsWith(r5)
            if (r1 == 0) goto L_0x0e63
        L_0x0e4e:
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.google.android.material.tabs.TabLayout$Tab r2 = r1.newTab()
            r4 = 2132018469(0x7f140525, float:1.9675246E38)
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$$ExternalSyntheticOutline0.m(r13, r4, r2)
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$Tab> r4 = r1.tabs
            boolean r4 = r4.isEmpty()
            r1.addTab(r2, r4)
        L_0x0e63:
            com.google.android.material.tabs.TabLayout r1 = r13.tlMenus
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$82 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$82
            r2.<init>()
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$BaseOnTabSelectedListener> r4 = r1.selectedListeners
            boolean r4 = r4.contains(r2)
            if (r4 != 0) goto L_0x0e77
            java.util.ArrayList<com.google.android.material.tabs.TabLayout$BaseOnTabSelectedListener> r1 = r1.selectedListeners
            r1.add(r2)
        L_0x0e77:
            android.app.Activity r1 = r13.mContext
            android.content.res.Resources r1 = r1.getResources()
            java.lang.String r1 = r1.getString(r3)
            r13.selectMenuTitle = r1
            r33.menuFile()
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            if (r1 == 0) goto L_0x0e92
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$75 r2 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$75
            r2.<init>()
            r1.setOnUpdateUI(r2)
        L_0x0e92:
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            r1.hasPages()
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            boolean r1 = r1.hasUndo()
            if (r1 != 0) goto L_0x0ea7
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvUndo
            r2 = 8
            r1.setVisibility(r2)
            goto L_0x0ea9
        L_0x0ea7:
            r2 = 8
        L_0x0ea9:
            com.artifex.sonui.editor.SODocumentView r1 = r13.mDocumentView
            boolean r1 = r1.hasRedo()
            if (r1 != 0) goto L_0x0eb6
            androidx.appcompat.widget.AppCompatImageView r1 = r13.imvRedo
            r1.setVisibility(r2)
        L_0x0eb6:
            r1 = 2132017535(0x7f14017f, float:1.9673351E38)
            java.lang.String r1 = r13.getString(r1)
            java.lang.String r1 = r1.toLowerCase()
            java.lang.String r2 = "ppt"
            boolean r1 = r1.contains(r2)
            if (r1 == 0) goto L_0x0f45
            java.lang.String r1 = r13.fileName
            if (r1 == 0) goto L_0x0f39
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r9)
            if (r1 != 0) goto L_0x0f45
            java.lang.String r1 = r13.fileType
            boolean r1 = r1.endsWith(r10)
            if (r1 != 0) goto L_0x0f45
            java.lang.String r1 = r13.fileType
            boolean r0 = r1.endsWith(r0)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            boolean r0 = r0.endsWith(r14)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            boolean r0 = r0.endsWith(r15)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            r1 = r20
            boolean r0 = r0.endsWith(r1)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            r1 = r18
            boolean r0 = r0.endsWith(r1)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            r1 = r30
            boolean r0 = r0.endsWith(r1)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            r1 = r23
            boolean r0 = r0.endsWith(r1)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            r1 = r19
            boolean r0 = r0.endsWith(r1)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            r1 = r22
            boolean r0 = r0.endsWith(r1)
            if (r0 != 0) goto L_0x0f45
            java.lang.String r0 = r13.fileType
            r1 = r21
            r0.endsWith(r1)
            goto L_0x0f45
        L_0x0f39:
            androidx.transition.ViewUtilsBase r0 = androidx.transition.ViewUtilsBase.getInstance()
            java.lang.String r1 = "event_app_editor_filename_null"
            java.lang.String r2 = "null"
            r3 = 0
            r0.executeLogEvent(r1, r8, r3, r2)
        L_0x0f45:
            android.widget.ImageView r0 = r13.imvFullScreen
            if (r0 == 0) goto L_0x0f57
            r1 = 0
            r0.setVisibility(r1)
            android.widget.ImageView r0 = r13.imvFullScreen
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$76 r1 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$76
            r1.<init>()
            r0.setOnClickListener(r1)
        L_0x0f57:
            com.github.clans.fab.FloatingActionButton r0 = r13.fabEdit
            if (r0 == 0) goto L_0x0f63
            com.artifex.sonui.artifactsdk.activity.DocViewActivity$77 r1 = new com.artifex.sonui.artifactsdk.activity.DocViewActivity$77
            r1.<init>()
            r0.setOnClickListener(r1)
        L_0x0f63:
            r33.setFabButtonColor()
            r0 = 2131427658(0x7f0b014a, float:1.8476938E38)
            android.view.View r1 = r13.findViewById(r0)
            r2 = 0
            r1.setVisibility(r2)
            com.commons_lite.ads_module.ads.control.AdHelpMain r1 = com.commons_lite.ads_module.ads.control.AdHelpMain.INSTANCE
            android.view.View r3 = r13.findViewById(r0)
            r4 = 0
            r5 = 0
            r0 = r1
            r1 = r2
            r2 = r33
            r0.renderPreloadedBanner(r1, r2, r3, r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.artifex.sonui.artifactsdk.activity.DocViewActivity.allDocControllerInit():void");
    }

    public final void backPressRedirection() {
        Intent intent;
        if (this.fromApp) {
            finish();
            return;
        }
        try {
            if (getString(R.string.app_name).contains("Email")) {
                intent = new Intent(this, Class.forName("com.rpdev.lib_nativeemail.activities.ControlActivity"));
            } else if (getString(R.string.app_name).toLowerCase().contains("scanner")) {
                intent = new Intent(this, Class.forName("com.camscanner.docscanner.pdfcreator.view.activity.main.MainActivity"));
            } else {
                intent = new Intent(this, Class.forName("com.rpdev.docreadermainV2.activity.FormatDashboardActivity"));
            }
            intent.setFlags(335544320);
            intent.putExtra("isFromPreview", true);
            showInterAds("closeClick", true, intent, IntentRedirectionConstants.HOME_REDIRECTION_REQUEST_CODE.intValue());
        } catch (ClassNotFoundException e) {
            FirebaseCrashlytics.getInstance().log(e.getMessage());
            e.printStackTrace();
        }
    }

    public final void callEvents(String str) {
        try {
            ViewUtilsBase instance = ViewUtilsBase.getInstance();
            instance.executeLogEvent("event_app_editor_menu_" + this.selectMenuTitle.toLowerCase() + "_sub_menu_" + str + "_pressed_" + this.fileExt, "DocViewActivityArtifact", (String) null, "pressed");
        } catch (Exception unused) {
        }
    }

    public final String checkFileType() {
        String str = this.fileExt;
        Objects.requireNonNull(str);
        char c = 65535;
        switch (str.hashCode()) {
            case 1469208:
                if (str.equals(".csv")) {
                    c = 0;
                    break;
                }
                break;
            case 1470026:
                if (str.equals(".doc")) {
                    c = 1;
                    break;
                }
                break;
            case 1470043:
                if (str.equals(".dot")) {
                    c = 2;
                    break;
                }
                break;
            case 1480269:
                if (str.equals(".odp")) {
                    c = 3;
                    break;
                }
                break;
            case 1481220:
                if (str.equals(".pdf")) {
                    c = 4;
                    break;
                }
                break;
            case 1481575:
                if (str.equals(".pot")) {
                    c = 5;
                    break;
                }
                break;
            case 1481587:
                if (str.equals(".ppa")) {
                    c = 6;
                    break;
                }
                break;
            case 1481605:
                if (str.equals(".pps")) {
                    c = 7;
                    break;
                }
                break;
            case 1481606:
                if (str.equals(".ppt")) {
                    c = 8;
                    break;
                }
                break;
            case 1485698:
                if (str.equals(".txt")) {
                    c = 9;
                    break;
                }
                break;
            case 1489169:
                if (str.equals(".xls")) {
                    c = 10;
                    break;
                }
                break;
            case 45570915:
                if (str.equals(".docm")) {
                    c = 11;
                    break;
                }
                break;
            case 45570926:
                if (str.equals(".docx")) {
                    c = 12;
                    break;
                }
                break;
            case 45571453:
                if (str.equals(".dotx")) {
                    c = 13;
                    break;
                }
                break;
            case 45695193:
                if (str.equals(".html")) {
                    c = 14;
                    break;
                }
                break;
            case 45928934:
                if (str.equals(".potm")) {
                    c = 15;
                    break;
                }
                break;
            case 45928945:
                if (str.equals(".potx")) {
                    c = 16;
                    break;
                }
                break;
            case 45929306:
                if (str.equals(".ppam")) {
                    c = 17;
                    break;
                }
                break;
            case 45929864:
                if (str.equals(".ppsm")) {
                    c = 18;
                    break;
                }
                break;
            case 45929875:
                if (str.equals(".ppsx")) {
                    c = 19;
                    break;
                }
                break;
            case 45929895:
                if (str.equals(".pptm")) {
                    c = 20;
                    break;
                }
                break;
            case 45929906:
                if (str.equals(".pptx")) {
                    c = 21;
                    break;
                }
                break;
            case 46163790:
                if (str.equals(".xlam")) {
                    c = 22;
                    break;
                }
                break;
            case 46164337:
                if (str.equals(".xlsb")) {
                    c = 23;
                    break;
                }
                break;
            case 46164348:
                if (str.equals(".xlsm")) {
                    c = 24;
                    break;
                }
                break;
            case 46164359:
                if (str.equals(".xlsx")) {
                    c = 25;
                    break;
                }
                break;
            case 46164379:
                if (str.equals(".xltm")) {
                    c = 26;
                    break;
                }
                break;
            case 46164390:
                if (str.equals(".xltx")) {
                    c = 27;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
            case 10:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
                return ".xls";
            case 1:
            case 2:
            case 11:
            case 12:
            case 13:
                return ".docx";
            case 3:
            case 5:
            case 6:
            case 7:
            case 8:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
                return ".ppt";
            case 4:
                return ".pdf";
            case 9:
                return ".txt";
            case 14:
                return ".html";
            default:
                return "";
        }
    }

    public final void eSignPDF() {
        Intent intent;
        callEvents("esignature");
        try {
            intent = new Intent(this.mContext, ToolsViewActivity.class);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            intent = null;
        }
        Intent intent2 = intent;
        try {
            intent2.setData(Uri.fromFile(new File(this.filePath)));
        } catch (Exception e2) {
            Log.e("DocViewActivityArtifact", e2.getLocalizedMessage().toString());
        }
        intent2.putExtra("isDark", true);
        intent2.putExtra("TOOL_TAG", "E Signature");
        intent2.putExtra("isFromPreview", true);
        intent2.putExtra("from_app", true);
        LoginHelper.getInstance().checkIsProOrNot(this, intent2, "E-Sign Your Document", false, this.openedFrom);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void editorToolOnClick(java.lang.String r13) {
        /*
            r12 = this;
            java.util.Objects.requireNonNull(r13)
            int r0 = r13.hashCode()
            r1 = 1
            r2 = 0
            r3 = 8
            java.lang.String r4 = "Compress PDF"
            java.lang.String r5 = "Merge PDF"
            java.lang.String r6 = "Split PDF"
            java.lang.String r7 = "PDF to Image"
            switch(r0) {
                case -2053846300: goto L_0x00a4;
                case -1888231764: goto L_0x009b;
                case -1293553779: goto L_0x0090;
                case -665540406: goto L_0x0087;
                case 78343830: goto L_0x007c;
                case 85869743: goto L_0x0071;
                case 291526486: goto L_0x0066;
                case 723404025: goto L_0x005b;
                case 907236116: goto L_0x004e;
                case 907280973: goto L_0x0040;
                case 1106729448: goto L_0x0032;
                case 1603960628: goto L_0x0026;
                case 1665114345: goto L_0x0018;
                default: goto L_0x0016;
            }
        L_0x0016:
            goto L_0x00ad
        L_0x0018:
            java.lang.String r0 = "Edit Xls"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x0022
            goto L_0x00ad
        L_0x0022:
            r13 = 12
            goto L_0x00ae
        L_0x0026:
            boolean r13 = r13.equals(r4)
            if (r13 != 0) goto L_0x002e
            goto L_0x00ad
        L_0x002e:
            r13 = 11
            goto L_0x00ae
        L_0x0032:
            java.lang.String r0 = "Bold Text"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x003c
            goto L_0x00ad
        L_0x003c:
            r13 = 10
            goto L_0x00ae
        L_0x0040:
            java.lang.String r0 = "Text Type"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x004a
            goto L_0x00ad
        L_0x004a:
            r13 = 9
            goto L_0x00ae
        L_0x004e:
            java.lang.String r0 = "Text Size"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x0058
            goto L_0x00ad
        L_0x0058:
            r13 = 8
            goto L_0x00ae
        L_0x005b:
            java.lang.String r0 = "PPT to PDF"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x0064
            goto L_0x00ad
        L_0x0064:
            r13 = 7
            goto L_0x00ae
        L_0x0066:
            java.lang.String r0 = "Excel to PDF"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x006f
            goto L_0x00ad
        L_0x006f:
            r13 = 6
            goto L_0x00ae
        L_0x0071:
            java.lang.String r0 = "E Signature PDF"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x007a
            goto L_0x00ad
        L_0x007a:
            r13 = 5
            goto L_0x00ae
        L_0x007c:
            java.lang.String r0 = "Edit Docx"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x0085
            goto L_0x00ad
        L_0x0085:
            r13 = 4
            goto L_0x00ae
        L_0x0087:
            boolean r13 = r13.equals(r5)
            if (r13 != 0) goto L_0x008e
            goto L_0x00ad
        L_0x008e:
            r13 = 3
            goto L_0x00ae
        L_0x0090:
            java.lang.String r0 = "Docx To Pdf"
            boolean r13 = r13.equals(r0)
            if (r13 != 0) goto L_0x0099
            goto L_0x00ad
        L_0x0099:
            r13 = 2
            goto L_0x00ae
        L_0x009b:
            boolean r13 = r13.equals(r6)
            if (r13 != 0) goto L_0x00a2
            goto L_0x00ad
        L_0x00a2:
            r13 = 1
            goto L_0x00ae
        L_0x00a4:
            boolean r13 = r13.equals(r7)
            if (r13 != 0) goto L_0x00ab
            goto L_0x00ad
        L_0x00ab:
            r13 = 0
            goto L_0x00ae
        L_0x00ad:
            r13 = -1
        L_0x00ae:
            r0 = 2132018104(0x7f1403b8, float:1.9674505E38)
            r8 = 2132017535(0x7f14017f, float:1.9673351E38)
            java.lang.String r9 = "com.rpdev.docreadermainV2.activity.pdfTools.ToolsViewActivity"
            switch(r13) {
                case 0: goto L_0x017b;
                case 1: goto L_0x0177;
                case 2: goto L_0x0148;
                case 3: goto L_0x0144;
                case 4: goto L_0x012a;
                case 5: goto L_0x0126;
                case 6: goto L_0x011b;
                case 7: goto L_0x0110;
                case 8: goto L_0x00f7;
                case 9: goto L_0x00f2;
                case 10: goto L_0x00dc;
                case 11: goto L_0x00d7;
                case 12: goto L_0x00bb;
                default: goto L_0x00b9;
            }
        L_0x00b9:
            goto L_0x017e
        L_0x00bb:
            java.lang.String r13 = r12.getString(r8)
            java.lang.String r1 = "xls"
            boolean r13 = r13.contains(r1)
            if (r13 == 0) goto L_0x00d0
            java.lang.String r13 = r12.getString(r0)
            r12.urlRedirection(r13)
            goto L_0x017e
        L_0x00d0:
            java.lang.String r13 = "https://play.google.com/store/apps/details?id=com.xsdev.xls.xlsx.excelviwer.excelreader.spread.sheets"
            r12.urlRedirection(r13)
            goto L_0x017e
        L_0x00d7:
            r12.redirectToTool(r9, r4)
            goto L_0x017e
        L_0x00dc:
            java.lang.String r13 = "bold"
            r12.callEvents(r13)
            com.artifex.sonui.editor.SODocumentView r13 = r12.mDocumentView
            if (r13 == 0) goto L_0x00ed
            boolean r0 = r13.getSelectionIsBold()
            r0 = r0 ^ r1
            r13.setSelectionIsBold(r0)
        L_0x00ed:
            r12.updateUI()
            goto L_0x017e
        L_0x00f2:
            r12.imvSelectFont()
            goto L_0x017e
        L_0x00f7:
            r13 = 2131430354(0x7f0b0bd2, float:1.8482407E38)
            android.view.View r13 = r12.findViewById(r13)
            android.widget.LinearLayout r13 = (android.widget.LinearLayout) r13
            int r0 = r13.getVisibility()
            if (r0 != 0) goto L_0x010b
            r13.setVisibility(r3)
            goto L_0x017e
        L_0x010b:
            r13.setVisibility(r2)
            goto L_0x017e
        L_0x0110:
            java.lang.String r13 = "ppt_to_pdf"
            r12.callEvents(r13)
            r12.whatSelected = r1
            r12.saveAsPdf()
            goto L_0x017e
        L_0x011b:
            java.lang.String r13 = "excel_to_pdf"
            r12.callEvents(r13)
            r12.whatSelected = r1
            r12.saveAsPdf()
            goto L_0x017e
        L_0x0126:
            r12.eSignPDF()
            goto L_0x017e
        L_0x012a:
            java.lang.String r13 = r12.getString(r8)
            java.lang.String r1 = "docx"
            boolean r13 = r13.contains(r1)
            if (r13 == 0) goto L_0x013e
            java.lang.String r13 = r12.getString(r0)
            r12.urlRedirection(r13)
            goto L_0x017e
        L_0x013e:
            java.lang.String r13 = "https://play.google.com/store/apps/details?id=com.xdev.docxreader.docx.docxviewer.document.doc.office.viewer.reader.word"
            r12.urlRedirection(r13)
            goto L_0x017e
        L_0x0144:
            r12.redirectToTool(r9, r5)
            goto L_0x017e
        L_0x0148:
            java.lang.String r13 = "docx_to_pdf"
            r12.callEvents(r13)
            billing.helper.BillingHelp r13 = billing.helper.BillingHelp.INSTANCE
            android.app.Activity r0 = r12.mContext
            boolean r0 = r13.isPremiumEnabled(r0)
            if (r0 == 0) goto L_0x0163
            boolean r13 = r13.isPremium()
            if (r13 == 0) goto L_0x0163
            r12.whatSelected = r1
            r12.saveAsPdf()
            goto L_0x017e
        L_0x0163:
            android.app.Activity r3 = r12.mContext
            r6 = 0
            r7 = 0
            java.lang.String r9 = r12.fileExt
            r11 = 0
            java.lang.String r4 = "docx_to_pdf_android"
            java.lang.String r5 = "redirect_to_docx_to_pdf"
            java.lang.String r8 = "docx_to_pdf"
            java.lang.String r10 = " To convert Docx To PDF "
            r2 = r12
            r2.showEditFileDialog(r3, r4, r5, r6, r7, r8, r9, r10, r11)
            goto L_0x017e
        L_0x0177:
            r12.redirectToTool(r9, r6)
            goto L_0x017e
        L_0x017b:
            r12.redirectToTool(r9, r7)
        L_0x017e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.artifex.sonui.artifactsdk.activity.DocViewActivity.editorToolOnClick(java.lang.String):void");
    }

    public final void hideSubMenus() {
        this.llFile.setVisibility(8);
        this.llEdit.setVisibility(8);
        this.llTools.setVisibility(8);
        this.llInsert.setVisibility(8);
        this.llFormat.setVisibility(8);
        this.llDraw.setVisibility(8);
        this.llScale.setVisibility(8);
        this.llAnnotation.setVisibility(8);
        this.llSelection.setVisibility(8);
        this.llPages.setVisibility(8);
        this.llOrganize.setVisibility(8);
        this.llFind.setVisibility(8);
        this.llFreeze.setVisibility(8);
    }

    public final void imvSelectFont() {
        callEvents("font");
        if (this.mDocumentView != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this.mContext);
            builder.setTitle("Font Name");
            final String[] fontList = this.mDocumentView.getFontList();
            if (fontList.length > 0) {
                builder.setItems(fontList, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        DocViewActivity docViewActivity = DocViewActivity.this;
                        SODocumentView sODocumentView = docViewActivity.mDocumentView;
                        if (sODocumentView != null) {
                            String str = fontList[i];
                            docViewActivity.selectFontName = str;
                            sODocumentView.setSelectionFontName(str);
                            AppCompatTextView appCompatTextView = DocViewActivity.this.txtFontName;
                            StringBuilder m = c$$ExternalSyntheticOutline0.m("");
                            m.append(DocViewActivity.this.selectFontName);
                            appCompatTextView.setText(m.toString());
                            ViewUtilsBase instance = ViewUtilsBase.getInstance();
                            StringBuilder m2 = c$$ExternalSyntheticOutline0.m("event_app_editor_");
                            m2.append(DocViewActivity.this.selectMenuTitle.toLowerCase());
                            m2.append("_font_select_");
                            m2.append(DocViewActivity.this.selectFontName.toLowerCase());
                            m2.append("_");
                            m2.append(DocViewActivity.this.fileExt);
                            instance.executeLogEvent(m2.toString(), "DocViewActivityArtifact", (String) null, "click");
                        }
                    }
                });
                builder.create().show();
            }
        }
        updateUI();
    }

    public final void menuFile() {
        hideSubMenus();
        this.llFile.setVisibility(0);
        if (this.configOptions.isEditingEnabled()) {
            this.llSave.setVisibility(0);
            this.llSaveAsPDF.setVisibility(0);
            return;
        }
        this.llSave.setVisibility(8);
        this.llSaveAsPDF.setVisibility(8);
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 302 && i2 == -1) {
            this.outputPath = intent.getExtras().getString("path");
            ProgressDialog progressDialog2 = new ProgressDialog(this.mContext);
            this.progressDialog = progressDialog2;
            progressDialog2.setProgressDrawable((Drawable) null);
            this.progressDialog.setProgressStyle(0);
            int i3 = this.whatSelected;
            if (i3 == 0) {
                this.progressDialog.setMessage("saving");
                this.progressDialog.show();
                this.mDocumentView.saveTo(this.outputPath, new SODocSaveListener() {
                    public void onComplete(int i, int i2) {
                        try {
                            DocViewActivity.this.progressDialog.hide();
                            DocViewActivity.this.progressDialog.dismiss();
                            if (i == 0) {
                                DocViewActivity.this.showMessage("The file was saved.");
                            } else {
                                DocViewActivity.this.showMessage("There was an error saving the file.");
                            }
                        } catch (Exception unused) {
                        }
                    }
                });
            } else if (i3 == 1) {
                this.progressDialog.setMessage("saving as pdf");
                this.progressDialog.show();
                this.mDocumentView.saveToPDF(this.outputPath, new SODocSaveListener() {
                    public void onComplete(int i, int i2) {
                        try {
                            DocViewActivity.this.progressDialog.hide();
                            DocViewActivity.this.progressDialog.dismiss();
                        } catch (Exception unused) {
                        }
                        if (i == 0) {
                            DocViewActivity docViewActivity = DocViewActivity.this;
                            Activity activity = docViewActivity.mContext;
                            if (activity == null) {
                                AdHelpMain adHelpMain = AdHelpMain.INSTANCE;
                                activity = AdHelpMain.currentActivity;
                            }
                            new AlertDialog.Builder(activity).setMessage("The file saved as pdf successfully.").setNegativeButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    AnalyticsHelp.getInstance().logEvent("event_app_editor_view_file_save_dialog_ok_pressed", (Map<String, String>) null);
                                    new RateAppBottomSheet("save_as_pdf_flow_completed", DocViewActivity.this, false).show(DocViewActivity.this.getSupportFragmentManager(), "RATEAPP");
                                }
                            }).setPositiveButton("Open Now", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent intent = null;
                                    AnalyticsHelp.getInstance().logEvent("event_app_editor_view_file_save_dialog_open_now_pressed", (Map<String, String>) null);
                                    ManageFiles manageFiles = new ManageFiles();
                                    DocViewActivity docViewActivity = DocViewActivity.this;
                                    String str = docViewActivity.outputPath;
                                    int intValue = IntentRedirectionConstants.SAVE_AS_PDF_REQUEST_CODE.intValue();
                                    try {
                                        int i2 = FilePreviewHandlingActivity.$r8$clinit;
                                        intent = new Intent(docViewActivity, FilePreviewHandlingActivity.class);
                                    } catch (ClassNotFoundException e) {
                                        e.printStackTrace();
                                    }
                                    AsyncJob.doInBackground(new AsyncJob.OnBackgroundJob(manageFiles, docViewActivity, str) {
                                        public final /* synthetic */ Activity val$mActivity;
                                        public final /* synthetic */ String val$path;

                                        public void doOnBackground(
/*
Method generation error in method: com.artifex.sonui.commonutils.ManageFiles.5.doOnBackground():void, dex: classes2.dex
                                        jadx.core.utils.exceptions.JadxRuntimeException: Method args not loaded: com.artifex.sonui.commonutils.ManageFiles.5.doOnBackground():void, class status: UNLOADED
                                        	at jadx.core.dex.nodes.MethodNode.getArgRegs(MethodNode.java:278)
                                        	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:116)
                                        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:313)
                                        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                                        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                                        	at java.util.ArrayList.forEach(ArrayList.java:1259)
                                        	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                        	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                                        	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                                        	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                                        	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                                        	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                                        	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                                        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                                        	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:676)
                                        	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:607)
                                        	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:364)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                                        	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                                        	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                                        	at jadx.core.codegen.InsnGen.generateMethodArguments(InsnGen.java:787)
                                        	at jadx.core.codegen.InsnGen.makeInvoke(InsnGen.java:728)
                                        	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:368)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:250)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:221)
                                        	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:109)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:55)
                                        	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                                        	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:211)
                                        	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:204)
                                        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:318)
                                        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                                        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                                        	at java.util.ArrayList.forEach(ArrayList.java:1259)
                                        	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                        	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                                        	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                                        	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                                        	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                                        	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                                        	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                                        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                                        	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:676)
                                        	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:607)
                                        	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:364)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                                        	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                                        	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                                        	at jadx.core.codegen.InsnGen.generateMethodArguments(InsnGen.java:787)
                                        	at jadx.core.codegen.InsnGen.makeInvoke(InsnGen.java:728)
                                        	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:368)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                                        	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                                        	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                                        	at jadx.core.codegen.InsnGen.addArgDot(InsnGen.java:91)
                                        	at jadx.core.codegen.InsnGen.makeInvoke(InsnGen.java:697)
                                        	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:368)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:250)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:221)
                                        	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:109)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:55)
                                        	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:142)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:62)
                                        	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                                        	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                                        	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:211)
                                        	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:204)
                                        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:318)
                                        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                                        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                                        	at java.util.ArrayList.forEach(ArrayList.java:1259)
                                        	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                        	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                                        	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                                        	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                                        	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                                        	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                                        	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                                        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                                        	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:676)
                                        	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:607)
                                        	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:364)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                                        	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                                        	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                                        	at jadx.core.codegen.InsnGen.generateMethodArguments(InsnGen.java:787)
                                        	at jadx.core.codegen.InsnGen.makeInvoke(InsnGen.java:728)
                                        	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:368)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:250)
                                        	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:221)
                                        	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:109)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:55)
                                        	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:142)
                                        	at jadx.core.codegen.RegionGen.connectElseIf(RegionGen.java:175)
                                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:152)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:62)
                                        	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                                        	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                                        	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:142)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:62)
                                        	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                                        	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                                        	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:211)
                                        	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:204)
                                        	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:318)
                                        	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                                        	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                                        	at java.util.ArrayList.forEach(ArrayList.java:1259)
                                        	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                        	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                                        	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                                        	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                                        	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                                        	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                                        	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                                        	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                                        	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                                        	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                                        	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:112)
                                        	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:78)
                                        	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:44)
                                        	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:33)
                                        	at jadx.core.codegen.CodeGen.generate(CodeGen.java:21)
                                        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:61)
                                        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
                                        
*/
                                    });
                                    intent.putExtra("isDark", CommonsMultiDexApplication.isDark);
                                    intent.putExtra("filePath", str);
                                    intent.putExtra("from_app", true);
                                    intent.putExtra("opened_from", "open_file_dialog_editor");
                                    intent.putExtra("open_directly", true);
                                    docViewActivity.startActivityForResult(intent, intValue);
                                    DocViewActivity.this.finish();
                                }
                            }).show();
                            return;
                        }
                        DocViewActivity docViewActivity2 = DocViewActivity.this;
                        boolean z = DocViewActivity.isSetup;
                        docViewActivity2.showMessage("There was an error saving the file.");
                    }
                });
            }
        } else if (i == 111) {
            if (Build.VERSION.SDK_INT < 30) {
                return;
            }
            if (Environment.isExternalStorageManager()) {
                startSaveActivity();
            } else {
                Toasty.error((Context) this.mContext, (int) R.string.failed_storage_permission).show();
            }
        } else if (i == IntentRedirectionConstants.SHARE_FILE_REQUEST_CODE.intValue()) {
            if (ShareFileHelper.getInstance().bottomSheetDialog != null) {
                ShareFileHelper.getInstance().bottomSheetDialog.cancel();
            }
            new RateAppBottomSheet("file_share_flow_completed", this, false).show(getSupportFragmentManager(), "RATEAPP");
        } else if (i == IntentRedirectionConstants.SAVE_AS_PDF_REQUEST_CODE.intValue()) {
            new RateAppBottomSheet("save_as_pdf_flow_completed", this, false).show(getSupportFragmentManager(), "RATEAPP");
        } else if (i == IntentRedirectionConstants.PRINT_REDIRECTION_REQUEST_CODE.intValue()) {
            new RateAppBottomSheet("print_flow_completed", this, false).show(getSupportFragmentManager(), "RATEAPP");
        }
    }

    public void onBackPressed() {
        ViewUtilsBase.getInstance().executeLogEvent("event_app_editor_backpress_button_click", "TAG", (String) null, "backpress button");
        SODocumentView sODocumentView = this.mDocumentView;
        if (sODocumentView != null) {
            try {
                sODocumentView.destroyDrawingCache();
            } catch (Exception e) {
                FirebaseCrashlytics.getInstance().log(e.getMessage());
            }
            if (this.mDocumentView.isDocumentModified()) {
                AdHelpMain adHelpMain = AdHelpMain.INSTANCE;
                AnonymousClass94 r1 = new Callable<Void>() {
                    public Object call() throws Exception {
                        DocViewActivity docViewActivity = DocViewActivity.this;
                        boolean z = DocViewActivity.isSetup;
                        docViewActivity.backPressRedirection();
                        return null;
                    }
                };
                Intrinsics.checkNotNull("showExitDialog");
                Log.d("AdHelpMain", "showExitDialog");
                HashMap hashMap = new HashMap();
                hashMap.put("activity", getClass().getSimpleName());
                if (AnalyticsHelp.instance == null) {
                    AnalyticsHelp.instance = new AnalyticsHelp((DefaultConstructorMarker) null);
                }
                AnalyticsHelp analyticsHelp = AnalyticsHelp.instance;
                if (analyticsHelp != null) {
                    analyticsHelp.logEvent("event_app_editor_exit_dialog_show", hashMap);
                }
                adHelpMain.createExitDialog(this);
                androidx.appcompat.app.AlertDialog alertDialog = AdHelpMain.exitDialog;
                if (alertDialog != null) {
                    Intrinsics.checkNotNull(alertDialog);
                    alertDialog.show();
                    if (!adHelpMain.isPremium()) {
                        Intrinsics.checkNotNull("rootNativeAdView is null");
                        Log.d("AdHelpMain", "rootNativeAdView is null");
                        androidx.appcompat.app.AlertDialog alertDialog2 = AdHelpMain.exitDialog;
                        Intrinsics.checkNotNull(alertDialog2);
                        LinearLayout linearLayout = (LinearLayout) alertDialog2.findViewById(R.id.nativeAdContainer);
                        Objects.requireNonNull(0, "set level its null");
                        Objects.requireNonNull(linearLayout, "set adcontainer its null, in case youre making a loading ad call make sure to set isCallForLoad as true in build of native template builder");
                        adHelpMain.renderPreloadedNative(new NativeTemplateBuilder(1005, 10002, 0, this, linearLayout, (DefaultConstructorMarker) null));
                    } else {
                        androidx.appcompat.app.AlertDialog alertDialog3 = AdHelpMain.exitDialog;
                        Intrinsics.checkNotNull(alertDialog3);
                        View findViewById = alertDialog3.findViewById(R.id.nativeAdContainer);
                        Intrinsics.checkNotNull(findViewById);
                        R$layout.gone(findViewById);
                    }
                    androidx.appcompat.app.AlertDialog alertDialog4 = AdHelpMain.exitDialog;
                    Intrinsics.checkNotNull(alertDialog4);
                    View findViewById2 = alertDialog4.findViewById(R.id.btn_disconnect);
                    androidx.appcompat.app.AlertDialog alertDialog5 = AdHelpMain.exitDialog;
                    Intrinsics.checkNotNull(alertDialog5);
                    TextView textView = (TextView) alertDialog5.findViewById(R.id.text);
                    Intrinsics.checkNotNull(textView);
                    textView.setText("Do you want to close this document without saving?");
                    Intrinsics.checkNotNull(findViewById2);
                    findViewById2.setOnClickListener(new RenameFileDialog$$ExternalSyntheticLambda0((Activity) this, (Callable) r1));
                    androidx.appcompat.app.AlertDialog alertDialog6 = AdHelpMain.exitDialog;
                    Intrinsics.checkNotNull(alertDialog6);
                    View findViewById3 = alertDialog6.findViewById(R.id.btn_cancel);
                    Intrinsics.checkNotNull(findViewById3);
                    findViewById3.setOnClickListener(new SubscriptionPlan$$ExternalSyntheticLambda0((Activity) this));
                    return;
                }
                return;
            }
            backPressRedirection();
            return;
        }
        backPressRedirection();
    }

    public void onCreate(Bundle bundle) {
        if (!isSetup) {
            Utilities.setDataLeakHandlers(new DataLeakHandlers());
            SOPreferences.mPersistentStorage = new PersistentStorage();
            ArDkLib.mClipboardHandler = new ClipboardHandler();
            ArDkLib.mSecureFS = new SecureFS();
            FileUtils.init();
            isSetup = true;
        }
        this.openedFrom = getIntent().getStringExtra("opened_from");
        this.fromApp = getIntent().getBooleanExtra("from_app", false);
        String str = this.openedFrom;
        if (str != null && str.equalsIgnoreCase("choose_file")) {
            AnalyticsHelp.getInstance().logEvent("event_app_choose_file_editor_opened", (Map<String, String>) null);
        }
        HashMap hashMap = new HashMap();
        hashMap.put("openedFrom", this.openedFrom);
        AnalyticsHelp.getInstance().logEvent("event_app_editor_sdk_editor_activity_started", hashMap);
        setContentView((int) R.layout.activity_doc_view);
        this.mContext = this;
        this.filePath = getIntent().getExtras().getString("filePath");
        this.fileName = new File(this.filePath).getName();
        StringBuilder m = c$$ExternalSyntheticOutline0.m(".");
        m.append(FilenameUtils.getExtension(this.fileName));
        this.fileExt = m.toString();
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.txtActivityTitle = (TextView) findViewById(R.id.txtActivityTitle);
        ImageView imageView = (ImageView) findViewById(R.id.imvFullScreen);
        this.imvFullScreen = imageView;
        imageView.setImageDrawable(getResources().getDrawable(R.drawable.ic_full_screen));
        this.llDocView = (LinearLayout) findViewById(R.id.llDocView);
        this.llButtonView = (LinearLayout) findViewById(R.id.llButtonView);
        this.btnAllowAccess = (Button) findViewById(R.id.btnAllowAccess);
        this.fontPlus = (AppCompatImageView) findViewById(R.id.imvFontPlusBottom);
        this.fontMinus = (AppCompatImageView) findViewById(R.id.imvFontMinusBottom);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        if (PermissionUtils.checkPermission(this) || PermissionUtils.checkWritePermission(this)) {
            allDocControllerInit();
        } else {
            this.llButtonView.setVisibility(0);
            this.btnAllowAccess.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    AnalyticsHelp.getInstance().logEvent("event_app_editor_view_permission_asked", (Map<String, String>) null);
                    Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                    intent.setData(Uri.fromParts("package", DocViewActivity.this.getPackageName(), (String) null));
                    DocViewActivity.this.allowAccessButtonCallback.launch(intent, (ActivityOptionsCompat) null);
                }
            });
        }
        this.fontPlus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DocViewActivity.access$000(DocViewActivity.this);
            }
        });
        this.fontMinus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                DocViewActivity.access$100(DocViewActivity.this);
            }
        });
        getWindow().getDecorView().setSystemUiVisibility(1030);
        super.onCreate(bundle);
    }

    public void onGetCallableFailure() {
    }

    public void onGetCallableSuccess() {
        if (this.startSaveActivityCalled) {
            startSaveActivity();
        }
    }

    public void onMLSuccess(boolean z) {
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return true;
        }
        onBackPressed();
        return true;
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        boolean z = false;
        if (i != 111) {
            try {
                if (iArr.length <= 0) {
                    AnalyticsHelp.getInstance().logEvent("event_app_editor_write_access_failed", (Map<String, String>) null);
                    backPressRedirection();
                } else if (iArr[0] == 0) {
                    if (i == 10001) {
                        AnalyticsHelp.getInstance().logEvent("event_app_editor_write_access_allowed", (Map<String, String>) null);
                        allDocControllerInit();
                    }
                } else if (iArr[0] == -1) {
                    AnalyticsHelp.getInstance().logEvent("event_app_editor_write_access_failed", (Map<String, String>) null);
                }
            } catch (Exception unused) {
            }
        } else if (iArr.length > 0) {
            boolean z2 = iArr[0] == 0;
            if (iArr[1] == 0) {
                z = true;
            }
            if (!z2 || !z) {
                AnalyticsHelp.getInstance().logEvent("event_app_editor_write_access_failed", (Map<String, String>) null);
                Toasty.error((Context) this.mContext, (int) R.string.allow_permission_for_storage_access).show();
                return;
            }
            AnalyticsHelp.getInstance().logEvent("event_app_editor_write_access_allowed", (Map<String, String>) null);
            startSaveActivity();
        }
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        if (z) {
            getWindow().getDecorView().setSystemUiVisibility(5894);
        }
    }

    public final void redirectToTool(String str, String str2) {
        try {
            Uri fromFile = Uri.fromFile(new File(this.filePath));
            Intent intent = new Intent(this.mContext, Class.forName(str));
            try {
                intent.setData(fromFile);
            } catch (Exception e) {
                Log.e("DocViewActivityArtifact", e.getLocalizedMessage().toString());
            }
            intent.putExtra("TOOL_TAG", str2);
            intent.putExtra("isFromPreview", true);
            intent.putExtra("from_app", true);
            showInterAds("actionBaseClick", true, intent, IntentRedirectionConstants.TOOL_REDIRECTION_REQUEST_CODE.intValue());
        } catch (Exception unused) {
        }
    }

    public final void saveAsPdf() {
        callEvents("save_as_pdf");
        if (!this.configOptions.isEditingEnabled()) {
            startSaveActivity();
        } else if (this.mDocumentView.isDocumentModified()) {
            BillingHelp billingHelp = BillingHelp.INSTANCE;
            if (!billingHelp.isPremiumEnabled(this.mContext) || !billingHelp.isPremium()) {
                showEditFileDialog(this.mContext, this.placementId, (String) null, (String) null, (Intent) null, "save_as_pdf", this.fileExt, "To save your document as pdf", false);
                return;
            }
            startSaveActivity();
        } else {
            startSaveActivity();
        }
    }

    public final void scaleBy(float f) {
        float scaleFactor = this.mDocumentView.getScaleFactor();
        float f2 = scaleFactor + f;
        this.mDocumentView.setScaleAndScroll(f2, this.mDocumentView.getScrollPositionX(), this.mDocumentView.getScrollPositionY());
    }

    public final void scrollBy(int i) {
        this.mDocumentView.setScaleAndScroll(this.mDocumentView.getScaleFactor(), this.mDocumentView.getScrollPositionX(), this.mDocumentView.getScrollPositionY() + i);
    }

    public final void setAdapter(String str, Boolean bool) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i = displayMetrics.widthPixels;
        EditorToolsAdapter.EditorToolOnClickListener editorToolOnClickListener2 = bool.booleanValue() ? this.editorToolOnClickListener : this;
        Objects.requireNonNull(str);
        char c = 65535;
        switch (str.hashCode()) {
            case 1481220:
                if (str.equals(".pdf")) {
                    c = 0;
                    break;
                }
                break;
            case 1481606:
                if (str.equals(".ppt")) {
                    c = 1;
                    break;
                }
                break;
            case 1489169:
                if (str.equals(".xls")) {
                    c = 2;
                    break;
                }
                break;
            case 45570926:
                if (str.equals(".docx")) {
                    c = 3;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
                this.editorToolsAdapter = new EditorToolsAdapter(i, bool, EditorBottomBarConstants.editorPdfToolsList, editorToolOnClickListener2);
                return;
            case 1:
                this.editorToolsAdapter = new EditorToolsAdapter(i, bool, Constants.editorPPTToolsList, editorToolOnClickListener2);
                return;
            case 2:
                if (!getString(R.string.app_name).toLowerCase().contains("xls")) {
                    this.editorToolsAdapter = new EditorToolsAdapter(i, bool, Constants.editorXlsToolsList, editorToolOnClickListener2);
                    return;
                } else if (bool.booleanValue()) {
                    this.editorToolsAdapter = new EditorToolsAdapter(i, bool, EditorBottomBarConstants.bottomXlsToolsListForXLSAPP, editorToolOnClickListener2);
                    return;
                } else {
                    this.editorToolsAdapter = new EditorToolsAdapter(i, bool, Constants.editorXlsToolsListForXLSAPP, editorToolOnClickListener2);
                    return;
                }
            case 3:
                if (getString(R.string.app_name).toLowerCase().contains("docx")) {
                    this.editorToolsAdapter = new EditorToolsAdapter(i, bool, Constants.editorDocxToolsListDocX, editorToolOnClickListener2);
                    return;
                }
                this.editorToolsAdapter = new EditorToolsAdapter(i, bool, Constants.editorDocxToolsList, editorToolOnClickListener2);
                if (bool.booleanValue()) {
                    this.editorToolsAdapter = new EditorToolsAdapter(i, bool, EditorBottomBarConstants.bottomDocxToolsListForXLSAPP, editorToolOnClickListener2);
                    return;
                }
                return;
            default:
                return;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:66:0x015b, code lost:
        if (r5.fileType.endsWith(".jpeg") != false) goto L_0x0180;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:75:0x019a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setFabButtonColor() {
        /*
            r5 = this;
            java.lang.String r0 = r5.fileName
            r1 = 2131100005(0x7f060165, float:1.781238E38)
            r2 = 2131099946(0x7f06012a, float:1.781226E38)
            if (r0 == 0) goto L_0x016f
            java.lang.String r0 = r5.fileType
            java.lang.String r3 = ".pdf"
            boolean r0 = r0.endsWith(r3)
            if (r0 == 0) goto L_0x0019
            r1 = 2131100577(0x7f0603a1, float:1.781354E38)
            goto L_0x0180
        L_0x0019:
            java.lang.String r0 = r5.fileType
            java.lang.String r3 = ".docx"
            boolean r0 = r0.endsWith(r3)
            if (r0 != 0) goto L_0x016b
            java.lang.String r0 = r5.fileType
            java.lang.String r3 = ".doc"
            boolean r0 = r0.endsWith(r3)
            if (r0 != 0) goto L_0x016b
            java.lang.String r0 = r5.fileType
            java.lang.String r3 = ".docm"
            boolean r0 = r0.endsWith(r3)
            if (r0 != 0) goto L_0x016b
            java.lang.String r0 = r5.fileType
            java.lang.String r3 = ".dot"
            boolean r0 = r0.endsWith(r3)
            if (r0 != 0) goto L_0x016b
            java.lang.String r0 = r5.fileType
            java.lang.String r3 = ".dotx"
            boolean r0 = r0.endsWith(r3)
            if (r0 == 0) goto L_0x004d
            goto L_0x016b
        L_0x004d:
            java.lang.String r0 = r5.fileType
            java.lang.String r3 = ".txt"
            boolean r0 = r0.endsWith(r3)
            r3 = 8
            if (r0 == 0) goto L_0x0063
            r1 = 2131101157(0x7f0605e5, float:1.7814716E38)
            android.widget.ImageView r0 = r5.imvFullScreen
            r0.setVisibility(r3)
            goto L_0x0180
        L_0x0063:
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".pptx"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".pptm"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".ppt"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".potx"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".potm"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".pot"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".ppsx"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".ppsm"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".pps"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".ppam"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".ppa"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x0167
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".odp"
            boolean r0 = r0.endsWith(r4)
            if (r0 == 0) goto L_0x00dd
            goto L_0x0167
        L_0x00dd:
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".xlsx"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x015e
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".xlsm"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x015e
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".xlsb"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x015e
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".xlam"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x015e
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".xltm"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x015e
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".xltx"
            boolean r0 = r0.endsWith(r4)
            if (r0 != 0) goto L_0x015e
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".xls"
            boolean r0 = r0.endsWith(r4)
            if (r0 == 0) goto L_0x0124
            goto L_0x015e
        L_0x0124:
            java.lang.String r0 = r5.fileType
            java.lang.String r4 = ".csv"
            boolean r0 = r0.endsWith(r4)
            if (r0 == 0) goto L_0x0134
            android.widget.ImageView r0 = r5.imvFullScreen
            r0.setVisibility(r3)
            goto L_0x0163
        L_0x0134:
            java.lang.String r0 = r5.fileType
            java.lang.String r2 = ".html"
            boolean r0 = r0.endsWith(r2)
            if (r0 == 0) goto L_0x013f
            goto L_0x0180
        L_0x013f:
            java.lang.String r0 = r5.fileType
            java.lang.String r2 = ".png"
            boolean r0 = r0.endsWith(r2)
            if (r0 != 0) goto L_0x0180
            java.lang.String r0 = r5.fileType
            java.lang.String r2 = ".jpg"
            boolean r0 = r0.endsWith(r2)
            if (r0 != 0) goto L_0x0180
            java.lang.String r0 = r5.fileType
            java.lang.String r2 = ".jpeg"
            boolean r0 = r0.endsWith(r2)
            if (r0 == 0) goto L_0x017d
            goto L_0x0180
        L_0x015e:
            android.widget.ImageView r0 = r5.imvFullScreen
            r0.setVisibility(r3)
        L_0x0163:
            r1 = 2131099946(0x7f06012a, float:1.781226E38)
            goto L_0x0180
        L_0x0167:
            r1 = 2131100589(0x7f0603ad, float:1.7813564E38)
            goto L_0x0180
        L_0x016b:
            r1 = 2131099937(0x7f060121, float:1.7812241E38)
            goto L_0x0180
        L_0x016f:
            androidx.transition.ViewUtilsBase r0 = androidx.transition.ViewUtilsBase.getInstance()
            r1 = 0
            java.lang.String r2 = "event_app_editor_filename_null"
            java.lang.String r3 = "DocViewActivityArtifact"
            java.lang.String r4 = "null"
            r0.executeLogEvent(r2, r3, r1, r4)
        L_0x017d:
            r1 = 2131099774(0x7f06007e, float:1.781191E38)
        L_0x0180:
            com.github.clans.fab.FloatingActionButton r0 = r5.fabEdit     // Catch:{ Exception -> 0x019a }
            android.content.res.Resources r2 = r5.getResources()     // Catch:{ Exception -> 0x019a }
            int r2 = r2.getColor(r1)     // Catch:{ Exception -> 0x019a }
            r0.setColorNormal(r2)     // Catch:{ Exception -> 0x019a }
            com.github.clans.fab.FloatingActionButton r0 = r5.fabEdit     // Catch:{ Exception -> 0x019a }
            android.content.res.Resources r2 = r5.getResources()     // Catch:{ Exception -> 0x019a }
            int r2 = r2.getColor(r1)     // Catch:{ Exception -> 0x019a }
            r0.setColorPressed(r2)     // Catch:{ Exception -> 0x019a }
        L_0x019a:
            com.google.android.material.tabs.TabLayout r0 = r5.tlMenus     // Catch:{ Exception -> 0x01c6 }
            android.content.res.Resources r2 = r5.getResources()     // Catch:{ Exception -> 0x01c6 }
            int r2 = r2.getColor(r1)     // Catch:{ Exception -> 0x01c6 }
            r0.setSelectedTabIndicatorColor(r2)     // Catch:{ Exception -> 0x01c6 }
            com.google.android.material.tabs.TabLayout r0 = r5.tlMenus     // Catch:{ Exception -> 0x01c6 }
            android.content.res.Resources r2 = r5.getResources()     // Catch:{ Exception -> 0x01c6 }
            r3 = 2131099719(0x7f060047, float:1.78118E38)
            int r2 = r2.getColor(r3)     // Catch:{ Exception -> 0x01c6 }
            android.content.res.Resources r3 = r5.getResources()     // Catch:{ Exception -> 0x01c6 }
            int r1 = r3.getColor(r1)     // Catch:{ Exception -> 0x01c6 }
            java.util.Objects.requireNonNull(r0)     // Catch:{ Exception -> 0x01c6 }
            android.content.res.ColorStateList r1 = com.google.android.material.tabs.TabLayout.createColorStateList(r2, r1)     // Catch:{ Exception -> 0x01c6 }
            r0.setTabTextColors(r1)     // Catch:{ Exception -> 0x01c6 }
        L_0x01c6:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.artifex.sonui.artifactsdk.activity.DocViewActivity.setFabButtonColor():void");
    }

    public void showEditFileDialog(final Activity activity, String str, String str2, String str3, Intent intent, final String str4, String str5, String str6, boolean z) {
        if (getResources().getBoolean(R.bool.purchasely_screen_for_dialogs)) {
            FreeTrialActivityHelper.Builder builder = new FreeTrialActivityHelper.Builder();
            builder.context = activity;
            builder.placementId = str;
            builder.redirectTo = str2;
            builder.redirectionUrl = null;
            builder.redirectionIntent = null;
            builder.openedFrom = str4;
            builder.fileExtension = str5;
            builder.build();
            builder.redirectToFreeTrialScreen();
            return;
        }
        ViewUtilsBase.getInstance().executeLogEvent("event_app_pro_dialog_shown", str4, (String) null, "");
        AlertDialog.Builder builder2 = new AlertDialog.Builder(activity);
        View inflate = activity.getLayoutInflater().inflate(R.layout.v2_dialog_edit_file_ppt, (ViewGroup) null);
        builder2.setView(inflate);
        this.imvCloseEPD = (ImageView) inflate.findViewById(R.id.imvCloseEPD);
        this.txtEditTitle = (TextView) inflate.findViewById(R.id.txtEditTitle);
        this.llGetPremium = (LinearLayoutCompat) inflate.findViewById(R.id.llGetPremium);
        this.txtOR = (AppCompatTextView) inflate.findViewById(R.id.txtOR);
        this.llWatchVideo = (LinearLayoutCompat) inflate.findViewById(R.id.llWatchVideo);
        this.tvEditPPT = (TextView) inflate.findViewById(R.id.tvEditPPT);
        AppCompatImageView appCompatImageView = (AppCompatImageView) inflate.findViewById(R.id.imgDetails);
        if (!str6.isEmpty()) {
            SkuDetailsAdapter$$ExternalSyntheticOutline0.m("", str6, this.txtEditTitle);
        }
        appCompatImageView.setBackgroundDrawable(activity.getDrawable(R.mipmap.img_fab_dialog_details));
        AppCompatImageView appCompatImageView2 = (AppCompatImageView) inflate.findViewById(R.id.mainIcon);
        if (this.fileType.equalsIgnoreCase(".pdf")) {
            this.tvEditPPT.setText("PPT Edit");
            appCompatImageView2.setImageDrawable(activity.getDrawable(R.drawable.dialog_title_image_edit));
        } else if (this.fileType.equalsIgnoreCase(".ppt")) {
            this.tvEditPPT.setText("PPT Edit");
            appCompatImageView2.setImageDrawable(activity.getDrawable(R.drawable.dialog_title_image_edit_ppt));
        } else if (this.fileType.equalsIgnoreCase(".xls")) {
            this.tvEditPPT.setText("XLS Edit");
            appCompatImageView2.setImageDrawable(activity.getDrawable(R.drawable.dialog_title_image_edit_xls));
        } else if (this.fileType.equalsIgnoreCase(".docx")) {
            this.tvEditPPT.setText("DOC Edit");
            appCompatImageView2.setImageDrawable(activity.getDrawable(R.drawable.dialog_title_image_edit_doc));
        } else {
            appCompatImageView2.setImageDrawable(activity.getDrawable(R.drawable.dialog_title_image_edit));
        }
        if (z) {
            this.txtOR.setVisibility(0);
            this.llWatchVideo.setVisibility(0);
        } else {
            this.txtOR.setVisibility(8);
            this.llWatchVideo.setVisibility(8);
        }
        this.imvCloseEPD.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ViewUtilsBase instance = ViewUtilsBase.getInstance();
                StringBuilder m = c$$ExternalSyntheticOutline0.m("event_app_editor_premium_dialog_close_");
                m.append(DocViewActivity.this.fileExt);
                instance.executeLogEvent(m.toString(), "DocViewActivityArtifact", (String) null, "SHOW");
                try {
                    AlertDialog alertDialog = DocViewActivity.this.editFileDialog1;
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                        DocViewActivity.this.editFileDialog1 = null;
                    }
                } catch (Exception unused) {
                }
            }
        });
        this.llGetPremium.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ViewUtilsBase instance = ViewUtilsBase.getInstance();
                StringBuilder m = c$$ExternalSyntheticOutline0.m("event_app_editor_premium_dialog_purchase_click_");
                m.append(DocViewActivity.this.fileExt);
                instance.executeLogEvent(m.toString(), "DocViewActivityArtifact", (String) null, "SHOW");
                try {
                    AlertDialog alertDialog = DocViewActivity.this.editFileDialog1;
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                        DocViewActivity.this.editFileDialog1 = null;
                    }
                } catch (Exception unused) {
                }
                BillingHelp.INSTANCE.openFeatureExplainer(activity, str4);
            }
        });
        this.llWatchVideo.setOnClickListener(new View.OnClickListener((Intent) null) {
            public void onClick(View view) {
                AdHelpMain.INSTANCE.showRewarded((Callable) new Callable<Void>() {
                    public Object call() throws Exception {
                        AnonymousClass91 r0 = AnonymousClass91.this;
                        Intent intent = null;
                        if (intent == null) {
                            return null;
                        }
                        activity.startActivity(intent);
                        return null;
                    }
                }, "EDIT_DOCUMENT");
                AlertDialog alertDialog = DocViewActivity.this.editFileDialog1;
                if (alertDialog != null) {
                    alertDialog.dismiss();
                    DocViewActivity.this.editFileDialog1 = null;
                }
            }
        });
        AlertDialog create = builder2.create();
        this.editFileDialog1 = create;
        create.setCancelable(false);
        this.editFileDialog1.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        if (!activity.isFinishing()) {
            ViewUtilsBase instance = ViewUtilsBase.getInstance();
            StringBuilder m = c$$ExternalSyntheticOutline0.m("event_app_editor_premium_dialog_show_");
            m.append(this.fileExt);
            instance.executeLogEvent(m.toString(), "DocViewActivityArtifact", (String) null, "SHOW");
            this.editFileDialog1.show();
        }
    }

    public void showInterAds(final String str, boolean z, final Intent intent, final int i) {
        intent.putExtra("from_app", true);
        AdHelpMain.INSTANCE.showInterstitial(new Callable<Void>() {
            public Object call() throws Exception {
                DocViewActivity.this.startActivityForResult(intent, i);
                if (!str.equals("closeClick")) {
                    return null;
                }
                DocViewActivity.this.finish();
                return null;
            }
        }, z, str);
    }

    public final void showMessage(String str) {
        try {
            new AlertDialog.Builder(this.mContext).setMessage(str).setPositiveButton("Ok", new DialogInterface.OnClickListener(this) {
                public void onClick(DialogInterface dialogInterface, int i) {
                }
            }).show();
        } catch (Exception unused) {
        }
    }

    public void startSaveActivity() {
        if (PermissionUtils.checkPermission(this.mContext)) {
            Intent intent = new Intent(this.mContext, SaveAsActivity.class);
            intent.putExtra("path", this.filePath);
            showInterAds("save_as_pdf_clicked", true, intent, 302);
            return;
        }
        this.startSaveActivityCalled = true;
        if (PermissionUtils.isAndroid11()) {
            PermissionUtils.requestPermission("retryFailedAccessRequest", this.mContext, PermissionUtils.getCallable("success", this), PermissionUtils.getCallable("failure", this));
            return;
        }
        AnalyticsHelp.getInstance().logEvent("event_app_home_write_access_asked", (Map<String, String>) null);
        PermissionUtils.requestPermission(this.mContext, 111);
    }

    public final void updateUI() {
        SODocumentView sODocumentView = this.mDocumentView;
        if (sODocumentView != null) {
            this.llDeleteSelection.setEnabled(sODocumentView.canDeleteSelection());
            if (this.mDocumentView.shouldConfigureSaveAsPDFButton()) {
                ConfigOptions appConfigOptions = ArDkLib.getAppConfigOptions();
                if (appConfigOptions == null || !appConfigOptions.isSaveAsPdfEnabled()) {
                    this.llSaveAsPDF.setEnabled(false);
                } else {
                    this.llSaveAsPDF.setEnabled(true);
                }
            }
            this.imvUndo.setEnabled(this.mDocumentView.canUndo());
            if (this.mContext != null) {
                if (this.imvUndo.isEnabled()) {
                    this.imvUndo.setColorFilter(ContextCompat.getColor(this.mContext, R.color.black), PorterDuff.Mode.SRC_IN);
                } else {
                    this.imvUndo.setColorFilter(ContextCompat.getColor(this.mContext, R.color.grey), PorterDuff.Mode.SRC_IN);
                }
                this.imvRedo.setEnabled(this.mDocumentView.canRedo());
                if (this.imvRedo.isEnabled()) {
                    this.imvRedo.setColorFilter(ContextCompat.getColor(this.mContext, R.color.black), PorterDuff.Mode.SRC_IN);
                } else {
                    this.imvRedo.setColorFilter(ContextCompat.getColor(this.mContext, R.color.grey), PorterDuff.Mode.SRC_IN);
                }
                if (!this.fileType.endsWith(".pdf")) {
                    try {
                        if (this.mDocumentView.getSelectionFontName() == null) {
                            this.txtFontName.setText("Arial");
                            this.imvSelectFont.setEnabled(false);
                        } else {
                            this.imvSelectFont.setEnabled(true);
                            AppCompatTextView appCompatTextView = this.txtFontName;
                            appCompatTextView.setText("" + this.mDocumentView.getSelectionFontName());
                        }
                    } catch (Exception unused) {
                        Log.d("DocViewActivityArtifact", "updateUI: 0");
                    }
                    try {
                        if (this.mDocumentView.getSelectionFontSize() <= 0.0d) {
                            this.txtTextSize.setText("12");
                            this.imvFontPlus.setEnabled(false);
                            this.imvFontMinus.setEnabled(false);
                        } else {
                            this.imvFontPlus.setEnabled(true);
                            this.imvFontMinus.setEnabled(true);
                            AppCompatTextView appCompatTextView2 = this.txtTextSize;
                            appCompatTextView2.setText("" + this.mDocumentView.getSelectionFontSize());
                            AppCompatTextView appCompatTextView3 = this.bottomTextSize;
                            appCompatTextView3.setText("" + this.mDocumentView.getSelectionFontSize());
                        }
                    } catch (Exception unused2) {
                        Log.d("DocViewActivityArtifact", "updateUI: 0");
                    }
                }
                boolean isDrawModeOn = this.mDocumentView.isDrawModeOn();
                LinearLayoutCompat linearLayoutCompat = this.llDrawSubMenu;
                if (isDrawModeOn) {
                    linearLayoutCompat.setBackground(getResources().getDrawable(R.drawable.btn_selected));
                    this.tvDraw.setTextColor(getResources().getColor(R.color.white));
                    this.imgDraw.setColorFilter(ContextCompat.getColor(this.mContext, R.color.white), PorterDuff.Mode.SRC_IN);
                    return;
                }
                linearLayoutCompat.setBackgroundColor(getResources().getColor(R.color.light_transparent));
                this.tvDraw.setTextColor(getResources().getColor(R.color.subMenuColor));
                this.imgDraw.setColorFilter(ContextCompat.getColor(this.mContext, R.color.subMenuColor), PorterDuff.Mode.SRC_IN);
            }
        }
    }

    public final void urlRedirection(String str) {
        boolean z;
        try {
            z = str.startsWith("https://play.google.com/store/apps/details?id=");
        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().log(e.getMessage());
            z = false;
        }
        if (z) {
            UtilsApp.redirectToPlayStore(this.mContext, str);
        }
    }
}
