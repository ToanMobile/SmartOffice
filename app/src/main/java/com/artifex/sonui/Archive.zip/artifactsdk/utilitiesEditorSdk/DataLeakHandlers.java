package com.artifex.sonui.artifactsdk.utilitiesEditorSdk;

import a.a.a.a.a.c$$ExternalSyntheticOutline0;
import a.a.a.a.b.f.a$$ExternalSyntheticOutline0;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.webkit.MimeTypeMap;
import android.widget.TextView;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.AlertDialog;
import androidx.concurrent.futures.AbstractResolvableFuture$$ExternalSyntheticOutline1;
import androidx.constraintlayout.core.widgets.Barrier$$ExternalSyntheticOutline0;
import androidx.core.content.FileProvider;
import androidx.fragment.app.BackStackRecord$$ExternalSyntheticOutline0;
import com.applovin.sdk.AppLovinEventTypes;
import com.artifex.solib.ArDkDoc;
import com.artifex.solib.ArDkLib;
import com.artifex.solib.ConfigOptions;
import com.artifex.solib.FileUtils;
import com.artifex.solib.MuPDFDoc;
import com.artifex.solib.SODocSaveListener;
import com.artifex.solib.SOSecureFS;
import com.artifex.solib.Worker;
import com.artifex.sonui.editor.NUIDocView;
import com.artifex.sonui.editor.PrintHelperPdf;
import com.artifex.sonui.editor.SOCustomSaveComplete;
import com.artifex.sonui.editor.SODataLeakHandlers;
import com.artifex.sonui.editor.SODocSession;
import com.artifex.sonui.editor.SOSaveAsComplete;
import com.artifex.sonui.editor.TwoBarProgressDialog;
import com.artifex.sonui.editor.Utilities;
import com.rpdev.document.manager.reader.allfiles.R;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class DataLeakHandlers implements SODataLeakHandlers {
    public Activity mActivity;
    public ConfigOptions mConfigOptions;
    public ArrayList<String> mDeleteOnClose = null;
    public NUIDocView mDocViewForInsert;
    public String mImagePath;
    public ProgressDialog mProgressDialog;
    public SOSecureFS mSecureFs;
    public String mSecurePath;
    public String mSecurePrefix;
    public String mTempFolderPath;
    public String mTempPhotoFolderPath;

    public void customSaveHandler(String str, ArDkDoc arDkDoc, String str2, SOCustomSaveComplete sOCustomSaveComplete) throws UnsupportedOperationException, IOException {
    }

    public final void displayDialogue(String str, String str2) {
        AnonymousClass1 r0 = new AlertDialog(this, new ContextThemeWrapper(this.mActivity, R.style.AlertDialogTheme)) {
            public boolean dispatchTouchEvent(MotionEvent motionEvent) {
                dismiss();
                return false;
            }
        };
        r0.setCancelable(true);
        r0.setCanceledOnTouchOutside(true);
        r0.setTitle(str);
        AlertController alertController = r0.mAlert;
        alertController.mMessage = str2;
        TextView textView = alertController.mMessageView;
        if (textView != null) {
            textView.setText(str2);
        }
        r0.show();
    }

    public final void displayProgressDialogue(String str, String str2, boolean z) {
        ProgressDialog progressDialog = new ProgressDialog(this.mActivity, R.style.AlertDialogTheme);
        this.mProgressDialog = progressDialog;
        progressDialog.setIndeterminate(true);
        this.mProgressDialog.setCancelable(z);
        this.mProgressDialog.setTitle(str);
        this.mProgressDialog.setMessage(str2);
        this.mProgressDialog.show();
    }

    public void doInsert() {
        if (this.mImagePath != null && this.mDocViewForInsert != null) {
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                    dataLeakHandlers.mDocViewForInsert.doInsertImage(dataLeakHandlers.mImagePath);
                    DataLeakHandlers dataLeakHandlers2 = DataLeakHandlers.this;
                    dataLeakHandlers2.mDocViewForInsert = null;
                    dataLeakHandlers2.mImagePath = null;
                    ProgressDialog progressDialog = dataLeakHandlers2.mProgressDialog;
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                        DataLeakHandlers.this.mProgressDialog = null;
                    }
                }
            }, 50);
        }
    }

    public void exportPdfAsHandler(String str, String str2, ArDkDoc arDkDoc) throws UnsupportedOperationException {
        final String str3;
        if (this.mConfigOptions.mSettingsBundle.getBoolean("PdfExportAsEnabledKey", true)) {
            displayProgressDialogue(AbstractResolvableFuture$$ExternalSyntheticOutline1.m("Exporting Document As '", str2, "'"), "", false);
            String m = Barrier$$ExternalSyntheticOutline0.m(new StringBuilder(), this.mTempFolderPath, str);
            int lastIndexOf = m.lastIndexOf(46);
            if (lastIndexOf == -1) {
                str3 = AbstractResolvableFuture$$ExternalSyntheticOutline1.m(m, ".", str2);
            } else {
                str3 = m.substring(0, lastIndexOf) + "." + str2;
            }
            arDkDoc.exportTo(str3, new SODocSaveListener() {
                public void onComplete(int i, int i2) {
                    ProgressDialog progressDialog = DataLeakHandlers.this.mProgressDialog;
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                        DataLeakHandlers.this.mProgressDialog = null;
                    }
                    if (i == 0) {
                        DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                        StringBuilder m = c$$ExternalSyntheticOutline0.m("Document exported to '");
                        m.append(str3);
                        m.append("'.\n\nPlease implement a custom exportAs handler");
                        dataLeakHandlers.displayDialogue("Information", m.toString());
                        return;
                    }
                    DataLeakHandlers.this.displayDialogue("Information", String.format("exportPdfAsHandler failed: %d %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                }
            }, str2);
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void finaliseDataLeakHandlers() {
        if (this.mDeleteOnClose != null) {
            for (int i = 0; i < this.mDeleteOnClose.size(); i++) {
                FileUtils.deleteFile(this.mDeleteOnClose.get(i));
            }
            this.mDeleteOnClose.clear();
        }
    }

    public void initDataLeakHandlers(Activity activity, ConfigOptions configOptions) throws IOException {
        this.mConfigOptions = configOptions;
        this.mActivity = activity;
        this.mDocViewForInsert = null;
        this.mImagePath = null;
        try {
            SOSecureFS sOSecureFS = ArDkLib.mSecureFS;
            this.mSecureFs = sOSecureFS;
            if (sOSecureFS != null) {
                this.mSecurePath = sOSecureFS.getSecurePath();
                this.mSecurePrefix = this.mSecureFs.getSecurePrefix();
                StringBuilder sb = new StringBuilder();
                sb.append(FileUtils.getTempPathRoot(this.mActivity));
                String str = File.separator;
                String m = BackStackRecord$$ExternalSyntheticOutline0.m(sb, str, "dataleak", str);
                this.mTempFolderPath = m;
                if (FileUtils.fileExists(m) || FileUtils.createDirectory(this.mTempFolderPath)) {
                    this.mTempPhotoFolderPath = this.mActivity.getCacheDir() + str + "dataleak" + str;
                    File file = new File(this.mTempPhotoFolderPath);
                    if (file.exists() || file.mkdirs()) {
                        this.mDeleteOnClose = new ArrayList<>();
                        return;
                    }
                    throw new IOException();
                }
                throw new IOException();
            }
            throw new ClassNotFoundException();
        } catch (ExceptionInInitializerError unused) {
            Log.e("DataLeakHandlers", String.format("DataLeakHandlers experienced unexpected exception [%s]", new Object[]{"ExceptionInInitializerError"}));
        } catch (LinkageError unused2) {
            Log.e("DataLeakHandlers", String.format("DataLeakHandlers experienced unexpected exception [%s]", new Object[]{"LinkageError"}));
        } catch (SecurityException unused3) {
            Log.e("DataLeakHandlers", String.format("DataLeakHandlers experienced unexpected exception [%s]", new Object[]{"SecurityException"}));
        } catch (ClassNotFoundException unused4) {
            Log.i("DataLeakHandlers", "SecureFS implementation unavailable");
        }
    }

    public void insertImageHandler(NUIDocView nUIDocView) throws UnsupportedOperationException {
        if (this.mConfigOptions.isImageInsertEnabled()) {
            this.mDocViewForInsert = nUIDocView;
            Intent intent = new Intent("android.intent.action.GET_CONTENT");
            intent.setType("image/*");
            this.mActivity.startActivityForResult(Intent.createChooser(intent, "Select Image"), 100);
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void insertPhotoHandler(NUIDocView nUIDocView) throws UnsupportedOperationException {
        if (this.mConfigOptions.isPhotoInsertEnabled()) {
            this.mDocViewForInsert = nUIDocView;
            String str = this.mTempPhotoFolderPath + UUID.randomUUID() + ".jpg";
            this.mImagePath = str;
            this.mDeleteOnClose.add(str);
            Uri uriForFile = FileProvider.getUriForFile(this.mActivity, this.mActivity.getApplicationContext().getPackageName() + ".provider", new File(this.mImagePath));
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            intent.addFlags(2);
            intent.setClipData(ClipData.newRawUri((CharSequence) null, uriForFile));
            intent.putExtra("output", uriForFile);
            this.mActivity.startActivityForResult(intent, 101);
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void launchUrlHandler(String str) throws UnsupportedOperationException {
        if (this.mConfigOptions.mSettingsBundle.getBoolean("LaunchUrlEnabledKey", true)) {
            displayDialogue("Information", "Please implement a custom Url launch handler");
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        String str;
        String str2 = null;
        if (i == 100) {
            if (i2 != -1) {
                this.mDocViewForInsert = null;
                this.mImagePath = null;
                return;
            }
            Uri data = intent.getData();
            if (DocumentsContract.isDocumentUri(this.mActivity, data)) {
                String extensionFromMimeType = MimeTypeMap.getSingleton().getExtensionFromMimeType(this.mActivity.getContentResolver().getType(data));
                if (this.mSecureFs != null) {
                    str = this.mTempFolderPath.replace(this.mSecurePrefix, this.mSecurePath);
                } else {
                    str = this.mTempPhotoFolderPath;
                }
                StringBuilder m = c$$ExternalSyntheticOutline0.m(str);
                m.append(UUID.randomUUID());
                m.append(".");
                m.append(extensionFromMimeType);
                String sb = m.toString();
                try {
                    byte[] bArr = new byte[4096];
                    InputStream openInputStream = this.mActivity.getContentResolver().openInputStream(data);
                    FileOutputStream fileOutputStream = new FileOutputStream(sb);
                    while (openInputStream.available() > 0) {
                        openInputStream.read(bArr);
                        fileOutputStream.write(bArr);
                    }
                    openInputStream.close();
                    fileOutputStream.close();
                    if (this.mSecureFs != null) {
                        sb = sb.replace(this.mSecurePath, this.mSecurePrefix);
                    }
                    this.mDeleteOnClose.add(sb);
                    str2 = sb;
                } catch (Exception unused) {
                    Log.e("DataLeakHandlers", "getRealPathFromURI(): Failed to copy image for insertion.");
                }
            } else {
                String scheme = data.getScheme();
                if (scheme != null && scheme.equalsIgnoreCase(AppLovinEventTypes.USER_VIEWED_CONTENT)) {
                    str2 = FileUtils.exportContentUri(this.mActivity, data);
                    this.mDeleteOnClose.add(str2);
                } else if (scheme != null && scheme.equalsIgnoreCase("file")) {
                    str2 = data.getPath();
                }
            }
            this.mImagePath = str2;
            if (str2 != null) {
                displayProgressDialogue("Inserting", "", true);
            }
        } else if (i != 101) {
        } else {
            if (i2 != -1) {
                this.mDocViewForInsert = null;
                this.mImagePath = null;
                return;
            }
            displayProgressDialogue("Inserting", "", true);
        }
    }

    public void openInHandler(String str, ArDkDoc arDkDoc) throws UnsupportedOperationException {
        if (this.mConfigOptions.isOpenInEnabled()) {
            displayProgressDialogue("Saving Document", "", false);
            final String m = Barrier$$ExternalSyntheticOutline0.m(new StringBuilder(), this.mTempFolderPath, str);
            arDkDoc.saveTo(m, new SODocSaveListener() {
                public void onComplete(int i, int i2) {
                    ProgressDialog progressDialog = DataLeakHandlers.this.mProgressDialog;
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                        DataLeakHandlers.this.mProgressDialog = null;
                    }
                    if (i == 0) {
                        DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                        dataLeakHandlers.mDeleteOnClose.add(m);
                        DataLeakHandlers dataLeakHandlers2 = DataLeakHandlers.this;
                        StringBuilder m = c$$ExternalSyntheticOutline0.m("Document saved to '");
                        m.append(m);
                        m.append("'.\n\nPlease implement a custom openIn handler");
                        dataLeakHandlers2.displayDialogue("Information", m.toString());
                    } else {
                        DataLeakHandlers.this.displayDialogue("Information", String.format("openInHandler failed: %d %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                    }
                    DataLeakHandlers dataLeakHandlers3 = DataLeakHandlers.this;
                    if (dataLeakHandlers3.mSecureFs != null) {
                        m.replace(dataLeakHandlers3.mSecurePrefix, dataLeakHandlers3.mSecurePath);
                    }
                }
            });
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void openPdfInHandler(String str, ArDkDoc arDkDoc) throws UnsupportedOperationException {
        if (this.mConfigOptions.isOpenPdfInEnabled()) {
            displayProgressDialogue("Exporting Document", "", false);
            final String m = BackStackRecord$$ExternalSyntheticOutline0.m(new StringBuilder(), this.mTempFolderPath, str, ".pdf");
            arDkDoc.saveToPDF(m, false, new SODocSaveListener() {
                public void onComplete(int i, int i2) {
                    ProgressDialog progressDialog = DataLeakHandlers.this.mProgressDialog;
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                        DataLeakHandlers.this.mProgressDialog = null;
                    }
                    if (i == 0) {
                        DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                        dataLeakHandlers.mDeleteOnClose.add(m);
                        DataLeakHandlers dataLeakHandlers2 = DataLeakHandlers.this;
                        StringBuilder m = c$$ExternalSyntheticOutline0.m("Document exported to '");
                        m.append(m);
                        m.append("'.\n\nPlease implement a custom openPdfIn handler");
                        dataLeakHandlers2.displayDialogue("Information", m.toString());
                    } else {
                        DataLeakHandlers.this.displayDialogue("Information", String.format("openPdfInHandler failed: %d %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                    }
                    DataLeakHandlers dataLeakHandlers3 = DataLeakHandlers.this;
                    if (dataLeakHandlers3.mSecureFs != null) {
                        m.replace(dataLeakHandlers3.mSecurePrefix, dataLeakHandlers3.mSecurePath);
                    }
                }
            });
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void pauseHandler(ArDkDoc arDkDoc, boolean z, Runnable runnable) {
        if (runnable != null) {
            runnable.run();
        }
    }

    public void postSaveHandler(SOSaveAsComplete sOSaveAsComplete) {
        sOSaveAsComplete.onComplete(0, (String) null);
    }

    public void printHandler(SODocSession sODocSession) throws UnsupportedOperationException {
        if (!this.mConfigOptions.isPrintingEnabled()) {
            throw new UnsupportedOperationException();
        } else if (sODocSession.isPasswordProtected()) {
            Activity activity = this.mActivity;
            Utilities.showMessage(activity, activity.getString(R.string.sodk_editor_printing_not_supported_title), this.mActivity.getString(R.string.sodk_editor_print_password_protected_pdf));
        } else {
            ArDkDoc doc = sODocSession.getDoc();
            String name = new File(sODocSession.getFileState().getOpenedPath()).getName();
            if (!FileUtils.getExtension(sODocSession.getUserPath()).equalsIgnoreCase("pdf")) {
                name = a$$ExternalSyntheticOutline0.m(name, ".pdf");
            }
            PrintHelperPdf printHelperPdf = new PrintHelperPdf();
            printHelperPdf.setPrintName(name);
            printHelperPdf.print(this.mActivity, doc, (Runnable) null);
        }
    }

    public void saveAsHandler(String str, ArDkDoc arDkDoc, final SOSaveAsComplete sOSaveAsComplete) throws UnsupportedOperationException {
        if (this.mConfigOptions.isSaveAsEnabled()) {
            final String m = Barrier$$ExternalSyntheticOutline0.m(new StringBuilder(), this.mTempFolderPath, str);
            if (sOSaveAsComplete.onFilenameSelected(m)) {
                displayProgressDialogue("Saving Document", "", false);
                arDkDoc.saveTo(m, new SODocSaveListener() {
                    public void onComplete(int i, int i2) {
                        ProgressDialog progressDialog = DataLeakHandlers.this.mProgressDialog;
                        if (progressDialog != null) {
                            progressDialog.dismiss();
                            DataLeakHandlers.this.mProgressDialog = null;
                        }
                        if (i == 0) {
                            DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                            StringBuilder m = c$$ExternalSyntheticOutline0.m("Document saved to '");
                            m.append(m);
                            m.append("'.\n\nPlease implement a custom saveAs handler");
                            dataLeakHandlers.displayDialogue("Information", m.toString());
                            sOSaveAsComplete.onComplete(0, m);
                            return;
                        }
                        DataLeakHandlers.this.displayDialogue("Information", String.format("saveAsHandler failed: %d %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                        sOSaveAsComplete.onComplete(1, (String) null);
                    }
                });
                return;
            }
            sOSaveAsComplete.onComplete(1, (String) null);
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void saveAsPdfHandler(String str, ArDkDoc arDkDoc) throws UnsupportedOperationException {
        if (this.mConfigOptions.isSaveAsPdfEnabled()) {
            displayProgressDialogue("Exporting Document", "", false);
            final String m = BackStackRecord$$ExternalSyntheticOutline0.m(new StringBuilder(), this.mTempFolderPath, str, ".pdf");
            arDkDoc.saveToPDF(m, false, new SODocSaveListener() {
                public void onComplete(int i, int i2) {
                    ProgressDialog progressDialog = DataLeakHandlers.this.mProgressDialog;
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                        DataLeakHandlers.this.mProgressDialog = null;
                    }
                    if (i == 0) {
                        DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                        StringBuilder m = c$$ExternalSyntheticOutline0.m("Document exported to '");
                        m.append(m);
                        m.append("'.\n\nPlease implement a custom savePdf handler");
                        dataLeakHandlers.displayDialogue("Information", m.toString());
                        return;
                    }
                    DataLeakHandlers.this.displayDialogue("Information", String.format("saveAsPdfHandler failed: %d %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                }
            });
            return;
        }
        throw new UnsupportedOperationException();
    }

    public void saveAsSecureHandler(String str, ArDkDoc arDkDoc, String str2, String str3, SOSaveAsComplete sOSaveAsComplete) throws UnsupportedOperationException {
        if (!this.mConfigOptions.isSaveAsEnabled()) {
            throw new UnsupportedOperationException();
        } else if (this.mConfigOptions.isSecureRedactionsEnabled()) {
            String str4 = str;
            final String m = BackStackRecord$$ExternalSyntheticOutline0.m(new StringBuilder(), this.mTempFolderPath, str, ".pdf");
            final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
            final TwoBarProgressDialog twoBarProgressDialog = new TwoBarProgressDialog(this.mActivity, "Saving");
            twoBarProgressDialog.setCancelRunnable(new Runnable(this) {
                public void run() {
                    twoBarProgressDialog.dismiss();
                    atomicBoolean.set(true);
                }
            });
            twoBarProgressDialog.show();
            MuPDFDoc muPDFDoc = (MuPDFDoc) arDkDoc;
            AnonymousClass10 r9 = new MuPDFDoc.SaveSecureProgress() {
            };
            final SOSaveAsComplete sOSaveAsComplete2 = sOSaveAsComplete;
            AnonymousClass11 r11 = new SODocSaveListener() {
                public void onComplete(int i, int i2) {
                    if (i == 0) {
                        DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                        StringBuilder m = c$$ExternalSyntheticOutline0.m("Document saved to '");
                        m.append(m);
                        m.append("'.\n\nPlease implement a custom saveAsSecureHandler");
                        dataLeakHandlers.displayDialogue("Information", m.toString());
                        sOSaveAsComplete2.onComplete(0, m);
                    } else if (i == 1) {
                        DataLeakHandlers.this.displayDialogue("Information", String.format("saveAsSecureHandler failed: %d %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                        sOSaveAsComplete2.onComplete(1, m);
                    } else {
                        DataLeakHandlers.this.displayDialogue("Information", String.format("saveAsSecureHandler cancelled.", new Object[0]));
                        sOSaveAsComplete2.onComplete(i, m);
                    }
                }
            };
            Objects.requireNonNull(muPDFDoc);
            muPDFDoc.mWorker.add(new Worker.Task(str2, str3, m, r9, new AtomicBoolean(false), r11) {
                public int result;
                public final /* synthetic */ AtomicBoolean val$cancelled;
                public final /* synthetic */ String val$language;
                public final /* synthetic */ SODocSaveListener val$listener;
                public final /* synthetic */ String val$path;
                public final /* synthetic */ String val$resolution;
                public final /* synthetic */ SaveSecureProgress val$secureProgress;

                public void run(
/*
Method generation error in method: com.artifex.solib.MuPDFDoc.34.run():void, dex: classes.dex
                jadx.core.utils.exceptions.JadxRuntimeException: Method args not loaded: com.artifex.solib.MuPDFDoc.34.run():void, class status: UNLOADED
                	at jadx.core.dex.nodes.MethodNode.getArgRegs(MethodNode.java:278)
                	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:116)
                	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:313)
                	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                	at java.util.ArrayList.forEach(ArrayList.java:1259)
                	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:676)
                	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:607)
                	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:364)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                	at jadx.core.codegen.InsnGen.generateMethodArguments(InsnGen.java:787)
                	at jadx.core.codegen.InsnGen.makeInvoke(InsnGen.java:728)
                	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:368)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:250)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:221)
                	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:109)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:55)
                	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:142)
                	at jadx.core.codegen.RegionGen.connectElseIf(RegionGen.java:175)
                	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:152)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:62)
                	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:211)
                	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:204)
                	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:318)
                	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                	at java.util.ArrayList.forEach(ArrayList.java:1259)
                	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:112)
                	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:78)
                	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:44)
                	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:33)
                	at jadx.core.codegen.CodeGen.generate(CodeGen.java:21)
                	at jadx.core.ProcessClass.generateCode(ProcessClass.java:61)
                	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
                
*/

                /* Code decompiled incorrectly, please refer to instructions dump. */
                public void work(
/*
Method generation error in method: com.artifex.solib.MuPDFDoc.34.work():void, dex: classes.dex
                jadx.core.utils.exceptions.JadxRuntimeException: Method args not loaded: com.artifex.solib.MuPDFDoc.34.work():void, class status: UNLOADED
                	at jadx.core.dex.nodes.MethodNode.getArgRegs(MethodNode.java:278)
                	at jadx.core.codegen.MethodGen.addDefinition(MethodGen.java:116)
                	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:313)
                	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                	at java.util.ArrayList.forEach(ArrayList.java:1259)
                	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                	at jadx.core.codegen.InsnGen.inlineAnonymousConstructor(InsnGen.java:676)
                	at jadx.core.codegen.InsnGen.makeConstructor(InsnGen.java:607)
                	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:364)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:231)
                	at jadx.core.codegen.InsnGen.addWrappedArg(InsnGen.java:123)
                	at jadx.core.codegen.InsnGen.addArg(InsnGen.java:107)
                	at jadx.core.codegen.InsnGen.generateMethodArguments(InsnGen.java:787)
                	at jadx.core.codegen.InsnGen.makeInvoke(InsnGen.java:728)
                	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:368)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:250)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:221)
                	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:109)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:55)
                	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:98)
                	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:142)
                	at jadx.core.codegen.RegionGen.connectElseIf(RegionGen.java:175)
                	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:152)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:62)
                	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:92)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:58)
                	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:211)
                	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:204)
                	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:318)
                	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:271)
                	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$2(ClassGen.java:240)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:183)
                	at java.util.ArrayList.forEach(ArrayList.java:1259)
                	at java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                	at java.util.stream.Sink$ChainedReference.end(Sink.java:258)
                	at java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:483)
                	at java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)
                	at java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:150)
                	at java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:173)
                	at java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)
                	at java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:485)
                	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:236)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:227)
                	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:112)
                	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:78)
                	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:44)
                	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:33)
                	at jadx.core.codegen.CodeGen.generate(CodeGen.java:21)
                	at jadx.core.ProcessClass.generateCode(ProcessClass.java:61)
                	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
                
*/
            });
        } else {
            throw new UnsupportedOperationException();
        }
    }

    public void shareHandler(String str, ArDkDoc arDkDoc) throws UnsupportedOperationException {
        if (this.mConfigOptions.isShareEnabled()) {
            displayProgressDialogue("Saving Document", "", false);
            final String m = Barrier$$ExternalSyntheticOutline0.m(new StringBuilder(), this.mTempFolderPath, str);
            arDkDoc.saveTo(m, new SODocSaveListener() {
                public void onComplete(int i, int i2) {
                    ProgressDialog progressDialog = DataLeakHandlers.this.mProgressDialog;
                    if (progressDialog != null) {
                        progressDialog.dismiss();
                        DataLeakHandlers.this.mProgressDialog = null;
                    }
                    if (i == 0) {
                        DataLeakHandlers dataLeakHandlers = DataLeakHandlers.this;
                        dataLeakHandlers.mDeleteOnClose.add(m);
                        DataLeakHandlers dataLeakHandlers2 = DataLeakHandlers.this;
                        StringBuilder m = c$$ExternalSyntheticOutline0.m("Document saved to '");
                        m.append(m);
                        m.append("'.\n\nPlease implement a custom share handler");
                        dataLeakHandlers2.displayDialogue("Information", m.toString());
                    } else {
                        DataLeakHandlers.this.displayDialogue("Information", String.format("shareHandler failed: %d %d", new Object[]{Integer.valueOf(i), Integer.valueOf(i2)}));
                    }
                    DataLeakHandlers dataLeakHandlers3 = DataLeakHandlers.this;
                    if (dataLeakHandlers3.mSecureFs != null) {
                        m.replace(dataLeakHandlers3.mSecurePrefix, dataLeakHandlers3.mSecurePath);
                    }
                }
            });
            return;
        }
        throw new UnsupportedOperationException();
    }
}
