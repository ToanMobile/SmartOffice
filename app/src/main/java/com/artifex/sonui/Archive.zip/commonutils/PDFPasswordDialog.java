package com.artifex.sonui.commonutils;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import com.rpdev.document.manager.reader.allfiles.R;

public class PDFPasswordDialog implements View.OnClickListener {
    public EditText eTextPassword;
    public Activity mActivity;
    public OnPPDCallback onPPDCallback;
    public String password = "";
    public AlertDialog pdfPasswordDialog;
    public TextView txtCancel;
    public TextView txtOpenFile;

    public interface OnPPDCallback {
        void onSuccess(boolean z, String str);
    }

    public PDFPasswordDialog(Activity activity, OnPPDCallback onPPDCallback2) {
        this.mActivity = activity;
        this.onPPDCallback = onPPDCallback2;
    }

    public void onClick(View view) {
        if (view.getId() == R.id.txtCancel) {
            this.password = "";
            this.onPPDCallback.onSuccess(false, "");
            this.pdfPasswordDialog.dismiss();
        } else if (view.getId() == R.id.txtOpenFile) {
            String m = ManageFiles$2$$ExternalSyntheticOutline0.m(this.eTextPassword);
            this.password = m;
            if (m.length() == 0) {
                Toast.makeText(this.mActivity, "Password should not be blank", 0).show();
                return;
            }
            this.onPPDCallback.onSuccess(true, this.password);
            this.pdfPasswordDialog.dismiss();
        }
    }

    public void showAskPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.mActivity);
        View inflate = this.mActivity.getLayoutInflater().inflate(R.layout.dialog_pdf_password, (ViewGroup) null);
        builder.setView(inflate);
        EditText editText = (EditText) inflate.findViewById(R.id.eTextPassword);
        this.eTextPassword = editText;
        try {
            editText.requestFocus();
            ((InputMethodManager) this.mActivity.getSystemService("input_method")).showSoftInput(this.eTextPassword, 1);
        } catch (Exception unused) {
        }
        this.txtCancel = (TextView) inflate.findViewById(R.id.txtCancel);
        this.txtOpenFile = (TextView) inflate.findViewById(R.id.txtOpenFile);
        this.txtCancel.setOnClickListener(this);
        this.txtOpenFile.setOnClickListener(this);
        AlertDialog create = builder.create();
        this.pdfPasswordDialog = create;
        create.setCancelable(false);
        this.pdfPasswordDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        this.pdfPasswordDialog.show();
    }
}
