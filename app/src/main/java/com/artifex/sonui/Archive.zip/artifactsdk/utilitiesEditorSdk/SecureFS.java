package com.artifex.sonui.artifactsdk.utilitiesEditorSdk;

import a.a.a.a.a.c$$ExternalSyntheticOutline0;
import android.os.Environment;
import android.util.Log;
import androidx.constraintlayout.core.widgets.Barrier$$ExternalSyntheticOutline0;
import com.artifex.solib.SOSecureFS;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.SyncFailedException;
import java.nio.channels.ClosedChannelException;

public class SecureFS implements SOSecureFS {
    public static final String mSecurePath;

    static {
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath());
        mSecurePath = Barrier$$ExternalSyntheticOutline0.m(sb, File.separator, "Secure");
    }

    public boolean closeFile(Object obj) {
        try {
            ((RandomAccessFile) obj).close();
            return true;
        } catch (IOException | ClassCastException unused) {
            return false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x003f A[SYNTHETIC, Splitter:B:12:0x003f] */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0044 A[Catch:{ Exception -> 0x0047 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean copyFile(java.lang.String r9, java.lang.String r10) {
        /*
            r8 = this;
            r0 = 0
            java.io.File r1 = new java.io.File     // Catch:{ Exception -> 0x0038 }
            java.lang.String r9 = r8.mapSecurePrefixToPath(r9)     // Catch:{ Exception -> 0x0038 }
            r1.<init>(r9)     // Catch:{ Exception -> 0x0038 }
            java.io.File r9 = new java.io.File     // Catch:{ Exception -> 0x0038 }
            java.lang.String r10 = r8.mapSecurePrefixToPath(r10)     // Catch:{ Exception -> 0x0038 }
            r9.<init>(r10)     // Catch:{ Exception -> 0x0038 }
            r9.createNewFile()     // Catch:{ Exception -> 0x0038 }
            java.io.FileInputStream r10 = new java.io.FileInputStream     // Catch:{ Exception -> 0x0038 }
            r10.<init>(r1)     // Catch:{ Exception -> 0x0038 }
            java.nio.channels.FileChannel r10 = r10.getChannel()     // Catch:{ Exception -> 0x0038 }
            java.io.FileOutputStream r1 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0035 }
            r1.<init>(r9)     // Catch:{ Exception -> 0x0035 }
            java.nio.channels.FileChannel r0 = r1.getChannel()     // Catch:{ Exception -> 0x0035 }
            r4 = 0
            long r6 = r10.size()     // Catch:{ Exception -> 0x0035 }
            r2 = r0
            r3 = r10
            r2.transferFrom(r3, r4, r6)     // Catch:{ Exception -> 0x0035 }
            r9 = 1
            goto L_0x003d
        L_0x0035:
            r9 = r0
            r0 = r10
            goto L_0x0039
        L_0x0038:
            r9 = r0
        L_0x0039:
            r10 = 0
            r10 = r0
            r0 = r9
            r9 = 0
        L_0x003d:
            if (r10 == 0) goto L_0x0042
            r10.close()     // Catch:{ Exception -> 0x0047 }
        L_0x0042:
            if (r0 == 0) goto L_0x0047
            r0.close()     // Catch:{ Exception -> 0x0047 }
        L_0x0047:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.artifex.sonui.artifactsdk.utilitiesEditorSdk.SecureFS.copyFile(java.lang.String, java.lang.String):boolean");
    }

    public boolean createDirectory(String str) {
        try {
            return new File(mapSecurePrefixToPath(str)).mkdirs();
        } catch (SecurityException unused) {
            return false;
        }
    }

    public boolean createFile(String str) {
        try {
            return new File(mapSecurePrefixToPath(str)).createNewFile();
        } catch (IOException | SecurityException unused) {
            return false;
        }
    }

    public boolean deleteFile(String str) {
        try {
            return new File(mapSecurePrefixToPath(str)).delete();
        } catch (SecurityException unused) {
            return false;
        }
    }

    public boolean fileExists(String str) {
        try {
            return new File(mapSecurePrefixToPath(str)).exists();
        } catch (SecurityException unused) {
            return false;
        }
    }

    public SOSecureFS.FileAttributes getFileAttributes(String str) {
        File file = new File(mapSecurePrefixToPath(str));
        SOSecureFS.FileAttributes fileAttributes = new SOSecureFS.FileAttributes();
        if (!file.exists()) {
            return null;
        }
        fileAttributes.length = file.length();
        fileAttributes.lastModified = file.lastModified() / 1000;
        fileAttributes.isHidden = file.isHidden();
        fileAttributes.isDirectory = file.isDirectory();
        fileAttributes.isWriteable = file.canWrite();
        fileAttributes.isSystem = false;
        return fileAttributes;
    }

    public Object getFileHandleForReading(String str) {
        try {
            return new RandomAccessFile(mapSecurePrefixToPath(str), "r");
        } catch (FileNotFoundException | SecurityException unused) {
            return null;
        }
    }

    public Object getFileHandleForUpdating(String str) {
        try {
            return new RandomAccessFile(mapSecurePrefixToPath(str), "rw");
        } catch (FileNotFoundException | SecurityException unused) {
            return null;
        }
    }

    public Object getFileHandleForWriting(String str) {
        try {
            return new RandomAccessFile(mapSecurePrefixToPath(str), "rw");
        } catch (FileNotFoundException | SecurityException unused) {
            return null;
        }
    }

    public long getFileLength(Object obj) {
        try {
            return ((RandomAccessFile) obj).length();
        } catch (IOException | ClassCastException unused) {
            return -1;
        }
    }

    public long getFileOffset(Object obj) {
        try {
            return ((RandomAccessFile) obj).getChannel().position();
        } catch (IOException | ClassCastException | ClosedChannelException unused) {
            return -1;
        }
    }

    public String getSecurePath() {
        return mSecurePath;
    }

    public String getSecurePrefix() {
        return "/SECURE";
    }

    public final String getTempPath() {
        return Barrier$$ExternalSyntheticOutline0.m(c$$ExternalSyntheticOutline0.m("/SECURE"), File.separator, "tmp");
    }

    public boolean isSecurePath(String str) {
        return str.startsWith("/SECURE") || str.startsWith(mSecurePath);
    }

    public final String mapSecurePrefixToPath(String str) {
        if (str.startsWith("/SECURE")) {
            return str.replaceFirst("/SECURE", mSecurePath);
        }
        Log.e("SecureFS", "mapSecurePrefixToPath [" + str + "]: Does not start with secure prefix");
        return str;
    }

    public int readFromFile(Object obj, byte[] bArr) {
        try {
            int read = ((RandomAccessFile) obj).read(bArr);
            if (read == -1) {
                return 0;
            }
            return read;
        } catch (IOException | ClassCastException | NullPointerException unused) {
            return -1;
        }
    }

    public boolean recursivelyRemoveDirectory(String str) {
        File file = new File(mapSecurePrefixToPath(str) + '/');
        try {
            if (file.isDirectory()) {
                for (File path : file.listFiles()) {
                    recursivelyRemoveDirectory(path.getPath());
                }
            }
            file.delete();
            return true;
        } catch (SecurityException unused) {
            return false;
        } catch (NullPointerException unused2) {
            Log.e("SecureFS", "recusivelyRemoveDirectory() failed  [" + str + "]: Have storage permissions been granted");
            return false;
        }
    }

    public boolean renameFile(String str, String str2) {
        File file = new File(mapSecurePrefixToPath(str));
        File file2 = new File(mapSecurePrefixToPath(str2));
        if (!file.exists()) {
            return false;
        }
        try {
            return file.renameTo(file2);
        } catch (SecurityException unused) {
            return false;
        }
    }

    public boolean seekToFileOffset(Object obj, long j) {
        try {
            ((RandomAccessFile) obj).seek(j);
            return true;
        } catch (IOException | ClassCastException unused) {
            return false;
        }
    }

    public boolean setFileLength(Object obj, long j) {
        try {
            ((RandomAccessFile) obj).setLength(j);
            return true;
        } catch (IOException | ClassCastException unused) {
            return false;
        }
    }

    public boolean syncFile(Object obj) {
        try {
            ((RandomAccessFile) obj).getFD().sync();
            return true;
        } catch (IOException | SyncFailedException | ClassCastException unused) {
            return false;
        }
    }

    public int writeToFile(Object obj, byte[] bArr) {
        try {
            ((RandomAccessFile) obj).write(bArr);
            return bArr.length;
        } catch (IOException | ClassCastException unused) {
            return -1;
        }
    }
}
