package com.artifex.sonui.commonutils;

import android.app.Activity;
import android.content.Intent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import com.arasthel.asyncjob.AsyncJob;
import com.commons_lite.ads_module.CommonsMultiDexApplication;
import com.artifex.sonui.artifactsdk.model.FilesData;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.FileDb.FileDatabase;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.FileDb.FileInstanceDB;
import com.rpdev.docreadermainV2.pdfTools.filePreview.FilePreviewHandlingActivity;
import java.io.File;
import java.util.Date;

public class ManageFiles {
    public EditText eTextTagName;
    public AlertDialog fileInfoDialog;
    public FilesData filesData;
    public ImageView imvClose;
    public Activity mActivity;
    public OnManageFilesCallback onManageFilesCallback;
    public AlertDialog renameFileDialog;
    public StringUtils stringUtils;
    public TextView txtCancel;
    public TextView txtCreatedOn;
    public TextView txtDone;
    public TextView txtFITitle;
    public TextView txtFileSize;
    public TextView txtFileType;
    public TextView txtMsg;
    public TextView txtTitle;

    public interface OnManageFilesCallback {
    }

    public ManageFiles() {
    }

    public void handleFileRedirection(final Activity activity, final String str, String str2) {
        Intent intent;
        try {
            int i = FilePreviewHandlingActivity.$r8$clinit;
            intent = new Intent(activity, FilePreviewHandlingActivity.class);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            intent = null;
        }
        AsyncJob.doInBackground(new AsyncJob.OnBackgroundJob(this) {
            public void doOnBackground() {
                try {
                    FileDatabase mainInstance = FileDatabase.getMainInstance(activity);
                    FileInstanceDB fileInstanceDB = new FileInstanceDB();
                    fileInstanceDB.fileName = new File(str).getName();
                    fileInstanceDB.filePath = str;
                    fileInstanceDB.timeAccessed = new Date().getTime();
                    fileInstanceDB.fileSize = (double) new File(str).length();
                    mainInstance.userDao().insertAll(fileInstanceDB);
                } catch (Exception e) {
                    FirebaseCrashlytics.getInstance().log(e.getMessage());
                }
            }
        });
        intent.putExtra("isDark", CommonsMultiDexApplication.isDark);
        intent.putExtra("filePath", str);
        intent.putExtra("from_app", true);
        intent.putExtra("opened_from", str2);
        intent.putExtra("open_directly", true);
        activity.startActivity(intent);
    }

    public ManageFiles(Activity activity, FilesData filesData2, OnManageFilesCallback onManageFilesCallback2) {
        this.mActivity = activity;
        this.filesData = filesData2;
        this.onManageFilesCallback = onManageFilesCallback2;
        this.stringUtils = new StringUtils(activity);
    }
}
