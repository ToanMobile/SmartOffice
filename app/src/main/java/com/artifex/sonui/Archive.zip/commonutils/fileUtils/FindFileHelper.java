package com.artifex.sonui.commonutils.fileUtils;

import a.a.a.a.a.c$$ExternalSyntheticOutline0;
import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;
import androidx.activity.R$id;
import androidx.appcompat.R$color;
import androidx.exifinterface.media.ExifInterface$$ExternalSyntheticOutline1;
import androidx.lifecycle.MutableLiveData;
import com.artifex.sonui.artifactsdk.model.FilesData;
import com.firebase.ui.auth.R$style;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.DaoManager;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.FileDb.FileDatabase;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.FileDb.FileInstanceDB;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.TagsDb.TagsFileInstanceDB;
import com.rpdev.a1officecloudmodule.di.InjectionHelperForClasses;
import com.rpdev.document.manager.reader.allfiles.R;
import dagger.hilt.android.EntryPointAccessors;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Pair;
import kotlin.collections.CollectionsKt__CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.jvm.internal.ArrayIterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt__StringsJVMKt;
import kotlinx.coroutines.CoroutineStart;
import kotlinx.coroutines.Dispatchers;

public final class FindFileHelper {
    public static final FindFileHelper INSTANCE = new FindFileHelper();
    public static String TAG = "FindFileHelper";
    public static ArrayList<FilesData> allFilesDataList = new ArrayList<>();
    public static MutableLiveData<ArrayList<FilesData>> favoritesFilesDataList = new MutableLiveData<>();
    public static ArrayList<FilesData> htmlFilesDataList = new ArrayList<>();
    public static InjectionHelperForClasses injectionHelperForClasses;
    public static ArrayList<FilesData> pdfFilesDataList = new ArrayList<>();
    public static ArrayList<FilesData> pptFilesDataList = new ArrayList<>();
    public static MutableLiveData<ArrayList<FilesData>> recentFiles = new MutableLiveData<>();
    public static ArrayList<FilesData> txtFilesDataList = new ArrayList<>();
    public static ArrayList<FilesData> wordFilesDataList = new ArrayList<>();
    public static ArrayList<FilesData> xlsFilesDataList = new ArrayList<>();

    static {
        new MutableLiveData();
    }

    public static final void access$getFavoritesListFromDb(FindFileHelper findFileHelper, Activity activity) {
        if (injectionHelperForClasses == null) {
            injectionHelperForClasses = (InjectionHelperForClasses) EntryPointAccessors.fromApplication(activity, InjectionHelperForClasses.class);
        }
        InjectionHelperForClasses injectionHelperForClasses2 = injectionHelperForClasses;
        List<TagsFileInstanceDB> GetSelectedFiles = DaoManager.GetSelectedFiles(injectionHelperForClasses2 != null ? injectionHelperForClasses2.getFileDatabase() : null, 8L);
        ArrayList arrayList = new ArrayList();
        Intrinsics.checkNotNullExpressionValue(GetSelectedFiles, "tagListFromDb");
        int i = 0;
        for (T next : GetSelectedFiles) {
            int i2 = i + 1;
            if (i >= 0) {
                TagsFileInstanceDB tagsFileInstanceDB = (TagsFileInstanceDB) next;
                FilesData filesData = new FilesData();
                filesData.title = tagsFileInstanceDB.fileTitle;
                filesData.path = tagsFileInstanceDB.filePath;
                File file = new File(tagsFileInstanceDB.filePath);
                if (file.exists()) {
                    filesData.size = (double) file.length();
                }
                filesData.fileDate = file.lastModified();
                filesData.isFavorite = tagsFileInstanceDB.tagName.equalsIgnoreCase("Favorites");
                arrayList.add(filesData);
                i = i2;
            } else {
                CollectionsKt__CollectionsKt.throwIndexOverflow();
                throw null;
            }
        }
        favoritesFilesDataList.postValue(arrayList);
    }

    public static final void access$getRecentlyViewedFiles(FindFileHelper findFileHelper, Activity activity) {
        List<FileInstanceDB> all = FileDatabase.getMainInstance(activity).userDao().getAll();
        ArrayList arrayList = new ArrayList();
        for (FileInstanceDB next : all) {
            FilesData filesData = new FilesData();
            filesData.title = next.fileName;
            filesData.path = next.filePath;
            filesData.size = next.fileSize / ((double) 1024);
            filesData.fileDate = next.timeAccessed;
            arrayList.add(filesData);
        }
        File externalFilesDir = activity.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        Intrinsics.checkNotNull(externalFilesDir);
        findFileHelper.getAllFilesForSpecificDirectory(arrayList, externalFilesDir);
        File externalStoragePublicDirectory = Environment.getExternalStoragePublicDirectory("A1 Office Documents");
        Intrinsics.checkNotNullExpressionValue(externalStoragePublicDirectory, "getExternalStoragePublic…ry(\"A1 Office Documents\")");
        findFileHelper.getAllFilesForSpecificDirectory(arrayList, externalStoragePublicDirectory);
        try {
            String[] list = activity.getAssets().list("introductionfiles");
            Intrinsics.checkNotNull(list);
            if (!(list.length == 0)) {
                Iterator it = R$style.iterator(list);
                while (true) {
                    ArrayIterator arrayIterator = (ArrayIterator) it;
                    if (!arrayIterator.hasNext()) {
                        break;
                    }
                    File copyFileFromAssets = findFileHelper.copyFileFromAssets(activity, (String) arrayIterator.next());
                    if (copyFileFromAssets != null) {
                        FilesData filesData2 = new FilesData();
                        filesData2.title = copyFileFromAssets.getName();
                        filesData2.path = copyFileFromAssets.getPath();
                        filesData2.size = (double) (copyFileFromAssets.length() / ((long) 1024));
                        filesData2.fileDate = copyFileFromAssets.lastModified();
                        InjectionHelperForClasses injectionHelperForClasses2 = injectionHelperForClasses;
                        filesData2.isFavorite = DaoManager.isFileEntryExist(injectionHelperForClasses2 != null ? injectionHelperForClasses2.getFileDatabase() : null, copyFileFromAssets.getName(), copyFileFromAssets.getAbsolutePath(), 8L);
                        arrayList.add(filesData2);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            String str = TAG;
            StringBuilder m = c$$ExternalSyntheticOutline0.m("addIntroFiles: ");
            m.append(e.getLocalizedMessage());
            Log.d(str, m.toString());
        }
        recentFiles.postValue(findFileHelper.removeDuplicates(arrayList));
    }

    public final File copyFileFromAssets(Activity activity, String str) {
        File file = null;
        try {
            AssetManager assets = activity.getAssets();
            InputStream open = assets.open("introductionfiles/" + str);
            Intrinsics.checkNotNullExpressionValue(open, "activity.assets.open(\"in…ionfiles/$assetFileName\")");
            file = sampleFileFolder(activity, str);
            if (!file.exists()) {
                file.createNewFile();
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = open.read(bArr);
                    if (read <= 0) {
                        break;
                    }
                    fileOutputStream.write(bArr, 0, read);
                }
                fileOutputStream.close();
                open.close();
            }
        } catch (IOException e) {
            String str2 = TAG;
            StringBuilder m = c$$ExternalSyntheticOutline0.m("copyFileFromAssets: file from assets");
            m.append(e.getLocalizedMessage());
            Log.d(str2, m.toString());
        }
        return file;
    }

    public final void fetchFileFromStorage(Activity activity) {
        if (injectionHelperForClasses == null) {
            injectionHelperForClasses = (InjectionHelperForClasses) EntryPointAccessors.fromApplication(activity, InjectionHelperForClasses.class);
        }
        if (allFilesDataList.size() == 0) {
            refreshFiles(activity);
        } else {
            R$id.launch$default(R$color.CoroutineScope(Dispatchers.Default), (CoroutineContext) null, (CoroutineStart) null, new FindFileHelper$refreshRecent$1(activity, (Continuation<? super FindFileHelper$refreshRecent$1>) null), 3, (Object) null);
        }
    }

    public final void getAllFilesForSpecificDirectory(ArrayList<FilesData> arrayList, File file) {
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (File file2 : listFiles) {
                if (file2.isDirectory()) {
                    getAllFilesForSpecificDirectory(arrayList, file2);
                } else if (file2.exists() && getFileSize(file2, "kb") > 0) {
                    FilesData filesData = new FilesData();
                    filesData.title = file2.getName();
                    filesData.path = file2.getAbsolutePath();
                    filesData.size = (double) file2.length();
                    filesData.fileDate = file2.lastModified();
                    InjectionHelperForClasses injectionHelperForClasses2 = injectionHelperForClasses;
                    filesData.isFavorite = DaoManager.isFileEntryExist(injectionHelperForClasses2 != null ? injectionHelperForClasses2.getFileDatabase() : null, file2.getName(), file2.getAbsolutePath(), 8L);
                    arrayList.add(filesData);
                }
            }
        }
    }

    public final ArrayList<FilesData> getAllFilesSlowApproach(File file, int i) {
        File[] listFiles = file.listFiles(new ExtensionsFilter("", new String[]{"pdf", "epub", "doc", "docx", "docm", "dot", "dotx", "xls", "xlsx", "xlsm", "xlsb", "xltm", "xltx", "csv", "ppt", "pptx", "potm", "potx", "pptm", "txt", "rtx", "rtf", "html"}));
        if (listFiles != null) {
            int length = listFiles.length;
            for (int i2 = 0; i2 < length; i2++) {
                if (listFiles[i2].isDirectory()) {
                    File file2 = listFiles[i2];
                    Intrinsics.checkNotNullExpressionValue(file2, "FileList[i]");
                    getAllFilesSlowApproach(file2, i + 1);
                } else {
                    File file3 = listFiles[i2];
                    if (file3.exists() && getFileSize(file3, "kb") > 0) {
                        FilesData filesData = new FilesData();
                        filesData.title = file3.getName();
                        filesData.path = file3.getAbsolutePath();
                        filesData.size = (double) file3.length();
                        filesData.fileDate = file3.lastModified();
                        InjectionHelperForClasses injectionHelperForClasses2 = injectionHelperForClasses;
                        filesData.isFavorite = DaoManager.isFileEntryExist(injectionHelperForClasses2 != null ? injectionHelperForClasses2.getFileDatabase() : null, file3.getName(), file3.getAbsolutePath(), 8L);
                        String str = TAG;
                        StringBuilder m = c$$ExternalSyntheticOutline0.m("addFileToList, file = ");
                        m.append(filesData.path);
                        m.append('/');
                        ExifInterface$$ExternalSyntheticOutline1.m(m, filesData.title, str);
                        String str2 = filesData.title;
                        Intrinsics.checkNotNullExpressionValue(str2, "filesData.title");
                        Locale locale = Locale.getDefault();
                        Intrinsics.checkNotNullExpressionValue(locale, "getDefault()");
                        String lowerCase = str2.toLowerCase(locale);
                        Intrinsics.checkNotNullExpressionValue(lowerCase, "this as java.lang.String).toLowerCase(locale)");
                        if (StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".pdf", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".epub", false, 2)) {
                            pdfFilesDataList.add(filesData);
                            allFilesDataList.add(filesData);
                            pdfFilesDataList.size();
                            allFilesDataList.size();
                        } else if (StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".docx", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".doc", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".docm", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".dot", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".dotx", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".dotm", false, 2)) {
                            wordFilesDataList.add(filesData);
                            allFilesDataList.add(filesData);
                            wordFilesDataList.size();
                            allFilesDataList.size();
                        } else if (StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".ppt", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".pptx", false, 2)) {
                            pptFilesDataList.add(filesData);
                            allFilesDataList.add(filesData);
                            pptFilesDataList.size();
                            allFilesDataList.size();
                        } else if (StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".txt", false, 2)) {
                            txtFilesDataList.add(filesData);
                            allFilesDataList.add(filesData);
                            txtFilesDataList.size();
                            allFilesDataList.size();
                        } else if (StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".xls", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".csv", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".xlsx", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".xltm", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".xlam", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".xlsb", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".xlsm", false, 2) || StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".xltx", false, 2)) {
                            xlsFilesDataList.add(filesData);
                            allFilesDataList.add(filesData);
                            xlsFilesDataList.size();
                            allFilesDataList.size();
                        } else if (StringsKt__StringsJVMKt.endsWith$default(lowerCase, ".html", false, 2)) {
                            wordFilesDataList.add(filesData);
                            htmlFilesDataList.add(filesData);
                            htmlFilesDataList.size();
                            allFilesDataList.size();
                        }
                    }
                }
            }
        }
        String str3 = TAG;
        StringBuilder m2 = c$$ExternalSyntheticOutline0.m("allFilesDataList = ");
        m2.append(allFilesDataList.size());
        Log.d(str3, m2.toString());
        if (allFilesDataList.size() > 0) {
            allFilesDataList = removeDuplicates(allFilesDataList);
            pdfFilesDataList = removeDuplicates(pdfFilesDataList);
            wordFilesDataList = removeDuplicates(wordFilesDataList);
            pptFilesDataList = removeDuplicates(pptFilesDataList);
            txtFilesDataList = removeDuplicates(txtFilesDataList);
            xlsFilesDataList = removeDuplicates(xlsFilesDataList);
            htmlFilesDataList = removeDuplicates(htmlFilesDataList);
        }
        return allFilesDataList;
    }

    public final long getFileSize(File file, String str) {
        long length = file.length();
        long j = (long) 1024;
        long j2 = length / j;
        long j3 = j2 / j;
        int hashCode = str.hashCode();
        if (hashCode == 3415) {
            str.equals("kb");
        } else if (hashCode != 3477) {
            if (hashCode == 3039496 && str.equals("byte")) {
                return length;
            }
        } else if (str.equals("mb")) {
            return j3;
        }
        return j2;
    }

    public final void refreshFiles(Activity activity) {
        if (injectionHelperForClasses == null) {
            injectionHelperForClasses = (InjectionHelperForClasses) EntryPointAccessors.fromApplication(activity, InjectionHelperForClasses.class);
        }
        R$id.launch$default(R$color.CoroutineScope(Dispatchers.Default), (CoroutineContext) null, (CoroutineStart) null, new FindFileHelper$refreshFiles$1(activity, (Continuation<? super FindFileHelper$refreshFiles$1>) null), 3, (Object) null);
    }

    public final ArrayList<FilesData> removeDuplicates(ArrayList<FilesData> arrayList) {
        HashSet hashSet = new HashSet();
        ArrayList arrayList2 = new ArrayList();
        for (T next : arrayList) {
            String str = ((FilesData) next).title;
            if (hashSet.add(new Pair(str, str))) {
                arrayList2.add(next);
            }
        }
        return new ArrayList<>(arrayList2);
    }

    public final File sampleFileFolder(Activity activity, String str) {
        Intrinsics.checkNotNullParameter(activity, "activity");
        Intrinsics.checkNotNullParameter(str, "fileName");
        StringBuilder sb = new StringBuilder();
        File externalFilesDir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        Intrinsics.checkNotNull(externalFilesDir);
        sb.append(externalFilesDir.getAbsolutePath());
        sb.append('/');
        sb.append(activity.getString(R.string.app_name));
        File file = new File(sb.toString());
        if (!file.exists()) {
            file.mkdir();
        }
        return new File(file.getPath() + '/' + str);
    }
}
