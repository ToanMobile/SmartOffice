package com.artifex.sonui.commonutils;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.artifex.sonui.commonutils.TagListAdapter;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.DaoManager;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.FileDb.FileDatabase;
import com.rpdev.a1officecloudmodule.database.Labelsdatabase.TagsDb.TagData;
import com.rpdev.document.manager.reader.allfiles.R;
import java.util.ArrayList;
import java.util.List;

public class ManageLabelDialog {
    public AlertDialog addMoreTagDialog;
    public Button btnAdd;
    public Button btnCancel;
    public FileDatabase database;
    public EditText eTextTagName;
    public FileUtils fileUtils;
    public boolean isFileExists = false;
    public boolean isLabelAssigned = false;
    public Activity mActivity;
    public TagListAdapter mTagListAdapter;
    public OnManageLabelCallback onManageLabelCallback;
    public String path = "";
    public RecyclerView rvTags;
    public AlertDialog selectTagDialog;
    public StringUtils stringUtils;
    public TagData tagData = null;
    public List<TagData> tagDataArrayList;
    public TagListAdapter.TagListItemClick tagListItemClick = new TagListAdapter.TagListItemClick() {
        public void onItemClick(int i) {
            if (ManageLabelDialog.this.tagDataArrayList.get(i).isSelected) {
                ManageLabelDialog.this.tagDataArrayList.get(i).isSelected = false;
            } else {
                ManageLabelDialog.this.tagDataArrayList.get(i).isSelected = true;
            }
            ManageLabelDialog.access$900(ManageLabelDialog.this);
        }
    };
    public TextView txtAddMoreTag;
    public TextView txtCancel;
    public TextView txtDone;
    public TextView txtMsg;
    public TextView txtNoData;
    public TextView txtTLMsg;
    public TextView txtTitle;
    public int type = 0;
    public String userEnteredTagName;

    public class AddNewLabelTask extends AsyncTask<Void, Void, Void> {
        public AddNewLabelTask() {
        }

        public Object doInBackground(Object[] objArr) {
            Void[] voidArr = (Void[]) objArr;
            ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
            manageLabelDialog.database = FileDatabase.getMainInstance(manageLabelDialog.mActivity);
            ManageLabelDialog manageLabelDialog2 = ManageLabelDialog.this;
            try {
                manageLabelDialog2.database.tagsInstanceDao().insertTag(new TagData((Long) null, manageLabelDialog2.userEnteredTagName, "", false));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        public void onPostExecute(Object obj) {
            super.onPostExecute((Void) obj);
            if (ManageLabelDialog.this.path.length() == 0) {
                ManageLabelDialog.this.onManageLabelCallback.onMLSuccess(true);
                return;
            }
            ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
            manageLabelDialog.mTagListAdapter = null;
            if (manageLabelDialog.tagDataArrayList.size() > 0) {
                ManageLabelDialog.this.tagDataArrayList.clear();
            }
            new FetchAllLabelsTask().execute(new Void[0]);
        }
    }

    public class AssignLabelToFileTask extends AsyncTask<Void, Void, Void> {
        public AssignLabelToFileTask() {
        }

        public Object doInBackground(Object[] objArr) {
            Void[] voidArr = (Void[]) objArr;
            for (int i = 0; i < ManageLabelDialog.this.tagDataArrayList.size(); i++) {
                TagData tagData = ManageLabelDialog.this.tagDataArrayList.get(i);
                if (tagData.isSelected) {
                    ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
                    if (!DaoManager.isFileEntryExist(manageLabelDialog.database, FileUtils.getFileName(manageLabelDialog.path), ManageLabelDialog.this.path, tagData.id)) {
                        ManageLabelDialog manageLabelDialog2 = ManageLabelDialog.this;
                        manageLabelDialog2.isLabelAssigned = true;
                        DaoManager.InsertTagFileEntry(manageLabelDialog2.database, tagData.id, tagData.tagName, FileUtils.getFileName(manageLabelDialog2.path), ManageLabelDialog.this.path, true);
                    }
                } else {
                    ManageLabelDialog manageLabelDialog3 = ManageLabelDialog.this;
                    if (DaoManager.isFileEntryExist(manageLabelDialog3.database, FileUtils.getFileName(manageLabelDialog3.path), ManageLabelDialog.this.path, tagData.id)) {
                        ManageLabelDialog manageLabelDialog4 = ManageLabelDialog.this;
                        DaoManager.DeleteFileEntryWithTagId(manageLabelDialog4.database, manageLabelDialog4.path, tagData.id);
                    }
                }
            }
            return null;
        }

        public void onPostExecute(Object obj) {
            super.onPostExecute((Void) obj);
            ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
            if (manageLabelDialog.isLabelAssigned) {
                Toast.makeText(manageLabelDialog.mActivity, "Tag added successfully", 0).show();
            } else {
                Toast.makeText(manageLabelDialog.mActivity, "Document already exist in selected tag", 0).show();
            }
        }
    }

    public class FetchAllLabelsTask extends AsyncTask<Void, Void, Void> {
        public FetchAllLabelsTask() {
        }

        public Object doInBackground(Object[] objArr) {
            Void[] voidArr = (Void[]) objArr;
            ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
            manageLabelDialog.database = FileDatabase.getMainInstance(manageLabelDialog.mActivity);
            ManageLabelDialog.this.tagDataArrayList = new ArrayList();
            ManageLabelDialog manageLabelDialog2 = ManageLabelDialog.this;
            manageLabelDialog2.tagDataArrayList = DaoManager.GetAllTags(manageLabelDialog2.database);
            for (int i = 0; i < ManageLabelDialog.this.tagDataArrayList.size(); i++) {
                ManageLabelDialog manageLabelDialog3 = ManageLabelDialog.this;
                FileDatabase fileDatabase = manageLabelDialog3.database;
                String fileName = FileUtils.getFileName(manageLabelDialog3.path);
                ManageLabelDialog manageLabelDialog4 = ManageLabelDialog.this;
                if (DaoManager.isFileEntryExist(fileDatabase, fileName, manageLabelDialog4.path, manageLabelDialog4.tagDataArrayList.get(i).id)) {
                    ManageLabelDialog.this.tagDataArrayList.get(i).isSelected = true;
                    ManageLabelDialog.this.isFileExists = true;
                }
            }
            return null;
        }

        public void onPostExecute(Object obj) {
            super.onPostExecute((Void) obj);
            ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
            if (manageLabelDialog.isFileExists) {
                manageLabelDialog.isFileExists = false;
                manageLabelDialog.txtTLMsg.setText("File already exists on selected tags, uncheck to remove");
                ManageLabelDialog.this.txtTLMsg.setVisibility(0);
            }
            ManageLabelDialog manageLabelDialog2 = ManageLabelDialog.this;
            manageLabelDialog2.mTagListAdapter = null;
            ManageLabelDialog.access$900(manageLabelDialog2);
        }
    }

    public interface OnManageLabelCallback {
        void onMLSuccess(boolean z);
    }

    public class RenameLabelTask extends AsyncTask<Void, Void, Void> {
        public RenameLabelTask() {
        }

        public Object doInBackground(Object[] objArr) {
            Void[] voidArr = (Void[]) objArr;
            ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
            manageLabelDialog.database = FileDatabase.getMainInstance(manageLabelDialog.mActivity);
            ManageLabelDialog manageLabelDialog2 = ManageLabelDialog.this;
            FileDatabase fileDatabase = manageLabelDialog2.database;
            try {
                fileDatabase.tagsInstanceDao().updateTagName(manageLabelDialog2.tagData.id, manageLabelDialog2.userEnteredTagName);
                return null;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public void onPostExecute(Object obj) {
            super.onPostExecute((Void) obj);
            ManageLabelDialog.this.onManageLabelCallback.onMLSuccess(true);
        }
    }

    public ManageLabelDialog(Activity activity, Uri uri, String str, int i, OnManageLabelCallback onManageLabelCallback2) {
        this.mActivity = activity;
        this.path = str;
        this.type = i;
        this.onManageLabelCallback = onManageLabelCallback2;
        this.fileUtils = new FileUtils(activity);
        this.stringUtils = new StringUtils(activity);
    }

    public static void access$900(ManageLabelDialog manageLabelDialog) {
        List<TagData> list = manageLabelDialog.tagDataArrayList;
        if (list == null || list.size() <= 0) {
            manageLabelDialog.rvTags.setVisibility(8);
            manageLabelDialog.txtNoData.setVisibility(0);
            manageLabelDialog.txtNoData.setText("No tags found.");
            return;
        }
        manageLabelDialog.rvTags.setVisibility(0);
        manageLabelDialog.txtNoData.setVisibility(8);
        TagListAdapter tagListAdapter = manageLabelDialog.mTagListAdapter;
        if (tagListAdapter == null) {
            TagListAdapter tagListAdapter2 = new TagListAdapter(manageLabelDialog.mActivity, manageLabelDialog.tagDataArrayList, manageLabelDialog.tagListItemClick);
            manageLabelDialog.mTagListAdapter = tagListAdapter2;
            manageLabelDialog.rvTags.setAdapter(tagListAdapter2);
            return;
        }
        tagListAdapter.notifyDataSetChanged();
        manageLabelDialog.rvTags.invalidate();
    }

    public void showAssignLabelDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.mActivity);
        View inflate = this.mActivity.getLayoutInflater().inflate(R.layout.tag_listing_popup, (ViewGroup) null);
        builder.setView(inflate);
        this.txtAddMoreTag = (TextView) inflate.findViewById(R.id.txtAddMoreTag);
        this.txtTLMsg = (TextView) inflate.findViewById(R.id.txtTLMsg);
        this.rvTags = (RecyclerView) inflate.findViewById(R.id.rvTags);
        this.txtNoData = (TextView) inflate.findViewById(R.id.txtNoData);
        this.btnCancel = (Button) inflate.findViewById(R.id.btnCancel);
        this.btnAdd = (Button) inflate.findViewById(R.id.btnAdd);
        boolean z = false;
        if (this.type == 0) {
            this.txtAddMoreTag.setVisibility(4);
        } else {
            this.txtAddMoreTag.setVisibility(0);
        }
        this.txtAddMoreTag.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
                AlertDialog.Builder builder = new AlertDialog.Builder(manageLabelDialog.mActivity);
                View inflate = manageLabelDialog.mActivity.getLayoutInflater().inflate(R.layout.v2_add_label_dialog, (ViewGroup) null);
                builder.setView(inflate);
                manageLabelDialog.eTextTagName = (EditText) inflate.findViewById(R.id.eTextTagName);
                manageLabelDialog.txtCancel = (TextView) inflate.findViewById(R.id.txtCancel);
                manageLabelDialog.txtDone = (TextView) inflate.findViewById(R.id.txtDone);
                manageLabelDialog.txtCancel.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        ManageLabelDialog.this.addMoreTagDialog.dismiss();
                    }
                });
                manageLabelDialog.txtDone.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        ManageLabelDialog manageLabelDialog = ManageLabelDialog.this;
                        manageLabelDialog.userEnteredTagName = ManageFiles$2$$ExternalSyntheticOutline0.m(manageLabelDialog.eTextTagName);
                        if (ManageLabelDialog.this.userEnteredTagName.length() == 0) {
                            ManageLabelDialog.this.eTextTagName.setError("Tag name cannot be empty");
                            return;
                        }
                        ManageLabelDialog.this.addMoreTagDialog.dismiss();
                        new AddNewLabelTask().execute(new Void[0]);
                    }
                });
                AlertDialog create = builder.create();
                manageLabelDialog.addMoreTagDialog = create;
                create.setCancelable(false);
                manageLabelDialog.addMoreTagDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                manageLabelDialog.addMoreTagDialog.show();
            }
        });
        this.btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ManageLabelDialog.this.selectTagDialog.dismiss();
            }
        });
        this.btnAdd.setOnClickListener(new View.OnClickListener() {
            /* JADX WARNING: Removed duplicated region for block: B:11:0x0028  */
            /* JADX WARNING: Removed duplicated region for block: B:12:0x003c  */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void onClick(android.view.View r3) {
                /*
                    r2 = this;
                    com.artifex.sonui.commonutils.ManageLabelDialog r3 = com.artifex.sonui.commonutils.ManageLabelDialog.this
                    java.util.List<com.rpdev.a1officecloudmodule.database.Labelsdatabase.TagsDb.TagData> r3 = r3.tagDataArrayList
                    r0 = 0
                    if (r3 == 0) goto L_0x0025
                    r3 = 0
                L_0x0008:
                    com.artifex.sonui.commonutils.ManageLabelDialog r1 = com.artifex.sonui.commonutils.ManageLabelDialog.this
                    java.util.List<com.rpdev.a1officecloudmodule.database.Labelsdatabase.TagsDb.TagData> r1 = r1.tagDataArrayList
                    int r1 = r1.size()
                    if (r3 >= r1) goto L_0x0025
                    com.artifex.sonui.commonutils.ManageLabelDialog r1 = com.artifex.sonui.commonutils.ManageLabelDialog.this
                    java.util.List<com.rpdev.a1officecloudmodule.database.Labelsdatabase.TagsDb.TagData> r1 = r1.tagDataArrayList
                    java.lang.Object r1 = r1.get(r3)
                    com.rpdev.a1officecloudmodule.database.Labelsdatabase.TagsDb.TagData r1 = (com.rpdev.a1officecloudmodule.database.Labelsdatabase.TagsDb.TagData) r1
                    boolean r1 = r1.isSelected
                    if (r1 == 0) goto L_0x0022
                    r3 = 1
                    goto L_0x0026
                L_0x0022:
                    int r3 = r3 + 1
                    goto L_0x0008
                L_0x0025:
                    r3 = 0
                L_0x0026:
                    if (r3 == 0) goto L_0x003c
                    com.artifex.sonui.commonutils.ManageLabelDialog r3 = com.artifex.sonui.commonutils.ManageLabelDialog.this
                    androidx.appcompat.app.AlertDialog r3 = r3.selectTagDialog
                    r3.dismiss()
                    com.artifex.sonui.commonutils.ManageLabelDialog$AssignLabelToFileTask r3 = new com.artifex.sonui.commonutils.ManageLabelDialog$AssignLabelToFileTask
                    com.artifex.sonui.commonutils.ManageLabelDialog r1 = com.artifex.sonui.commonutils.ManageLabelDialog.this
                    r3.<init>()
                    java.lang.Void[] r0 = new java.lang.Void[r0]
                    r3.execute(r0)
                    goto L_0x0049
                L_0x003c:
                    com.artifex.sonui.commonutils.ManageLabelDialog r3 = com.artifex.sonui.commonutils.ManageLabelDialog.this
                    android.app.Activity r3 = r3.mActivity
                    java.lang.String r1 = "Please select at least one tag to add file"
                    android.widget.Toast r3 = android.widget.Toast.makeText(r3, r1, r0)
                    r3.show()
                L_0x0049:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.artifex.sonui.commonutils.ManageLabelDialog.AnonymousClass3.onClick(android.view.View):void");
            }
        });
        this.rvTags.setLayoutManager(new LinearLayoutManager(this.mActivity));
        new FetchAllLabelsTask().execute(new Void[0]);
        AlertDialog create = builder.create();
        this.selectTagDialog = create;
        create.setCancelable(false);
        this.selectTagDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        Activity activity = this.mActivity;
        if (activity != null) {
            z = true;
        }
        if ((!activity.isFinishing()) && z) {
            this.selectTagDialog.show();
        }
    }

    public ManageLabelDialog(Activity activity, TagData tagData2, OnManageLabelCallback onManageLabelCallback2) {
        this.mActivity = activity;
        this.tagData = tagData2;
        this.onManageLabelCallback = onManageLabelCallback2;
        this.fileUtils = new FileUtils(activity);
        this.stringUtils = new StringUtils(activity);
    }
}
