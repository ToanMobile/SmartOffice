package com.artifex.sonui.artifactsdk.activity;

import a.a.a.a.a.c$$ExternalSyntheticOutline0;
import a.a.a.a.b.f.a$$ExternalSyntheticOutline0;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.analytics_lite.analytics.analytic.AnalyticsHelp;
import com.artifex.solib.FileUtils;
import com.artifex.sonui.artifactsdk.adapter.PathDataAdapter;
import com.artifex.sonui.artifactsdk.modelEditor.PathData;
import com.artifex.sonui.commonutils.RenameFileDialog;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.rpdev.document.manager.reader.allfiles.R;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class SaveAsActivity extends AppCompatActivity implements View.OnClickListener {
    public String a1OfficeFolderName = "A1 Office Documents";
    public AppCompatButton btnSave;
    public String fileName = "";
    public LinearLayoutCompat llA1OfficeDoc;
    public LinearLayoutCompat llDoc;
    public LinearLayoutCompat llFolders;
    public LinearLayoutCompat llLocationDetails;
    public Context mContext;
    public PathDataAdapter mPathDataAdapter;
    public PathDataAdapter.OnPathDataListItemClick onPathDataListItemClick = new PathDataAdapter.OnPathDataListItemClick() {
    };
    public String path = "";
    public ArrayList<PathData> pathDataArrayList;
    public RecyclerView rvDirDetails;
    public String selectedUserPath = "";
    public String selectedUserPathFolderName = "";
    public Toolbar toolbar;
    public TextView txtActivityTitle;
    public AppCompatTextView txtFileName;
    public AppCompatTextView txtPath;

    public final void fetchDirData(String str) {
        ArrayList<PathData> arrayList = this.pathDataArrayList;
        if (arrayList == null) {
            this.pathDataArrayList = new ArrayList<>();
        } else {
            arrayList.clear();
        }
        File[] listFiles = new File(str).listFiles();
        int i = 0;
        while (i < listFiles.length) {
            try {
                PathData pathData = new PathData();
                pathData.title = listFiles[i].getName();
                pathData.path = listFiles[i].getPath();
                if (listFiles[i].isDirectory()) {
                    pathData.isFolder = true;
                } else {
                    pathData.isFolder = false;
                }
                if (!listFiles[i].isHidden()) {
                    this.pathDataArrayList.add(pathData);
                }
                i++;
            } catch (Exception unused) {
            }
        }
        this.mPathDataAdapter = null;
        ArrayList<PathData> arrayList2 = this.pathDataArrayList;
        if (arrayList2 == null || arrayList2.size() <= 0) {
            this.rvDirDetails.setVisibility(8);
            return;
        }
        this.rvDirDetails.setVisibility(0);
        if (this.mPathDataAdapter == null) {
            PathDataAdapter pathDataAdapter = new PathDataAdapter(this, this.pathDataArrayList, this.onPathDataListItemClick);
            this.mPathDataAdapter = pathDataAdapter;
            this.rvDirDetails.setAdapter(pathDataAdapter);
            return;
        }
        this.rvDirDetails.invalidate();
        this.mPathDataAdapter.notifyDataSetChanged();
    }

    public void onBackPressed() {
        if (this.selectedUserPathFolderName.length() == 0) {
            try {
                AnalyticsHelp.getInstance().logEvent("event_app_editor_save_as_activity_backbutton", (Map<String, String>) null);
            } catch (Exception e) {
                FirebaseCrashlytics.getInstance().log(e.getMessage());
            }
            finish();
            return;
        }
        String str = this.selectedUserPath;
        String substring = str.substring(str.lastIndexOf("/") + 1);
        if (substring.equals(getResources().getString(R.string.a1_office_doc)) || substring.equals(getResources().getString(R.string.doc))) {
            this.mPathDataAdapter = null;
            this.rvDirDetails.setVisibility(8);
            this.selectedUserPathFolderName = "";
            this.llFolders.setVisibility(0);
            this.llLocationDetails.setVisibility(8);
            return;
        }
        String m = a$$ExternalSyntheticOutline0.m("/", substring);
        this.selectedUserPath = this.selectedUserPath.replace(m, "");
        this.selectedUserPathFolderName = this.selectedUserPathFolderName.replace(m, "");
        updatePath();
        fetchDirData(this.selectedUserPath);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.llDoc) {
            String path2 = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS).getPath();
            this.selectedUserPath = path2;
            fetchDirData(path2);
            this.llFolders.setVisibility(8);
            this.llLocationDetails.setVisibility(0);
            this.selectedUserPathFolderName = Environment.DIRECTORY_DOCUMENTS;
            updatePath();
        } else if (view.getId() == R.id.llA1OfficeDoc) {
            String path3 = Environment.getExternalStoragePublicDirectory(this.a1OfficeFolderName).getPath();
            this.selectedUserPath = path3;
            fetchDirData(path3);
            this.llFolders.setVisibility(8);
            this.llLocationDetails.setVisibility(0);
            this.selectedUserPathFolderName = this.a1OfficeFolderName;
            updatePath();
        } else if (view.getId() == R.id.btnSave) {
            try {
                HashMap hashMap = new HashMap();
                hashMap.put("path", this.path);
                AnalyticsHelp.getInstance().logEvent("event_app_editor_save_as_activity_save_button_pressed", hashMap);
            } catch (Exception e) {
                FirebaseCrashlytics.getInstance().log(e.getMessage());
            }
            if (Objects.equals(this.selectedUserPath, "")) {
                Snackbar.make(findViewById(R.id.activitySaveLayout), "Please Enter Destination to Save File", 0).show();
            } else {
                new RenameFileDialog(this, new RenameFileDialog.RenameFileDialogListener() {
                }, "save_as_activity").show();
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.v2_activity_save_as);
        this.mContext = this;
        this.path = getIntent().getExtras().getString("path");
        try {
            HashMap hashMap = new HashMap();
            hashMap.put("path", this.path);
            AnalyticsHelp.getInstance().logEvent("event_app_editor_save_as_activity_open", hashMap);
        } catch (Exception e) {
            FirebaseCrashlytics.getInstance().log(e.getMessage());
        }
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.txtActivityTitle = (TextView) findViewById(R.id.txtActivityTitle);
        this.txtFileName = (AppCompatTextView) findViewById(R.id.txtFileName);
        this.txtPath = (AppCompatTextView) findViewById(R.id.txtPath);
        this.llLocationDetails = (LinearLayoutCompat) findViewById(R.id.llLocationDetails);
        this.llFolders = (LinearLayoutCompat) findViewById(R.id.llFolders);
        this.llDoc = (LinearLayoutCompat) findViewById(R.id.llDoc);
        this.llA1OfficeDoc = (LinearLayoutCompat) findViewById(R.id.llA1OfficeDoc);
        this.rvDirDetails = (RecyclerView) findViewById(R.id.rvDirDetails);
        this.btnSave = (AppCompatButton) findViewById(R.id.btnSave);
        this.llDoc.setOnClickListener(this);
        this.llA1OfficeDoc.setOnClickListener(this);
        this.btnSave.setOnClickListener(this);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        this.rvDirDetails.setLayoutManager(new LinearLayoutManager(this.mContext));
        this.txtActivityTitle.setText("");
        TextView textView = this.txtActivityTitle;
        StringBuilder m = c$$ExternalSyntheticOutline0.m("");
        m.append(getResources().getString(R.string.sub_menu_save_as));
        textView.setText(m.toString());
        String str = "A1 Office " + System.currentTimeMillis() + ".pdf";
        this.fileName = str;
        FileUtils.getExtension(str);
        AppCompatTextView appCompatTextView = this.txtFileName;
        StringBuilder m2 = c$$ExternalSyntheticOutline0.m("");
        m2.append(this.fileName);
        appCompatTextView.setText(m2.toString());
        File file = new File(Environment.getExternalStorageDirectory(), this.a1OfficeFolderName);
        if (!file.exists() && !file.mkdirs()) {
            Log.d("App", "failed to create directory");
        }
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return true;
        }
        finish();
        return true;
    }

    public final void updatePath() {
        AppCompatTextView appCompatTextView = this.txtPath;
        StringBuilder m = c$$ExternalSyntheticOutline0.m("");
        m.append(this.selectedUserPathFolderName);
        appCompatTextView.setText(m.toString());
    }
}
