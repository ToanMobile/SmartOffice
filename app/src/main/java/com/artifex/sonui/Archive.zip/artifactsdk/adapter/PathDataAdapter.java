package com.artifex.sonui.artifactsdk.adapter;

import a.a.a.a.a.c$$ExternalSyntheticOutline0;
import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;
import com.commons_lite.ads_module.billing.pro.legacy.ProAdapter$$ExternalSyntheticOutline0;
import com.artifex.sonui.artifactsdk.activity.SaveAsActivity;
import com.artifex.sonui.artifactsdk.modelEditor.PathData;
import com.rpdev.document.manager.reader.allfiles.R;
import java.util.ArrayList;

public class PathDataAdapter extends RecyclerView.Adapter<ViewHolder> {
    public ArrayList<PathData> list;
    public Activity mActivity;
    public OnPathDataListItemClick onPathDataListItemClick;

    public interface OnPathDataListItemClick {
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public AppCompatImageView imvFilesIcon;
        public AppCompatTextView txtTitle;

        public ViewHolder(PathDataAdapter pathDataAdapter, View view) {
            super(view);
            this.imvFilesIcon = (AppCompatImageView) view.findViewById(R.id.imvFilesIcon);
            this.txtTitle = (AppCompatTextView) view.findViewById(R.id.txtTitle);
        }
    }

    public PathDataAdapter(Activity activity, ArrayList<PathData> arrayList, OnPathDataListItemClick onPathDataListItemClick2) {
        this.mActivity = activity;
        this.list = arrayList;
        this.onPathDataListItemClick = onPathDataListItemClick2;
    }

    public int getItemCount() {
        return this.list.size();
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        if (this.list.get(i) != null) {
            PathData pathData = this.list.get(i);
            AppCompatTextView appCompatTextView = viewHolder2.txtTitle;
            StringBuilder m = c$$ExternalSyntheticOutline0.m("");
            m.append(pathData.title);
            appCompatTextView.setText(m.toString());
            if (pathData.isFolder) {
                viewHolder2.imvFilesIcon.setImageResource(R.drawable.ic_folder_save_as);
            } else if (pathData.title.endsWith(".pdf")) {
                viewHolder2.imvFilesIcon.setImageResource(R.mipmap.ic_file_pdf);
            } else if (pathData.title.endsWith(".docx") || pathData.title.endsWith(".doc") || pathData.title.endsWith(".docm") || pathData.title.endsWith(".dot") || pathData.title.endsWith(".dotx") || pathData.title.endsWith(".ppt") || pathData.title.endsWith(".pptx") || pathData.title.endsWith(".ppa") || pathData.title.endsWith(".pps") || pathData.title.endsWith(".xlsx") || pathData.title.endsWith(".xlsm") || pathData.title.endsWith(".xlsb") || pathData.title.endsWith(".xlam") || pathData.title.endsWith(".xltm") || pathData.title.endsWith(".xltx") || pathData.title.endsWith(".xls")) {
                viewHolder2.imvFilesIcon.setImageResource(R.drawable.ic_file_word);
            } else if (pathData.title.endsWith(".csv")) {
                viewHolder2.imvFilesIcon.setImageResource(R.mipmap.ic_file_xls);
            } else if (pathData.title.endsWith(".html")) {
                viewHolder2.imvFilesIcon.setImageResource(R.mipmap.ic_file_html);
            } else if (pathData.title.endsWith(".png") || pathData.title.endsWith(".jpg") || pathData.title.endsWith(".jpeg")) {
                viewHolder2.imvFilesIcon.setImageResource(R.drawable.ic_file_image);
            } else if (pathData.title.endsWith(".txt")) {
                viewHolder2.imvFilesIcon.setImageResource(R.mipmap.ic_file_txt);
            } else {
                viewHolder2.imvFilesIcon.setImageResource(R.drawable.ic_folder_save_as);
            }
            viewHolder2.itemView.setTag(Integer.valueOf(i));
            viewHolder2.itemView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    int intValue = ((Integer) view.getTag()).intValue();
                    SaveAsActivity.AnonymousClass2 r0 = (SaveAsActivity.AnonymousClass2) PathDataAdapter.this.onPathDataListItemClick;
                    SaveAsActivity saveAsActivity = SaveAsActivity.this;
                    saveAsActivity.selectedUserPathFolderName = SaveAsActivity.this.selectedUserPathFolderName + "/" + SaveAsActivity.this.pathDataArrayList.get(intValue).title;
                    SaveAsActivity.this.updatePath();
                    SaveAsActivity saveAsActivity2 = SaveAsActivity.this;
                    saveAsActivity2.selectedUserPath = saveAsActivity2.pathDataArrayList.get(intValue).path;
                    SaveAsActivity saveAsActivity3 = SaveAsActivity.this;
                    saveAsActivity3.fetchDirData(saveAsActivity3.pathDataArrayList.get(intValue).path);
                }
            });
        }
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(this, ProAdapter$$ExternalSyntheticOutline0.m(viewGroup, R.layout.v2_path_data_row, viewGroup, false));
    }
}
