package com.artifex.sonui.artifactsdk.utilitiesEditorSdk;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import com.artifex.solib.SOClipboardHandler;

public class ClipboardHandler implements SOClipboardHandler {
    public Activity mActivity;
    public ClipboardManager mClipboard;

    public boolean clipboardHasPlaintext() {
        try {
            return this.mClipboard.hasPrimaryClip();
        } catch (Exception unused) {
            return false;
        }
    }

    public String getPlainTextFromClipoard() {
        boolean z;
        try {
            z = this.mClipboard.hasPrimaryClip();
        } catch (Exception unused) {
            z = false;
        }
        return z ? this.mClipboard.getPrimaryClip().getItemAt(0).coerceToText(this.mActivity).toString() : "";
    }

    public void initClipboardHandler(Activity activity) {
        this.mActivity = activity;
        this.mClipboard = (ClipboardManager) activity.getSystemService("clipboard");
    }

    public void putPlainTextToClipboard(String str) {
        this.mClipboard.setPrimaryClip(ClipData.newPlainText("text", str));
    }

    public void releaseClipboardHandler() {
        this.mActivity = null;
        this.mClipboard = null;
    }
}
