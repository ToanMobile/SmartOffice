package com.artifex.sonui.artifactsdk.utilitiesEditorSdk;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.artifex.sonui.editor.DocumentView;

public class Overlay extends View implements View.OnTouchListener {
    public int currentX = 0;
    public int currentY = 0;
    public boolean drawing = false;
    public DocumentView mDocumentView;
    public int startX = 0;
    public int startY = 0;

    public Overlay(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setOnTouchListener(this);
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.drawing) {
            Paint paint = new Paint();
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(10.0f);
            paint.setColor(-16776961);
            int[] iArr = {0, 0};
            getLocationInWindow(iArr);
            int i = this.startX - iArr[0];
            int i2 = this.startY - iArr[1];
            int i3 = this.currentX - iArr[0];
            int i4 = this.currentY - iArr[1];
            float f = (float) i;
            float f2 = (float) i3;
            float f3 = (float) i4;
            canvas.drawLine(f, (float) i2, f2, f3, paint);
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        int rawX = (int) motionEvent.getRawX();
        int rawY = (int) motionEvent.getRawY();
        int action = motionEvent.getAction();
        if (action == 0) {
            this.currentX = rawX;
            this.startX = rawX;
            this.currentY = rawY;
            this.startY = rawY;
            this.drawing = true;
            invalidate();
        } else if (action == 1) {
            this.drawing = false;
            invalidate();
            int abs = Math.abs(this.currentX - this.startX);
            int abs2 = Math.abs(this.currentY - this.startY);
            if (abs >= 10 || abs2 >= 10) {
                this.mDocumentView.select(new Point(this.startX, this.startY), new Point(this.currentX, this.currentY));
            } else {
                this.mDocumentView.select(new Point(this.currentX, this.currentY));
            }
        } else if (action == 2) {
            this.currentX = rawX;
            this.currentY = rawY;
            invalidate();
        }
        return true;
    }

    public void setDocView(DocumentView documentView) {
        this.mDocumentView = documentView;
    }
}
