package com.artifex.sonui.commonutils.fileUtils;

import java.io.File;
import java.io.FileFilter;

public class ExtensionsFilter implements FileFilter {
    public String[] extensions;

    public ExtensionsFilter(String str, String[] strArr) {
        String[] strArr2 = (String[]) strArr.clone();
        this.extensions = strArr2;
        int length = strArr2.length;
        for (int i = 0; i < length; i++) {
            strArr2[i] = strArr2[i].toLowerCase();
        }
    }

    public boolean accept(File file) {
        if (file.isDirectory()) {
            return true;
        }
        String lowerCase = file.getAbsolutePath().toLowerCase();
        for (String str : this.extensions) {
            if (lowerCase.endsWith(str) && lowerCase.charAt((lowerCase.length() - str.length()) - 1) == '.') {
                return true;
            }
        }
        return false;
    }
}
