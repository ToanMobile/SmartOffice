package com.artifex.sonui.commonutils;

import a.a.a.a.a.c$$ExternalSyntheticOutline0;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.artifex.sonui.commonutils.ManageLabelDialog;
import java.util.List;

public class TagListAdapter extends RecyclerView.Adapter<ViewHolder> {
    public List<TagData> list;
    public Context mContext;
    public TagListItemClick tagListItemClick;

    public interface TagListItemClick {
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public CheckBox chkTag;
        public ImageView imvTagStatus;
        public TextView txtTagTitle;

        public ViewHolder(TagListAdapter tagListAdapter, View view) {
            super(view);
            this.imvTagStatus = (ImageView) view.findViewById(R.id.imvTagStatus);
            this.chkTag = (CheckBox) view.findViewById(R.id.chkTag);
            this.txtTagTitle = (TextView) view.findViewById(R.id.txtTagTitle);
        }
    }

    public TagListAdapter(Context context, List<TagData> list2, TagListItemClick tagListItemClick2) {
        this.mContext = context;
        this.list = list2;
        this.tagListItemClick = tagListItemClick2;
    }

    public int getItemCount() {
        return this.list.size();
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        if (this.list.get(i) != null) {
            TagData tagData = this.list.get(i);
            TextView textView = viewHolder2.txtTagTitle;
            StringBuilder m = c$$ExternalSyntheticOutline0.m("");
            m.append(tagData.tagName);
            textView.setText(m.toString());
            if (tagData.isSelected) {
                viewHolder2.imvTagStatus.setImageResource(R.mipmap.ic_tag_selected);
                viewHolder2.chkTag.setChecked(true);
            } else {
                viewHolder2.imvTagStatus.setImageResource(R.mipmap.ic_tag_default);
                viewHolder2.chkTag.setChecked(false);
            }
            viewHolder2.itemView.setTag(Integer.valueOf(i));
            viewHolder2.itemView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    ((ManageLabelDialog.AnonymousClass8) TagListAdapter.this.tagListItemClick).onItemClick(((Integer) view.getTag()).intValue());
                }
            });
            viewHolder2.chkTag.setTag(Integer.valueOf(i));
            viewHolder2.chkTag.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    ((ManageLabelDialog.AnonymousClass8) TagListAdapter.this.tagListItemClick).onItemClick(((Integer) view.getTag()).intValue());
                }
            });
        }
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(this, ProAdapter$$ExternalSyntheticOutline0.m(viewGroup, R.layout.tag_listing_row, viewGroup, false));
    }
}
